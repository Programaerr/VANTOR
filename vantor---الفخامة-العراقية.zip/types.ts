
export interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice: number;
  description: string;
  category: string;
  images: string[];
  isOutOfStock: boolean;
  colors: string[];
  sizes: string[];
  sizeGuide: string;
  offerLabel: string;
}

export interface CartItem extends Product {
  quantity: number;
  selectedSize: string;
  selectedColor: string;
}

export interface OrderRecord {
  orderId: string;
  timestamp: number;
  customerInfo: {
    name: string;
    phone: string;
    address: string;
  };
  customerNotes?: string;
  cartItems: CartItem[];
  totalAmount: number;
  deliveryFee: number;
  finalTotal: number;
  userid?: string | null;
  status?: 'processing' | 'out_for_delivery' | 'delivered' | 'cancelled' | 'failed' | 'returned' | 'replacement';
}

export interface VisitorRecord {
  id: number;
  created_at: string;
  city: string;
  country: string;
  device_type: string;
  os: string;
  browser: string;
  source?: string; // تم التغيير من ip_address إلى source
}

export interface ChatMessage {
  role: 'user' | 'model' | 'agent' | 'system';
  text: string;
}

export interface CurrentUser {
  id: string;
  name:string;
  email: string;
  phone?: string;
  address?: string;
}
