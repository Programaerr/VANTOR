
import React, { useState, useEffect, useCallback, useRef, Suspense, useMemo, useTransition } from 'react';
import { supabase } from './services/supabaseClient';
import { getProducts, upsertProduct, deleteProduct, getCategories, addCategory, updateCategory, deleteCategory, getSettings, saveSettings, getOrders, isUserAdmin, isUserOrderManager, updateUserProfile, saveOrderDirectly, sendTelegramNotification, getProductById, recordVisit } from './services/apiService';
import { Product, CartItem, OrderRecord, CurrentUser } from './types';
import { withTimeout } from './utils';

import Header from './components/Header';
import MainContent from './components/MainContent';
import AIChatWidget from './components/AIChatWidget';
import Footer from './components/Footer';
import Alert from './components/common/Alert';
import LoadingScreen from './components/common/LoadingScreen';
import ConfirmationModal from './components/modals/ConfirmationModal';
import OrderSuccessModal from './components/modals/OrderSuccessModal';
import OrderDetailsModal from './components/modals/OrderDetailsModal';
import PrivacyPolicyModal from './components/modals/PrivacyPolicyModal';
import { LoaderCircle, ChevronUp, SlidersHorizontal, Store, Info, ShieldCheck, Activity, X, LogOut } from 'lucide-react';

const ProductDetail = React.lazy(() => import('./components/ProductDetail'));
const AdminPanel = React.lazy(() => import('./components/AdminPanel'));
const Cart = React.lazy(() => import('./components/Cart'));
const AuthModal = React.lazy(() => import('./components/AuthModal'));
const ProfileView = React.lazy(() => import('./components/ProfileView'));

const ComponentLoader = () => (
  <div className="flex items-center justify-center p-10 w-full h-full min-h-[200px]">
    <LoaderCircle size={32} className="animate-spin text-black/20" />
  </div>
);

// --- SAFE HISTORY NAVIGATION HELPERS ---
const safeHistoryPush = (state: any, url: string = '') => {
  try {
    if (window.location.protocol === 'blob:') {
        window.history.pushState(state, '');
    } else {
        window.history.pushState(state, '', url || undefined);
    }
  } catch (e) {
    try { window.history.pushState(state, ''); } catch(e2) {}
  }
};

const safeHistoryReplace = (state: any, url: string = '') => {
  try {
    if (window.location.protocol === 'blob:') {
        window.history.replaceState(state, '');
    } else {
        window.history.replaceState(state, '', url || undefined);
    }
  } catch (e) {
    try { window.history.replaceState(state, ''); } catch(e2) {}
  }
};

// Simple Error Boundary implementation for function components
interface ErrorBoundaryProps {
  children?: React.ReactNode;
}
interface ErrorBoundaryState {
  hasError: boolean;
}
class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  state: ErrorBoundaryState = { hasError: false };
  declare props: Readonly<ErrorBoundaryProps>;
  static getDerivedStateFromError(error: any) { return { hasError: true }; }
  componentDidCatch(error: any, errorInfo: any) { console.error("Uncaught error:", error, errorInfo); }
  render() {
    if (this.state.hasError) {
      return <div className="p-10 text-center"><h1>عذراً، حدث خطأ ما.</h1><button onClick={() => window.location.reload()} className="mt-4 px-4 py-2 bg-black text-white rounded-lg">تحديث الصفحة</button></div>;
    }
    return this.props.children;
  }
}

// --- APP STATE TYPES ---
type ViewType = 'HOME' | 'STORE' | 'ADMIN';
type ModalType = 'cart' | 'menu' | 'filters' | 'auth' | 'profile' | 'logoutConfirm' | 'aboud' | 'privacy';

export default function App() {
  // Data State
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [currentUser, setCurrentUser] = useState<CurrentUser | null>(null);
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const [isOrderManagerLoggedIn, setIsOrderManagerLoggedIn] = useState(false);
  const [ordersHistory, setOrdersHistory] = useState<OrderRecord[]>([]);
  
  // Settings State
  const [heroImageUrl, setHeroImageUrl] = useState<string>('');
  const [announcementText, setAnnouncementText] = useState<string>('');
  const [announcementTimerEnabled, setAnnouncementTimerEnabled] = useState(false);
  const [announcementDeadline, setAnnouncementDeadline] = useState('');
  const [announcementBgColor, setAnnouncementBgColor] = useState('#000000');
  const [announcementTextColor, setAnnouncementTextColor] = useState('#FFFFFF');
  const [announcementSpeed, setAnnouncementSpeed] = useState(30);
  const [tiktokUrl, setTiktokUrl] = useState(''); 
  const [instagramUrl, setInstagramUrl] = useState('');
  const [facebookUrl, setFacebookUrl] = useState('');
  const [whatsappUrl, setWhatsappUrl] = useState('');
  const [isOfferExpired, setIsOfferExpired] = useState(false);
  
  // UI State (Centralized)
  const [view, setView] = useState<ViewType>('HOME');
  const [modal, setModal] = useState<ModalType | null>(null);
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  
  // Transient State
  const [isLoading, setIsLoading] = useState(true);
  const [isProcessingAdminData, setIsProcessingAdminData] = useState(false);
  const [connectionError, setConnectionError] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [activeCategory, setActiveCategory] = useState<string>('الكل');
  const [priceFilter, setPriceFilter] = useState<number>(45000);
  const [tempPrice, setTempPrice] = useState<number>(45000);
  const [productDisplayMode, setProductDisplayMode] = useState<'GRID' | 'VERTICAL_LIST'>('GRID');
  const [showAlert, setShowAlert] = useState<{ message: string; type: 'warning' | 'info' } | null>(null);
  const [itemToDelete, setItemToDelete] = useState<{ id: string, name: string, type: 'product' | 'category' } | null>(null);
  const [isConfirmingOrder, setIsConfirmingOrder] = useState(false);
  const [showOrderSuccessModal, setShowOrderSuccessModal] = useState(false);
  const [lastOrderId, setLastOrderId] = useState<string>('');
  const [selectedOrderDetails, setSelectedOrderDetails] = useState<OrderRecord | null>(null);
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const [, startTransition] = useTransition();
  
  const alertTimeoutRef = useRef<number | null>(null);
  const isUpdatingFromHistory = useRef(false);
  const footerRef = useRef<HTMLElement>(null);
  const productsGridRef = useRef<HTMLDivElement>(null);

  // --- DERIVED STATE: Automatically get product object when ID changes ---
  useEffect(() => {
    if (selectedProductId) {
        const product = products.find(p => p.id === selectedProductId);
        if (product) {
            setSelectedProduct(product);
        } else {
            setSelectedProduct(null); // Clear previous while fetching
            getProductById(selectedProductId).then(setSelectedProduct);
        }
    } else {
        setSelectedProduct(null);
    }
  }, [selectedProductId, products]);

  // --- SMART DATA FETCHING STRATEGY ---
  const loadInitialData = useCallback(async (isSilent = false, retryCount = 0) => {
    if (!isSilent && retryCount === 0) setIsLoading(true);
    setConnectionError(false);
    try {
        const [productsRes, categoriesRes, settingsRes] = await Promise.all([ getProducts(), getCategories(), getSettings() ]);
        setProducts(productsRes); setCategories(categoriesRes);
        setHeroImageUrl(settingsRes.heroImageUrl); setAnnouncementText(settingsRes.announcementText); setAnnouncementTimerEnabled(settingsRes.announcementTimerEnabled);
        setAnnouncementDeadline(settingsRes.announcementDeadline); setAnnouncementBgColor(settingsRes.announcementBgColor); setAnnouncementTextColor(settingsRes.announcementTextColor);
        setAnnouncementSpeed(settingsRes.announcementSpeed); setTiktokUrl(settingsRes.tiktokUrl); setInstagramUrl(settingsRes.instagramUrl);
        setFacebookUrl(settingsRes.facebookUrl); setWhatsappUrl(settingsRes.whatsappUrl);
        setIsLoading(false);

        // History state initialization after data load
        const params = new URLSearchParams(window.location.search);
        const sharedProductId = params.get('product_id');
        if (sharedProductId) {
            safeHistoryReplace({ view: 'STORE', modal: null, productId: sharedProductId }, `?product_id=${sharedProductId}`);
            setView('STORE'); setSelectedProductId(sharedProductId);
        } else {
            safeHistoryReplace({ view: 'HOME', modal: null, productId: null }, window.location.pathname);
        }
    } catch (e) {
        console.error('Critical Connection Error:', e);
        setConnectionError(true); setIsLoading(false);
    }
  }, []);
  
  // Timer for Offer Expiration
  useEffect(() => {
    if (!announcementTimerEnabled || !announcementDeadline) { setIsOfferExpired(false); return; }
    const checkExpiration = () => {
        const distance = new Date(announcementDeadline).getTime() - new Date().getTime();
        if (distance < 0) setIsOfferExpired(true);
        else { setIsOfferExpired(false); const timeout = setTimeout(() => setIsOfferExpired(true), distance); return () => clearTimeout(timeout); }
    };
    return checkExpiration();
  }, [announcementTimerEnabled, announcementDeadline]);

  // --- APP INITIALIZATION & AUTH ---
  useEffect(() => {
    const handleScroll = () => { setShowScrollTop(window.scrollY > 300); };
    window.addEventListener('scroll', handleScroll);
    if (window.location.hash.includes('access_token')) { setTimeout(() => { setShowAlert({ message: 'تم تفعيل الحساب بنجاح! أهلاً بك في VANTOR.', type: 'info' }); safeHistoryReplace(null, window.location.pathname); }, 1500); }

    const initApp = async () => {
        try {
            const { data: { session } } = await supabase.auth.getSession();
            if (session?.user) {
                 const { id, email, user_metadata: { name, phone, address } } = session.user;
                 setCurrentUser({ id, name: name || email, email, phone, address });
                 Promise.all([isUserAdmin(id), isUserOrderManager(id)]).then(([isAdmin, isManager]) => { setIsAdminLoggedIn(isAdmin); setIsOrderManagerLoggedIn(isManager); });
            }
        } catch (e) { console.warn("Session restoration warning:", e); }
        finally { loadInitialData(); recordVisit(); }
    };
    initApp();

    const { data: authListener } = supabase.auth.onAuthStateChange(async (_event, session) => {
      if (session?.user) {
          const { id, email, user_metadata: { name, phone, address } } = session.user;
          setCurrentUser({ id, name: name || email, email, phone, address });
          Promise.all([isUserAdmin(id), isUserOrderManager(id)]).then(([isAdmin, isManager]) => { setIsAdminLoggedIn(isAdmin); setIsOrderManagerLoggedIn(isManager); });
      } else { 
          setCurrentUser(null); setIsAdminLoggedIn(false); setIsOrderManagerLoggedIn(false);
      }
    });

    return () => { window.removeEventListener('scroll', handleScroll); authListener.subscription.unsubscribe(); };
  }, [loadInitialData]);
  
  // --- ALERT TIMEOUT ---
  useEffect(() => {
    if (showAlert) {
      if (alertTimeoutRef.current) clearTimeout(alertTimeoutRef.current);
      alertTimeoutRef.current = window.setTimeout(() => { setShowAlert(null); }, showAlert.type === 'warning' ? 8000 : 4000);
    }
    return () => { if (alertTimeoutRef.current) clearTimeout(alertTimeoutRef.current); };
  }, [showAlert]);

  // --- MASTER NAVIGATION & HISTORY MANAGEMENT ---
  useEffect(() => {
    const handlePopState = (event: PopStateEvent) => {
      isUpdatingFromHistory.current = true;
      const state = event.state || { view: 'HOME', modal: null, productId: null };
      
      startTransition(() => {
        setView(state.view || 'HOME');
        setModal(state.modal || null);
        setSelectedProductId(state.productId || null);
        
        // Reset transient states on navigation
        setItemToDelete(null);
        setSelectedOrderDetails(null);
        setShowOrderSuccessModal(false);
      });
      setTimeout(() => { isUpdatingFromHistory.current = false; }, 50);
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const changeState = useCallback((
    targetState: { view?: ViewType; modal?: ModalType | null; productId?: string | null },
    options: { replace?: boolean } = {}
  ) => {
    if (isUpdatingFromHistory.current) return;
    
    const currentState = { view, modal, productId: selectedProductId };
    const newState = { ...currentState, ...targetState };
    
    // Update React State First
    startTransition(() => {
        if (newState.view !== view) setView(newState.view);
        if (newState.modal !== modal) setModal(newState.modal);
        if (newState.productId !== selectedProductId) setSelectedProductId(newState.productId);
    });

    const url = newState.productId ? `?product_id=${newState.productId}` : window.location.pathname;
    if (options.replace || JSON.stringify(currentState) === JSON.stringify(newState)) {
        safeHistoryReplace(newState, url);
    } else {
        safeHistoryPush(newState, url);
    }
  }, [view, modal, selectedProductId]);

  const handleCloseOverlays = useCallback(() => {
    // If a product detail view is open, just deselect the product to go back to the grid.
    if (selectedProductId) {
        changeState({ productId: null });
        return;
    }
    // If any modal is open, just close it by setting modal state to null.
    if (modal) {
        changeState({ modal: null });
        return;
    }
  }, [selectedProductId, modal, changeState]);
  
  const handleCloseAdminPanel = useCallback(() => {
    // Replace the current state with the home view for a clean, reliable exit
    changeState({ view: 'HOME', modal: null, productId: null }, { replace: true });
  }, [changeState]);
  
  // Action Handlers
  const handleLogoClick = useCallback(() => changeState({ view: 'HOME', modal: null, productId: null }), [changeState]);
  const handleMenuClick = useCallback(() => changeState({ modal: modal === 'menu' ? null : 'menu' }), [modal, changeState]);
  const handleUserClick = useCallback(() => changeState({ modal: 'profile' }), [changeState]);
  const handleLoginClick = useCallback(() => changeState({ modal: 'auth' }), [changeState]);
  const handleCartClick = useCallback(() => changeState({ modal: modal === 'cart' ? null : 'cart' }), [modal, changeState]);
  const handleAboudToggle = useCallback(() => changeState({ modal: modal === 'aboud' ? null : 'aboud' }), [modal, changeState]);
  const handleProductClick = useCallback((p: Product) => changeState({ view: 'STORE', productId: p.id }), [changeState]);
  const handleFilterToggle = useCallback(() => changeState({ modal: modal === 'filters' ? null : 'filters' }), [modal, changeState]);
  const navigateToView = useCallback((v: ViewType) => changeState({ view: v, modal: null, productId: null }), [changeState]);
  
  const handleCategoryChange = useCallback((category: string) => { startTransition(() => { setActiveCategory(category); }); }, []);
  const handlePriceFilterChange = useCallback((price: number) => { startTransition(() => { setPriceFilter(price); }); }, []);
  const applyFilters = useCallback(() => { handlePriceFilterChange(tempPrice); handleCloseOverlays(); }, [tempPrice, handlePriceFilterChange, handleCloseOverlays]);
  const clearFilters = useCallback(() => { handleCategoryChange('الكل'); handlePriceFilterChange(45000); setTempPrice(45000); handleCloseOverlays(); }, [handleCategoryChange, handlePriceFilterChange, handleCloseOverlays]);
  
  const handleOpenAdminPanel = useCallback(async () => {
      setIsProcessingAdminData(true);
      try {
          setOrdersHistory(await getOrders(50));
          changeState({ view: 'ADMIN', modal: null });
      } catch (error: any) { setShowAlert({ message: `فشل تحميل البيانات: ${error.message}`, type: 'warning' }); } 
      finally { setIsProcessingAdminData(false); }
  }, [changeState]);

  const handleLogout = useCallback(async () => { 
    setIsLoggingOut(true);
    try { await withTimeout(supabase.auth.signOut(), 8000); } catch (e) { console.warn('SignOut error'); }
    finally {
      localStorage.clear(); sessionStorage.clear(); 
      setCurrentUser(null); setIsAdminLoggedIn(false); setIsOrderManagerLoggedIn(false); setCart([]);
      changeState({ view: 'HOME', modal: null, productId: null }, { replace: true });
      setIsLoggingOut(false);
      setShowAlert({ message: 'تم تسجيل الخروج بنجاح!', type: 'info' });
    }
  }, [changeState]);

  const handleConfirmDeletion = async () => {
    if (!itemToDelete) return;
    try {
      if (itemToDelete.type === 'product') { await deleteProduct(itemToDelete.id); setProducts(p => p.filter(prod => prod.id !== itemToDelete.id)); } 
      else if (itemToDelete.type === 'category') { await deleteCategory(itemToDelete.name); setCategories(c => c.filter(cat => cat !== itemToDelete.name)); setProducts(await getProducts()); }
      setShowAlert({ message: 'تم الحذف بنجاح.', type: 'info' });
    } catch (error: any) { setShowAlert({ message: `فشل الحذف: ${error.message}`, type: 'warning' }); }
    finally { setItemToDelete(null); }
  };

  const addToCart = useCallback((product: Product, size: string, color: string, quantity: number) => {
    if (!size || !color) { setShowAlert({ message: 'تنبيه: لم يتم اختيار اللون أو المقاس.', type: 'warning' }); return; }
    setCart(prev => {
        const existing = prev.find(i => i.id === product.id && i.selectedSize === size && i.selectedColor === color);
        if (existing) { return prev.map(i => i === existing ? { ...i, quantity: i.quantity + quantity } : i); }
        return [...prev, { ...product, quantity, selectedSize: size, selectedColor: color }];
    });
    changeState({ modal: 'cart' });
  }, [changeState]);

  const handleConfirmOrder = useCallback(async (info: { name: string; phone: string; address: string; notes: string; }) => {
    if (isConfirmingOrder) return;
    setIsConfirmingOrder(true);
    try {
      const shortId = `#${Date.now().toString().slice(-6)}`;
      const rec: OrderRecord = { orderId: shortId, timestamp: Date.now(), customerInfo: info, customerNotes: info.notes, cartItems: cart, totalAmount: cart.reduce((a, b) => a + (b.price * b.quantity), 0), deliveryFee: 5000, finalTotal: cart.reduce((a, b) => a + (b.price * b.quantity), 0) + 5000, userid: currentUser?.id, status: 'processing' };
      await saveOrderDirectly(rec);
      setCart([]); setLastOrderId(shortId);
      changeState({ modal: 'cart' }, { replace: true }); // Replace cart history to prevent going back
      setShowOrderSuccessModal(true);
      sendTelegramNotification(rec).catch(console.error);
    } catch (e: any) { setShowAlert({ message: `خطأ في تأكيد الطلب: ${e.message}`, type: 'warning' }); }
    finally { setIsConfirmingOrder(false); }
  }, [cart, currentUser?.id, isConfirmingOrder, changeState]);

  const filteredProducts = useMemo(() => {
    return products.filter(p => (activeCategory === 'الكل' || p.category === activeCategory) && p.price <= priceFilter);
  }, [products, activeCategory, priceFilter]);

  if (isLoading) return <LoadingScreen />;
  if (connectionError) return <div className="min-h-screen bg-[#FFFFFD] flex flex-col items-center justify-center p-6 text-center space-y-6 animate-fade-in fixed inset-0 z-[2000]"><div className="w-24 h-24 bg-red-100 rounded-full flex items-center justify-center animate-pulse"><span className="text-red-500 text-4xl">⚠️</span></div><h2 className="text-2xl font-bold uppercase">فشل الاتصال بالمتجر</h2><p className="text-gray-500 font-bold max-w-sm">يرجى التأكد من اتصالك بالإنترنت.</p><div className="flex flex-col gap-3"><button onClick={() => window.location.reload()} className="px-8 py-4 bg-black text-white rounded-2xl font-bold uppercase shadow-xl active:scale-95 transition-all">تحديث الصفحة</button><button onClick={async () => { await supabase.auth.signOut(); window.location.reload(); }} className="px-8 py-4 bg-white border border-red-200 text-red-600 rounded-2xl font-bold uppercase shadow-sm active:scale-95 transition-all flex items-center justify-center gap-3 hover:bg-red-50"><LogOut size={20}/>تسجيل الخروج</button></div></div>;
  if (isProcessingAdminData) return <div className="min-h-screen bg-[#FFFFFD] flex flex-col items-center justify-center animate-fade-in fixed inset-0 z-[1000]"><LoaderCircle size={48} className="animate-spin text-black mb-4"/><p className="font-bold text-lg">جاري تحضير لوحة التحكم...</p></div>;

  const MarqueeContent = () => (<><span className="mx-6 font-bold text-xs sm:text-sm tracking-widest whitespace-nowrap">{announcementText}</span><span className="mx-6 opacity-50 text-[10px]">✦</span><span className="mx-6 font-bold text-xs sm:text-sm tracking-widest whitespace-nowrap">{announcementText}</span><span className="mx-6 opacity-50 text-[10px]">✦</span><span className="mx-6 font-bold text-xs sm:text-sm tracking-widest whitespace-nowrap">{announcementText}</span><span className="mx-6 opacity-50 text-[10px]">✦</span><span className="mx-6 font-bold text-xs sm:text-sm tracking-widest whitespace-nowrap">{announcementText}</span><span className="mx-6 opacity-50 text-[10px]">✦</span></>);

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-[#FFFFFD] text-black text-sm" dir="rtl" style={{ fontFamily: "'Noto Naskh Arabic', serif" }}>
        
        {view !== 'ADMIN' && <Header onMenuClick={handleMenuClick} onLogoClick={handleLogoClick} currentUser={currentUser} onUserClick={handleUserClick} onLoginClick={handleLoginClick} cartItemCount={cart.reduce((a, b) => a + b.quantity, 0)} onCartClick={handleCartClick} />}
        
        <Alert showAlert={showAlert} onClose={() => setShowAlert(null)} />
        <div className="h-16"></div>
        
        {announcementText && view !== 'ADMIN' && !isOfferExpired && (
            <div style={{ backgroundColor: announcementBgColor, color: announcementTextColor }} className="overflow-hidden py-2 relative z-[10] shadow-md border-b border-white/10 flex select-none" dir="ltr">
                <div className="animate-marquee-infinite flex" style={{ animationDuration: `${announcementSpeed}s` }}><div className="flex shrink-0 items-center justify-around min-w-full"><MarqueeContent /></div><div className="flex shrink-0 items-center justify-around min-w-full"><MarqueeContent /></div></div>
            </div>
        )}

        {view === 'ADMIN' ? (
          <Suspense fallback={<div className="h-screen flex items-center justify-center"><LoaderCircle className="animate-spin" size={40}/></div>}>
              <AdminPanel products={products} categories={categories} orders={ordersHistory} onSaveProduct={async (p) => { await upsertProduct(p); setProducts(await getProducts()); return true; }} onDeleteProduct={(id, name) => setItemToDelete({ id, name, type: 'product' })} onCategoryUpdate={() => { getCategories().then(setCategories); getProducts().then(setProducts); }} onDeleteCategory={(id, name) => setItemToDelete({ id, name, type: 'category' })} onSaveSettings={async (s) => { await saveSettings(s); loadInitialData(true); }} initialHeroUrl={heroImageUrl} initialAnnouncement={announcementText} initialTimerEnabled={announcementTimerEnabled} initialDeadline={announcementDeadline} initialBgColor={announcementBgColor} initialTextColor={announcementTextColor} initialSpeed={announcementSpeed} initialTiktokUrl={tiktokUrl} initialInstagramUrl={instagramUrl} initialFacebookUrl={facebookUrl} initialWhatsappUrl={whatsappUrl} onViewOrderDetails={setSelectedOrderDetails} onClose={handleCloseAdminPanel} isSuperAdmin={isAdminLoggedIn} onShowAlert={setShowAlert} />
          </Suspense>
        ) : (
          <>
            <div className="content-visibility-auto">
              <main className="w-full">
                {selectedProduct ? (
                  <div className="max-w-[1400px] mx-auto px-4 md:px-10 py-8">
                    <Suspense fallback={<ComponentLoader />}>
                        <ProductDetail product={selectedProduct} onBack={handleCloseOverlays} onAddToCart={addToCart} onShowAlert={setShowAlert} />
                    </Suspense>
                  </div>
                ) : (
                  <MainContent pageType={view === 'STORE' ? 'STORE' : 'HOME'} onNavigateToStore={() => navigateToView('STORE')} heroImageUrl={heroImageUrl} productDisplayMode={productDisplayMode} setProductDisplayMode={setProductDisplayMode} activeCategory={activeCategory} filteredProducts={filteredProducts} onProductClick={handleProductClick} productsGridRef={productsGridRef} showTimer={announcementTimerEnabled && !isOfferExpired} deadline={announcementDeadline} allProducts={products} />
                )}
              </main>
              <Footer ref={footerRef} tiktokUrl={tiktokUrl} instagramUrl={instagramUrl} facebookUrl={facebookUrl} whatsappUrl={whatsappUrl} />
            </div>

            {view === 'STORE' && !selectedProduct && (
              <button onClick={handleFilterToggle} className="fixed bottom-6 right-6 z-[490] w-14 h-14 bg-white/20 backdrop-blur-md border border-white/20 text-black rounded-full flex items-center justify-center shadow-xl hover:bg-black hover:text-white transition-all active:scale-95 animate-slide-up"><SlidersHorizontal size={24} /></button>
            )}
            {showScrollTop && (
              <button onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} className="fixed bottom-24 right-6 z-[490] w-14 h-14 bg-white/20 backdrop-blur-md border border-white/20 text-black rounded-full flex items-center justify-center shadow-xl hover:bg-black hover:text-white transition-all animate-slide-up active:scale-95"><ChevronUp size={22}/></button>
            )}
            <AIChatWidget isOpen={modal === 'aboud'} onToggle={handleAboudToggle} products={products} currentUser={currentUser} onShowAlert={setShowAlert} />
          </>
        )}

        {/* --- MODALS & OVERLAYS --- */}
        {modal === 'menu' && (
          <>
            <div className="fixed inset-0 bg-black/5 backdrop-blur-sm z-[600] animate-fade-in" onClick={handleCloseOverlays} aria-hidden="true"></div>
            <div onClick={(e) => e.stopPropagation()} className="fixed top-20 right-4 w-[280px] sm:w-80 bg-[#FFFFFD]/65 backdrop-blur-[50px] z-[601] shadow-2xl p-6 flex flex-col gap-4 animate-slide-to-left rounded-[2rem] border border-white/40">
                <nav className="flex flex-col gap-3 text-right">
                  <button onClick={() => navigateToView('HOME')} className="group w-full text-right p-4 rounded-2xl hover:bg-black/5 transition-all flex items-center justify-between"><span className="font-bold text-base text-gray-800">الصفحة الرئيسية</span><div className="p-3 bg-white/40 rounded-full border border-black/5 group-hover:scale-110 transition-transform"><Activity size={20}/></div></button>
                  <button onClick={() => navigateToView('STORE')} className="group w-full text-right p-4 rounded-2xl hover:bg-black/5 transition-all flex items-center justify-between"><span className="font-bold text-base text-gray-800">المتجر</span><div className="p-3 bg-white/40 rounded-full border border-black/5 group-hover:scale-110 transition-transform"><Store size={20}/></div></button>
                  <button onClick={() => { handleCloseOverlays(); setTimeout(() => { footerRef.current?.scrollIntoView({ behavior: 'smooth' }); }, 250); }} className="group w-full text-right p-4 rounded-2xl hover:bg-black/5 transition-all flex items-center justify-between"><span className="font-bold text-base text-gray-800">حول VANTOR</span><div className="p-3 bg-white/40 rounded-full border border-black/5 group-hover:scale-110 transition-transform"><Info size={20}/></div></button>
                  <button onClick={() => changeState({ modal: 'privacy' })} className="group w-full text-right p-4 rounded-2xl hover:bg-black/5 transition-all flex items-center justify-between"><span className="font-bold text-base text-gray-800">سياسة الخصوصية</span><div className="p-3 bg-white/40 rounded-full border border-black/5 group-hover:scale-110 transition-transform"><ShieldCheck size={20}/></div></button>
                </nav>
            </div>
          </>
        )}

        {modal === 'auth' && <Suspense fallback={null}><AuthModal onClose={handleCloseOverlays} onAuthSuccess={() => { loadInitialData(true); handleCloseOverlays(); setShowAlert({ message: 'تم تسجيل الدخول بنجاح. أهلاً بك في VANTOR!', type: 'info' }); }} /></Suspense>}
        {modal === 'profile' && currentUser && <Suspense fallback={null}><ProfileView user={currentUser} onClose={handleCloseOverlays} onUpdateProfile={async (p) => { await updateUserProfile(p); handleCloseOverlays(); setShowAlert({ message: 'تم تحديث ملفك بنجاح!', type: 'info' }); }} onLogout={() => changeState({ modal: 'logoutConfirm' })} isAdmin={isAdminLoggedIn} isOrderManager={isOrderManagerLoggedIn} onAdminPanelClick={handleOpenAdminPanel} onViewOrderDetails={setSelectedOrderDetails} /></Suspense>}
        {modal === 'filters' && (
          <div className="fixed inset-0 z-[900] flex items-center justify-center p-4 bg-black/5 backdrop-blur-sm animate-fade-in" onClick={handleCloseOverlays}>
            <div onClick={(e) => e.stopPropagation()} className="bg-[#FFFFFD]/65 backdrop-blur-[50px] w-full max-w-lg p-6 sm:p-8 rounded-[2.5rem] shadow-2xl border border-white/40 animate-slide-up"><div className="flex flex-col gap-4 sm:gap-6 text-right"><div className="flex justify-between items-center border-b border-black/10 pb-2"><h3 className="font-bold text-lg uppercase">تصفية المنتجات</h3><button onClick={handleCloseOverlays} className="p-1.5 hover:bg-black/5 rounded-full transition-colors"><X size={20}/></button></div><div className="space-y-4"><p className="font-bold text-sm sm:text-base text-gray-700 uppercase tracking-widest text-right">الأقسام</p><div className="flex flex-wrap justify-center gap-2">{['الكل', ...categories].map(c => (<button key={c} onClick={() => handleCategoryChange(c)} className={`px-3 py-1.5 rounded-xl border font-bold text-sm transition-all active:scale-95 ${activeCategory === c ? 'bg-black text-white border-black' : 'bg-white/40 border-black/10 hover:border-black/30'}`}>{c}</button>))}</div></div><div className="space-y-4 pt-4 border-t border-black/10"><p className="font-bold text-sm sm:text-base text-gray-700 uppercase tracking-widest text-right">السعر: {Number(tempPrice).toLocaleString()} د.ع</p><div className="flex gap-2 items-center"><input type="range" min="25000" max="45000" step="5000" value={tempPrice} onChange={e => setTempPrice(Number(e.target.value))} className="flex-grow h-1.5 bg-black/10 rounded-lg appearance-none cursor-pointer accent-black" /></div></div><div className="flex gap-3 sm:gap-4 pt-4"><button onClick={applyFilters} className="flex-grow py-3.5 sm:py-4 bg-black text-white rounded-xl sm:rounded-2xl font-bold uppercase shadow-xl active:scale-95 transition-all text-sm border-b-4 border-gray-900">تطبيق التصفية</button><button onClick={clearFilters} className="px-8 sm:px-10 py-3.5 sm:py-4 bg-white/40 border border-black/10 rounded-xl sm:rounded-2xl font-bold text-gray-600 hover:text-black hover:bg-white/60 transition-all active:scale-95 text-sm">إلغاء التصفية</button></div></div></div>
          </div>
        )}
        {modal === 'cart' && !showOrderSuccessModal && <Suspense fallback={null}><Cart isOpen={modal === 'cart'} onClose={handleCloseOverlays} cartItems={cart} onUpdateQuantity={(id, s, c, delta) => setCart(prev => prev.map(item => item.id === id && item.selectedSize === s && item.selectedColor === c ? { ...item, quantity: item.quantity + delta } : item).filter(i => i.quantity > 0))} onRemoveItem={(id, s, c) => setCart(prev => prev.filter(i => !(i.id === id && i.selectedSize === s && i.selectedColor === c)))} onConfirmOrder={handleConfirmOrder} isConfirmingOrder={isConfirmingOrder} currentUser={currentUser} onShowAlert={setShowAlert} /></Suspense>}
        {modal === 'privacy' && <PrivacyPolicyModal onClose={handleCloseOverlays} />}
        
        {showOrderSuccessModal && <OrderSuccessModal orderId={lastOrderId} onClose={() => { setShowOrderSuccessModal(false); handleCloseOverlays(); }} />}
        <ConfirmationModal isOpen={modal === 'logoutConfirm'} onClose={handleCloseOverlays} onConfirm={handleLogout} title="تأكيد الخروج" confirmText="نعم" cancelText="إلغاء" isLoading={isLoggingOut}><p className="text-sm font-bold text-gray-700">هل أنت متأكد من تسجيل الخروج من VANTOR؟</p></ConfirmationModal>
        <ConfirmationModal isOpen={!!itemToDelete} onClose={() => setItemToDelete(null)} onConfirm={handleConfirmDeletion} title="تأكيد الحذف" confirmText="نعم، احذف" cancelText="إلغاء" isDestructive={true}><p className="text-sm font-bold text-gray-700">هل أنت متأكد من حذف "{itemToDelete?.name}"؟</p></ConfirmationModal>
        {selectedOrderDetails && <OrderDetailsModal order={selectedOrderDetails} onClose={() => setSelectedOrderDetails(null)} />}
      </div>
    </ErrorBoundary>
  );
}
