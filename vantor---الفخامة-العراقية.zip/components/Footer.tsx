
import React, { forwardRef } from 'react';
import { ShieldCheck, Instagram, Facebook, Phone, MessageCircle } from 'lucide-react';

interface FooterProps {
  tiktokUrl?: string;
  instagramUrl?: string;
  facebookUrl?: string;
  whatsappUrl?: string;
}

const Footer = forwardRef<HTMLElement, FooterProps>((props, ref) => {
  const { tiktokUrl, instagramUrl, facebookUrl, whatsappUrl } = props;
  const currentYear = new Date().getFullYear();

  return (
    <footer ref={ref} className="bg-black text-white py-12 sm:py-16 mt-12 sm:mt-16 md:mt-32 rounded-t-[2.5rem] sm:rounded-t-[3rem] text-center relative z-10" role="contentinfo">
      <div className="max-w-6xl mx-auto px-6 sm:px-8">
        <h2 className="text-2xl sm:text-3xl md:text-5xl lg:text-6xl font-bold uppercase mb-8 sm:mb-10 opacity-5 select-none tracking-tighter">VANTOR</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8 md:gap-16 text-right md:text-center items-start">
          <div className="space-y-3 sm:space-y-4">
            <h4 className="font-bold text-lg sm:text-xl uppercase tracking-widest border-b border-white/10 pb-1.5 sm:pb-2 inline-block">VANTOR</h4>
            <p className="text-xs sm:text-sm leading-relaxed font-bold text-white/90">أناقة عراقية حديثة وجودة عالمية من بغداد لكل العراق. نحن نؤمن بأن كل قطعة يجب أن تحكي قصة نجاح وتميز.</p>
          </div>
          <div className="flex flex-col items-center justify-center">
            <div className="p-6 sm:p-8 bg-white/5 rounded-2xl sm:rounded-3xl border border-white/10 shadow-xl mb-3 sm:mb-4 group hover:scale-105 transition-transform"><ShieldCheck size={36} className="text-white"/></div>
            <p className="text-[9px] sm:text-[10px] font-bold uppercase tracking-[0.2em] sm:tracking-[0.3em] text-white opacity-100">جودة التفاصيل والضمان</p>
          </div>
          <div className="space-y-3 sm:space-y-4">
            <h4 className="font-bold text-lg sm:text-xl uppercase tracking-widest border-b border-white/10 pb-1.5 sm:pb-2 inline-block">تواصل معنا</h4>
            <div className="flex justify-start md:justify-center gap-4 sm:gap-6 flex-wrap">
              {instagramUrl && (
                  <a href={instagramUrl} target="_blank" rel="noopener noreferrer" className="hover:scale-110 transition-transform bg-white/5 p-3 sm:p-4 rounded-xl sm:rounded-2xl border border-white/10 shadow-lg" aria-label="صفحة انستغرام"><Instagram size={22}/></a>
              )}
              {facebookUrl && (
                  <a href={facebookUrl} target="_blank" rel="noopener noreferrer" className="hover:scale-110 transition-transform bg-white/5 p-3 sm:p-4 rounded-xl sm:rounded-2xl border border-white/10 shadow-lg" aria-label="صفحة فيسبوك"><Facebook size={22}/></a>
              )}
              {whatsappUrl && (
                  <a href={whatsappUrl} target="_blank" rel="noopener noreferrer" className="hover:scale-110 transition-transform bg-white/5 p-3 sm:p-4 rounded-xl sm:rounded-2xl border border-white/10 shadow-lg" aria-label="واتساب"><MessageCircle size={22}/></a>
              )}
              {tiktokUrl && (
                  <a href={tiktokUrl} target="_blank" rel="noopener noreferrer" className="hover:scale-110 transition-transform bg-white/5 p-3 sm:p-4 rounded-xl sm:rounded-2xl border border-white/10 shadow-lg" aria-label="صفحة تيك توك">
                    <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M9 12a4 4 0 1 0 4 4V4a5 5 0 0 0 5 5"/>
                    </svg>
                  </a>
              )}
            </div>
          </div>
        </div>
        <div className="pt-12 sm:pt-16 border-t border-white/10 mt-10 sm:mt-12 text-white font-bold text-[10px] sm:text-xs uppercase tracking-[0.3em] sm:tracking-[0.4em] opacity-100">
          كل الحقوق محفوظة لـ VANTOR © {currentYear}
        </div>
      </div>
    </footer>
  );
});

Footer.displayName = "Footer";

export default Footer;
