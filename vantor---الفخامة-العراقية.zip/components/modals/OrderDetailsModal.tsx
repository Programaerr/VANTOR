import React from 'react';
import { OrderRecord } from '../../types';
import { X } from 'lucide-react';

interface OrderDetailsModalProps {
  order: OrderRecord;
  onClose: () => void;
}

export default function OrderDetailsModal({ order, onClose }: OrderDetailsModalProps) {
  return (
    <div className="fixed inset-0 z-[1100] flex items-center justify-center p-4 bg-black/5 backdrop-blur-sm animate-fade-in" role="dialog" aria-modal="true" onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} className="bg-[#FFFFFD]/65 backdrop-blur-[50px] w-full max-w-2xl max-h-[90vh] p-6 rounded-3xl shadow-2xl border border-white/40 animate-slide-up text-right space-y-4 flex flex-col">
          <div className="flex justify-between items-center border-b border-black/10 pb-3 flex-shrink-0">
              <h3 className="text-lg font-bold uppercase tracking-tight">تفاصيل الطلب <span className="font-mono text-gray-500">#{order.orderId.slice(-6)}</span></h3>
              <button onClick={onClose} className="p-1.5 text-black hover:bg-black/10 rounded-full"><X size={20}/></button>
          </div>
          <div className="overflow-y-auto custom-scrollbar -mr-2 pr-2 space-y-4">
            <div className="bg-white/40 backdrop-blur-md p-4 rounded-xl border border-black/5">
                <h4 className="font-bold mb-2">معلومات الزبون</h4>
                <p className="text-sm"><b>الاسم:</b> {order.customerInfo.name}</p>
                <p className="text-sm"><b>الهاتف:</b> {order.customerInfo.phone}</p>
                <p className="text-sm"><b>العنوان:</b> {order.customerInfo.address}</p>
                {order.customerNotes && (
                  <p className="text-sm pt-2 mt-2 border-t border-black/5"><b>ملاحظات:</b> {order.customerNotes}</p>
                )}
            </div>
            <div className="bg-white/40 backdrop-blur-md p-4 rounded-xl border border-black/5 space-y-3">
                 <h4 className="font-bold">المنتجات المطلوبة</h4>
                 {order.cartItems.map((item, index) => (
                     <div key={index} className="flex gap-3 items-center border-b border-black/5 pb-3 last:border-b-0">
                         <img src={item.images[0]} alt={item.name} className="w-16 h-16 object-cover rounded-lg"/>
                         <div className="flex-grow">
                             <p className="font-bold text-sm">{item.name}</p>
                             <p className="text-xs text-gray-500">
                                 المقاس: {item.selectedSize} | اللون: 
                                 <span className="inline-block w-3 h-3 rounded-full align-middle mx-1 border border-black/10" style={{backgroundColor: item.selectedColor}}></span>
                                 <span className="font-mono text-gray-700" dir="ltr">{item.selectedColor}</span>
                             </p>
                         </div>
                         <div className="text-left">
                             <p className="font-bold text-sm">x{item.quantity}</p>
                             <p className="text-xs">{item.price.toLocaleString()} د.ع</p>
                         </div>
                     </div>
                 ))}
            </div>
             <div className="bg-white/40 backdrop-blur-md p-4 rounded-xl border border-black/5 font-bold space-y-2">
                 <div className="flex justify-between text-sm"><span>المجموع الفرعي:</span><span>{order.totalAmount.toLocaleString()} د.ع</span></div>
                 <div className="flex justify-between text-sm"><span>كلفة التوصيل:</span><span>{order.deliveryFee.toLocaleString()} د.ع</span></div>
                 <div className="flex justify-between text-lg border-t border-black/10 pt-2 mt-2"><span>المجموع النهائي:</span><span>{order.finalTotal.toLocaleString()} د.ع</span></div>
             </div>
          </div>
      </div>
    </div>
  );
}