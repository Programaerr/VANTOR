import React from 'react';
import { Check, X, Copy } from 'lucide-react';

interface OrderSuccessModalProps {
  orderId: string;
  onClose: () => void;
}

export default function OrderSuccessModal({ orderId, onClose }: OrderSuccessModalProps) {
  const handleCopyId = () => {
    navigator.clipboard.writeText(orderId);
    // You might want to use a toast here instead of alert in production, 
    // but keeping it simple as per original logic if no toast system is passed.
    alert('تم نسخ رمز الطلب بنجاح');
  };

  return (
    <div className="fixed inset-0 z-[1100] flex items-center justify-center p-4 bg-black/40 backdrop-blur-md animate-fade-in" role="dialog" aria-modal="true">
        <div onClick={(e) => e.stopPropagation()} className="bg-[#FFFFFD] w-full max-w-md p-8 sm:p-12 rounded-[3rem] shadow-2xl border-4 border-white animate-slide-up text-center space-y-6 relative overflow-hidden">
            {/* Decoration */}
            <div className="absolute top-0 inset-x-0 h-3 bg-gradient-to-r from-green-500 via-green-600 to-green-500"></div>
            
            <button onClick={onClose} className="absolute top-6 right-6 p-3 bg-white rounded-full text-black hover:bg-black hover:text-white transition-all shadow-md active:scale-90 border border-black/5" aria-label="إغلاق">
                <X size={20}/>
            </button>

            <div className="w-24 h-24 sm:w-28 sm:h-28 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto border-4 border-white shadow-xl">
                <Check size={56} className="animate-bounce stroke-[3px]" />
            </div>

            <div className="space-y-3">
                <h3 className="text-3xl sm:text-4xl font-black uppercase tracking-tighter text-black leading-none">تم استلام طلبك بنجاح</h3>
                <p className="text-base sm:text-lg font-bold text-gray-800">شكراً لاختيارك VANTOR للأزياء الفاخرة</p>
            </div>

            {/* Order Code Card - Solid Background for clarity */}
            <div className="bg-white p-6 rounded-[2.5rem] border-2 border-black/5 shadow-inner space-y-2">
                <p className="text-xs font-bold text-gray-500 uppercase tracking-widest">رمز الطلب الخاص بك</p>
                <div className="flex items-center justify-center gap-3">
                    <span className="text-3xl sm:text-4xl font-black font-price text-black tracking-widest">{orderId}</span>
                    <button onClick={handleCopyId} className="p-2.5 bg-gray-100 text-gray-500 hover:text-black hover:bg-gray-200 rounded-xl transition-colors" title="نسخ الرمز">
                        <Copy size={20}/>
                    </button>
                </div>
            </div>

            <div className="space-y-5 pt-2">
                <p className="text-sm font-bold text-black leading-relaxed px-4">
                    يرجى الاحتفاظ بهذا الرمز لمراجعة حالة طلبك لاحقاً.
                    <br />
                    <span className="text-green-700 font-extrabold">سوف يتصل بك فريقنا خلال 24 ساعة لتأكيد التفاصيل.</span>
                </p>
                
                <button 
                    onClick={onClose} 
                    className="w-full py-5 bg-black text-white rounded-[2rem] font-bold text-lg uppercase shadow-2xl hover:bg-gray-900 transition-all active:scale-95 border-b-4 border-gray-800"
                >
                    حسناً، فهمت
                </button>
            </div>

            <p className="text-[11px] text-gray-400 font-bold uppercase tracking-widest">فريق VANTOR بخدمتكم دائماً</p>
        </div>
    </div>
  );
}