import React from 'react';
import { AlertTriangle, Trash2, LoaderCircle } from 'lucide-react';

interface ConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void | Promise<void>;
  title: string;
  confirmText: string;
  cancelText: string;
  isDestructive?: boolean;
  children?: React.ReactNode;
  isLoading?: boolean;
}

export default function ConfirmationModal({
  isOpen, onClose, onConfirm, title, confirmText, cancelText, isDestructive = false, children,
  isLoading = false
}: ConfirmationModalProps) {
  if (!isOpen) return null;

  const handleConfirmClick = async () => {
    await onConfirm();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4 sm:p-6 bg-black/5 backdrop-blur-md" role="dialog" aria-modal="true" onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} className="bg-[#FFFFFD] w-full max-w-sm p-6 sm:p-10 rounded-[2rem] sm:rounded-[2.5rem] shadow-2xl border-4 border-black/5 text-center space-y-6 sm:space-y-8 animate-slide-up">
        {isDestructive && (
          <div className="w-16 h-16 sm:w-20 sm:h-20 bg-red-50 text-red-500 rounded-full flex items-center justify-center mx-auto border-2 border-red-100">
            <Trash2 size={32} />
          </div>
        )}
        <h3 className="text-xl sm:text-2xl font-bold uppercase tracking-tighter">{title}</h3>
        {children}
        <div className="flex gap-3 sm:gap-4 pt-4">
          <button
            onClick={handleConfirmClick}
            disabled={isLoading}
            className="flex-grow py-3.5 sm:py-4 bg-black text-white rounded-xl sm:rounded-2xl font-bold uppercase shadow-xl active:scale-95 transition-all text-sm border-b-4 border-gray-900 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
          >
            {isLoading ? <LoaderCircle size={22} className="animate-spin" /> : confirmText}
          </button>
          <button onClick={onClose} className="px-8 sm:px-10 py-3.5 sm:py-4 bg-white border border-black/10 rounded-xl sm:rounded-2xl font-bold text-gray-400 hover:text-black transition-all active:scale-95 text-sm">
            {cancelText}
          </button>
        </div>
      </div>
    </div>
  );
}