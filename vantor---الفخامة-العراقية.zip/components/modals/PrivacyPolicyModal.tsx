
import React, { useState } from 'react';
import { X } from 'lucide-react';

interface PrivacyPolicyModalProps {
  onClose: () => void;
}

export default function PrivacyPolicyModal({ onClose }: PrivacyPolicyModalProps) {
  return (
    <div className="fixed inset-0 z-[1100] flex items-center justify-center p-4 bg-black/5 backdrop-blur-sm animate-fade-in" role="dialog" aria-modal="true" onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} className="bg-[#FFFFFD] w-full max-w-2xl max-h-[90vh] p-6 rounded-3xl shadow-2xl border border-black/5 animate-slide-up text-right space-y-4 flex flex-col">
        <div className="flex justify-between items-center border-b border-black/10 pb-3 flex-shrink-0">
          <h3 className="text-xl sm:text-2xl font-bold uppercase tracking-tight">سياسة الخصوصية والأمان</h3>
          <button onClick={onClose} className="p-1.5 text-black hover:bg-black/10 rounded-full" aria-label="إغلاق"><X size={20}/></button>
        </div>
        <div className="overflow-y-auto custom-scrollbar -mr-2 pr-2 space-y-4 text-sm sm:text-base leading-relaxed font-bold text-gray-800">
          <p>في VANTOR، نولي خصوصيتك وأمان بياناتك أهمية قصوى. تهدف هذه السياسة إلى توضيح كيفية جمعنا واستخدامنا وحمايتنا للمعلومات التي تقدمها لنا.</p>

          <h4 className="font-bold text-lg mt-6 mb-2">1. المعلومات التي نجمعها</h4>
          <p>نجمع المعلومات التي تزودنا بها طواعية عند إجراء طلب أو تسجيل حساب، وتشمل:</p>
          <ul className="list-disc pr-6 space-y-1">
            <li>الاسم الكامل.</li>
            <li>عنوان البريد الإلكتروني.</li>
            <li>رقم الهاتف.</li>
            <li>عنوان التوصيل بالتفصيل.</li>
            <li>تفاصيل المنتجات التي تم طلبها (الكمية، المقاس، اللون، السعر).</li>
          </ul>

          <h4 className="font-bold text-lg mt-6 mb-2">2. كيفية استخدامنا للمعلومات</h4>
          <p>نستخدم معلوماتك للأغراض التالية:</p>
          <ul className="list-disc pr-6 space-y-1">
            <li>معالجة وتأكيد طلباتك وتسليم المنتجات.</li>
            <li>التواصل معك حول حالة طلبك.</li>
            <li>تحسين تجربتك في التسوق وخدماتنا.</li>
            <li>إدارة حسابك إذا كنت مسجلاً لدينا.</li>
            <li>أغراض التحليلات الداخلية لتحسين المتجر.</li>
          </ul>

          <h4 className="font-bold text-lg mt-6 mb-2">3. مشاركة المعلومات</h4>
          <p>نحن لا نبيع أو نتاجر أو نؤجر معلوماتك الشخصية لأطراف ثالثة. يتم استخدام بيانات الطلبات (الاسم، الهاتف، العنوان، تفاصيل الطلب) حصراً لغرض معالجة الطلب وتسهيل عملية التوصيل، مع ضمان حمايتها من أي وصول غير مصرح به.</p>
          <p>جميع بيانات المستخدمين والمنتجات والطلبات يتم تخزينها بشكل آمن ومشفر ضمن أنظمتنا السحابية المحمية بأعلى معايير الأمان العالمية لضمان حماية خصوصيتك التامة.</p>

          <h4 className="font-bold text-lg mt-6 mb-2">4. أمن البيانات</h4>
          <p>نتخذ تدابير أمنية تقنية وإدارية صارمة لحماية معلوماتك الشخصية من الوصول غير المصرح به أو التعديل أو الكشف أو التلف. تشمل هذه التدابير حماية كلمات المرور، وتشفير البيانات الحساسة، وضمان أمان الخوادم التي نستضيف عليها البيانات.</p>

          <h4 className="font-bold text-lg mt-6 mb-2">5. حقوقك</h4>
          <p>لديك الحق في الوصول إلى معلوماتك الشخصية التي نحتفظ بها وتصحيحها أو طلب حذفها. يمكنك تحديث بيانات ملفك الشخصي في أي وقت من خلال لوحة التحكم الخاصة بحسابك. لأي طلبات أخرى تتعلق ببياناتك، يرجى التواصل مع فريق الدعم لدينا.</p>

          <h4 className="font-bold text-lg mt-6 mb-2">6. التغييرات على سياسة الخصوصية</h4>
          <p>قد نقوم بتحديث سياسة الخصوصية هذه من وقت لآخر لمواكبة التطورات التقنية والقانونية. سيتم نشر أي تغييرات هنا، ونشجعك على مراجعتها بانتظام لتبقى على اطلاع بكيفية حمايتنا لبياناتك.</p>

          <h4 className="font-bold text-lg mt-6 mb-2">7. الاتصال بنا</h4>
          <p>إذا كان لديك أي استفسارات أو مخاوف حول سياسة الخصوصية هذه، يرجى التواصل معنا عبر القنوات الرسمية المتاحة في المتجر.</p>
        </div>
      </div>
    </div>
  );
}
