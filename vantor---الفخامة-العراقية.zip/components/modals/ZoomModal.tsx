
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';

interface ZoomModalProps {
  isOpen: boolean;
  images: string[];
  startIndex: number;
  onClose: () => void;
}

export default function ZoomModal({ isOpen, images, startIndex, onClose }: ZoomModalProps) {
  const [currentIndex, setCurrentIndex] = useState(startIndex);
  const imageRef = useRef<HTMLImageElement>(null);
  
  // الحالة الحالية للتحويل (تستخدم Ref لتجنب إعادة الرسم المتكرر أثناء الحركة السريعة)
  const transform = useRef({ scale: 1, x: 0, y: 0 });
  const gesture = useRef({
    startX: 0,
    startY: 0,
    startDistance: 0,
    initialScale: 1,
    isPinching: false,
    isPanning: false,
    pointers: [] as {id: number, x: number, y: number}[]
  });

  // تحديث الصورة المعروضة عند الفتح
  useEffect(() => {
    if (isOpen) {
        setCurrentIndex(startIndex);
        resetZoom();
        document.body.style.overflow = 'hidden';
    } else {
        document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [isOpen, startIndex]);

  // دالة تطبيق التغييرات على الصورة مباشرة
  const updateImageTransform = () => {
      if (imageRef.current) {
          const { x, y, scale } = transform.current;
          imageRef.current.style.transform = `translate(${x}px, ${y}px) scale(${scale})`;
      }
  };

  const resetZoom = () => {
      transform.current = { scale: 1, x: 0, y: 0 };
      updateImageTransform();
  };

  const handleNext = useCallback(() => {
    if (currentIndex < images.length - 1) {
        setCurrentIndex(prev => prev + 1);
        resetZoom();
    }
  }, [currentIndex, images.length]);

  const handlePrev = useCallback(() => {
    if (currentIndex > 0) {
        setCurrentIndex(prev => prev - 1);
        resetZoom();
    }
  }, [currentIndex]);

  // حساب المسافة بين نقطتين (لللمس المتعدد)
  const getDistance = (touches: React.TouchList) => {
      return Math.hypot(
          touches[0].clientX - touches[1].clientX,
          touches[0].clientY - touches[1].clientY
      );
  };

  // --- معالجة أحداث اللمس (Touch Events) ---

  const handleTouchStart = (e: React.TouchEvent) => {
      if (e.touches.length === 2) {
          // بداية التكبير (أصبعين)
          gesture.current.isPinching = true;
          gesture.current.startDistance = getDistance(e.touches);
          gesture.current.initialScale = transform.current.scale;
      } else if (e.touches.length === 1) {
          // بداية التحريك أو السحب (أصبع واحد)
          gesture.current.isPanning = true;
          gesture.current.startX = e.touches[0].clientX - transform.current.x;
          gesture.current.startY = e.touches[0].clientY - transform.current.y;
      }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
      e.preventDefault(); // منع المتصفح من التدخل

      if (e.touches.length === 2 && gesture.current.isPinching) {
          // منطق التكبير (Pinch Zoom)
          const newDistance = getDistance(e.touches);
          const scaleFactor = newDistance / gesture.current.startDistance;
          // تحديد الحد الأدنى والأقصى للتكبير (1x إلى 4x)
          const newScale = Math.min(Math.max(gesture.current.initialScale * scaleFactor, 1), 4);
          
          transform.current.scale = newScale;
          
          // إذا رجعنا للحجم الطبيعي، نصفر الإحداثيات
          if (newScale === 1) {
              transform.current.x = 0;
              transform.current.y = 0;
          }
          updateImageTransform();

      } else if (e.touches.length === 1 && gesture.current.isPanning) {
          // منطق التحريك (Pan)
          const x = e.touches[0].clientX - gesture.current.startX;
          const y = e.touches[0].clientY - gesture.current.startY;

          if (transform.current.scale > 1) {
              // إذا مكبرة: تحريك حر للصورة
              // (يمكن إضافة حدود هنا لمنع الصورة من الخروج كلياً)
              transform.current.x = x;
              transform.current.y = y;
              updateImageTransform();
          } else {
              // إذا الحجم طبيعي: سحب للتغيير (Swipe Logic Visual Feedback)
              // نسمح بحركة أفقية بسيطة كتأثير بصري
              transform.current.x = x * 0.5; // مقاومة للحركة
              updateImageTransform();
          }
      }
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
      if (gesture.current.isPinching) {
          gesture.current.isPinching = false;
          // إذا كان التكبير أقل من 1 (تصغير زائد)، نرجعه للطبيعي
          if (transform.current.scale < 1) {
              resetZoom();
          }
      } else if (gesture.current.isPanning) {
          gesture.current.isPanning = false;

          // منطق السحب للتغيير (فقط إذا لم يكن هناك تكبير)
          if (transform.current.scale === 1) {
              const movedX = transform.current.x;
              const threshold = 100; // مسافة السحب المطلوبة

              if (movedX < -threshold) {
                  handleNext();
              } else if (movedX > threshold) {
                  handlePrev();
              } else {
                  // ارتداد للمكان الأصلي إذا لم يكتمل السحب
                  transform.current.x = 0;
                  updateImageTransform();
              }
          }
      }
  };

  if (!isOpen) return null;

  return createPortal(
    <div
      className="fixed inset-0 z-[9999] bg-black/95 touch-none animate-fade-in flex flex-col"
      role="dialog"
      aria-modal="true"
    >
      {/* الشريط العلوي: العداد وزر الإغلاق */}
      <div className="absolute top-0 inset-x-0 p-4 flex justify-between items-center z-50 pointer-events-none">
         <span className="bg-black/40 backdrop-blur-md text-white/90 px-3 py-1 rounded-full text-xs font-bold font-mono border border-white/10">
            {currentIndex + 1} / {images.length}
         </span>
         <button
          onClick={onClose}
          className="p-3 rounded-full bg-white/10 text-white hover:bg-white/20 hover:text-red-500 transition-colors backdrop-blur-md border border-white/10 pointer-events-auto active:scale-90"
          aria-label="إغلاق"
        >
          <X size={24} />
        </button>
      </div>

      {/* منطقة الصورة الرئيسية */}
      <div 
        className="flex-grow flex items-center justify-center overflow-hidden w-full h-full relative"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
         {/* أزرار التنقل الجانبية (تظهر فقط إذا لم يكن هناك تكبير) */}
         {transform.current.scale === 1 && (
             <>
                {currentIndex > 0 && (
                    <button 
                        onClick={(e) => { e.stopPropagation(); handlePrev(); }} 
                        className="absolute left-4 p-3 bg-white/10 text-white rounded-full hover:bg-white/20 z-40 backdrop-blur-md transition-opacity"
                    >
                        <ChevronLeft size={32}/>
                    </button>
                )}
                {currentIndex < images.length - 1 && (
                    <button 
                        onClick={(e) => { e.stopPropagation(); handleNext(); }} 
                        className="absolute right-4 p-3 bg-white/10 text-white rounded-full hover:bg-white/20 z-40 backdrop-blur-md transition-opacity"
                    >
                        <ChevronRight size={32}/>
                    </button>
                )}
             </>
         )}

         <img
          ref={imageRef}
          src={images[currentIndex]}
          alt="Zoomed"
          draggable={false}
          className="max-w-full max-h-full object-contain select-none will-change-transform transition-transform duration-75 ease-linear"
          style={{ transformOrigin: 'center center' }}
        />
      </div>
    </div>,
    document.body
  );
}
