import React, { useState, useEffect } from 'react';
import { CartItem, CurrentUser } from '../types';
import { Minus, Plus, LoaderCircle, MapPin, WalletCards, X, ShoppingBag, CheckCircle2 } from 'lucide-react';

interface CartProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (id: string, size: string, color: string, delta: number) => void;
  onRemoveItem: (id: string, size: string, color: string) => void;
  onConfirmOrder: (customerInfo: { name: string, phone: string, address: string, notes: string }) => Promise<void>;
  isConfirmingOrder: boolean;
  currentUser: CurrentUser | null;
  onShowAlert: (alert: { message: string, type: 'warning' | 'info' }) => void;
}

export default function Cart({
  isOpen, onClose, cartItems, onUpdateQuantity, onRemoveItem,
  onConfirmOrder, isConfirmingOrder, currentUser, onShowAlert
}: CartProps) {
  const [orderName, setOrderName] = useState('');
  const [orderPhone, setOrderPhone] = useState('');
  const [orderAddress, setOrderAddress] = useState('');
  const [orderNotes, setOrderNotes] = useState('');
  const [cartFormErrors, setCartFormErrors] = useState<{name?: boolean, phone?: boolean, address?: boolean}>({});
  const [isClosing, setIsClosing] = useState(false);

  useEffect(() => {
    if (currentUser) {
      setOrderName(currentUser.name || '');
      setOrderPhone(currentUser.phone || '');
      setOrderAddress(currentUser.address || '');
    } else {
      setOrderName(''); setOrderPhone(''); setOrderAddress('');
    }
    setOrderNotes('');
  }, [currentUser, isOpen]);

  const handleClose = () => {
    setIsClosing(true);
    setTimeout(() => {
      onClose();
      setIsClosing(false);
    }, 200); 
  };

  const handleConfirm = () => {
    setCartFormErrors({});
    const errors: { name?: boolean; phone?: boolean; address?: boolean } = {};
    let alertMessage = '';
    if (!orderName.trim()) { errors.name = true; alertMessage = 'تنبيه: يرجى إدخال الاسم الكامل.'; }
    if (!orderAddress.trim()) { errors.address = true; alertMessage = 'تنبيه: يرجى إدخال عنوان التوصيل.'; }
    const phoneClean = orderPhone.trim();
    if (!phoneClean || !/^07[0-9]{9}$/.test(phoneClean)) { 
        errors.phone = true; 
        alertMessage = 'تنبيه: يجب أن يكون الرقم 11 رقماً ويبدأ بـ 07.'; 
    }
    if (Object.keys(errors).length > 0) { 
        setCartFormErrors(errors); 
        onShowAlert({ message: alertMessage, type: 'warning' }); 
        return; 
    }
    onConfirmOrder({ name: orderName, phone: orderPhone, address: orderAddress, notes: orderNotes });
  };
  
  // دالة للتنقل بين الحقول باستخدام Enter
  const handleKeyDown = (e: React.KeyboardEvent, nextElementId?: string, isSubmit: boolean = false) => {
      if (e.key === 'Enter') {
          e.preventDefault();
          if (isSubmit) {
              handleConfirm();
          } else if (nextElementId) {
              const el = document.getElementById(nextElementId);
              if (el) el.focus();
          }
      }
  };

  if (!isOpen) return null;

  const totalAmount = cartItems.reduce((a, b) => a + (Number(b.price) * b.quantity), 0);
  const finalTotal = totalAmount + 5000;

  return (
    <>
      <div 
        className={`fixed inset-0 z-[485] bg-black/5 backdrop-blur-sm transition-opacity duration-200 ${isClosing ? 'animate-fade-out' : 'animate-fade-in'}`} 
        onClick={handleClose} 
        aria-hidden="true"
      ></div>
      
      <div className="fixed inset-0 z-[490] flex justify-center items-start pt-16 md:pt-20 pointer-events-none">
        <div 
          onClick={(e) => e.stopPropagation()} 
          className={`pointer-events-auto w-[90%] max-w-[420px] max-h-[85vh] flex flex-col bg-[#FFFFFD]/65 backdrop-blur-[50px] shadow-[0_20px_60px_rgba(0,0,0,0.1)] rounded-[2.5rem] border border-white/40 overflow-hidden ${isClosing ? 'animate-slide-up-exit' : 'animate-slide-down-enter'}`} 
          role="dialog"
        >
          <div className="flex justify-end items-center p-4 pb-0 flex-shrink-0 z-10">
               <button onClick={handleClose} className="w-8 h-8 rounded-full bg-[#FFFFFD]/50 backdrop-blur-md flex items-center justify-center border border-black/5 hover:bg-black hover:text-white transition-all shadow-sm active:scale-90 group">
                  <X size={16} className="group-hover:rotate-90 transition-transform duration-200" />
               </button>
          </div>

          <div className="flex-grow overflow-y-auto custom-scrollbar p-5 pt-0 space-y-5">
              {cartItems.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-[40vh] gap-4 opacity-60">
                    <div className="w-20 h-20 rounded-[2rem] bg-[#FFFFFD]/50 backdrop-blur-md flex items-center justify-center border border-black/5 shadow-sm">
                        <ShoppingBag size={32} className="text-black/70"/>
                    </div>
                    <span className="font-bold text-base text-black/70 tracking-tight">الحقيبة فارغة</span>
                </div>
              ) : (
                <div className="space-y-2.5 pt-1">
                  {cartItems.map((item, idx) => (
                    <div key={idx} className="flex gap-3 bg-white/60 backdrop-blur-md p-3 rounded-[1.8rem] border border-white/50 shadow-sm relative group overflow-hidden">
                      <img src={item.images[0]} alt={item.name} className="w-14 h-16 object-cover rounded-2xl shadow-sm border border-black/5" />
                      <div className="flex-grow flex flex-col justify-between py-0.5">
                        <div className="flex justify-between items-start">
                           <div className="space-y-0.5">
                              <h4 className="font-bold text-xs text-gray-900 leading-tight">{item.name}</h4>
                              <div className="flex gap-1 items-center">
                                  <span className="text-[8px] bg-black text-white px-2 py-0.5 rounded-md font-bold uppercase">{item.selectedSize}</span>
                                  <span className="w-3 h-3 rounded-full border border-black/10" style={{backgroundColor: item.selectedColor}}></span>
                              </div>
                           </div>
                           <button onClick={() => onRemoveItem(item.id, item.selectedSize, item.selectedColor)} className="text-gray-400 p-1 hover:text-red-500 transition-all"><X size={14}/></button>
                        </div>
                        <div className="flex items-end justify-between mt-1">
                            <div className="font-price font-bold text-sm tracking-tight text-black">{(Number(item.price) * item.quantity).toLocaleString()} <span className="text-[9px] text-gray-500">د.ع</span></div>
                            <div className="flex items-center gap-1 bg-[#FFFFFD]/50 p-1 rounded-xl border border-black/5">
                              <button onClick={() => onUpdateQuantity(item.id, item.selectedSize, item.selectedColor, -1)} className="w-5 h-5 flex items-center justify-center hover:bg-gray-100 rounded-lg active:scale-90"><Minus size={10}/></button>
                              <span className="font-price font-bold text-[10px] min-w-[15px] text-center">{item.quantity}</span>
                              <button onClick={() => onUpdateQuantity(item.id, item.selectedSize, item.selectedColor, 1)} className="w-5 h-5 flex items-center justify-center hover:bg-gray-100 rounded-lg active:scale-90"><Plus size={10}/></button>
                            </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {cartItems.length > 0 && (
                  <div className="bg-white/50 backdrop-blur-xl p-5 rounded-[2.2rem] border border-white/60 space-y-4 shadow-lg">
                     <div className="flex items-center gap-1.5 px-1">
                        <MapPin size={14} className="text-black"/>
                        <span className="text-[10px] font-bold uppercase text-black/70">معلومات الزبون</span>
                     </div>
                     <div className="space-y-2">
                          <input 
                            id="cart-name"
                            value={orderName} 
                            onChange={e => setOrderName(e.target.value)} 
                            onKeyDown={(e) => handleKeyDown(e, 'cart-phone')}
                            placeholder="الاسم الكامل" 
                            className={`w-full p-3.5 rounded-2xl bg-[#FFFFFD]/50 border outline-none font-bold text-xs transition-all placeholder:text-gray-500 ${cartFormErrors.name ? 'border-red-500' : 'border-black/5 focus:border-black/20'}`} 
                          />
                          <div className="flex gap-2">
                               <input 
                                id="cart-phone"
                                type="tel" 
                                value={orderPhone} 
                                onChange={e => setOrderPhone(e.target.value.replace(/[^0-9]/g, '').slice(0, 11))} 
                                onKeyDown={(e) => handleKeyDown(e, 'cart-address')}
                                placeholder="الهاتف 07" 
                                className={`w-1/2 p-3.5 rounded-2xl bg-[#FFFFFD]/50 border outline-none font-bold text-xs text-left placeholder:text-gray-500 ${cartFormErrors.phone ? 'border-red-500' : 'border-black/5 focus:border-black/20'}`} 
                                dir="ltr" 
                               />
                               <input 
                                id="cart-address"
                                value={orderAddress} 
                                onChange={e => setOrderAddress(e.target.value)} 
                                onKeyDown={(e) => handleKeyDown(e, 'cart-notes')}
                                placeholder="المحافظة / العنوان" 
                                className={`w-1/2 p-3.5 rounded-2xl bg-[#FFFFFD]/50 border outline-none font-bold text-xs placeholder:text-gray-500 ${cartFormErrors.address ? 'border-red-500' : 'border-black/5 focus:border-black/20'}`} 
                               />
                          </div>
                          <input 
                            id="cart-notes"
                            value={orderNotes} 
                            onChange={e => setOrderNotes(e.target.value)} 
                            onKeyDown={(e) => handleKeyDown(e, undefined, true)}
                            placeholder="ملاحظات الطلب" 
                            className="w-full p-3.5 rounded-2xl bg-[#FFFFFD]/50 border border-black/5 outline-none font-bold text-xs focus:border-black/20 placeholder:text-gray-500" 
                          />
                     </div>
                     <div className="h-px bg-black/5 w-full"></div>
                     <div className="space-y-1.5 px-1">
                          <div className="flex justify-between text-[11px] font-bold text-gray-500"><span>المجموع</span><span className="font-price text-black">{totalAmount.toLocaleString()} د.ع</span></div>
                          <div className="flex justify-between text-[11px] font-bold text-gray-500"><span>كلفة التوصيل</span><span className="font-price text-black">5,000 د.ع</span></div>
                          <div className="flex justify-between text-lg font-black text-black pt-1"><span>الإجمالي</span><span className="font-price">{finalTotal.toLocaleString()} د.ع</span></div>
                     </div>
                     <div className="flex items-center justify-center gap-2 p-3 bg-green-50/50 backdrop-blur-sm rounded-2xl border border-green-200/50 text-green-700">
                        <WalletCards size={18} />
                        <span className="font-bold text-xs">الدفع عند الاستلام متاح حالياً</span>
                     </div>
                     <button onClick={handleConfirm} disabled={isConfirmingOrder} className="w-full py-4 bg-black text-white rounded-[1.8rem] font-bold text-sm uppercase shadow-2xl active:scale-95 transition-all flex items-center justify-center gap-2 border-b-4 border-gray-900">
                          {isConfirmingOrder ? <LoaderCircle size={20} className="animate-spin"/> : 'تأكيد الطلب'}
                     </button>
                  </div>
              )}
          </div>
        </div>
      </div>
    </>
  );
}