import React from 'react';
import { Menu, ShoppingBag, User } from 'lucide-react';
import { CurrentUser } from '../types';

interface HeaderProps {
  onMenuClick: () => void;
  onLogoClick: () => void;
  currentUser: CurrentUser | null;
  onUserClick: () => void;
  onLoginClick: () => void;
  cartItemCount: number;
  onCartClick: () => void;
}

export default function Header({
  onMenuClick, onLogoClick,
  currentUser, onUserClick, onLoginClick, cartItemCount, onCartClick
}: HeaderProps) {
  return (
    <header 
      className="fixed top-0 inset-x-0 z-[500] h-16 flex items-center transition-all duration-300 px-4 md:px-10 bg-[#FFFFFD]/65 backdrop-blur-md shadow-sm border-b border-black/5"
    >
      <div className="max-w-[1400px] mx-auto w-full flex justify-between items-center relative h-full">
        <div className="flex gap-2 items-center">
          <button 
            onClick={onMenuClick} 
            className="p-3 border rounded-full transition-colors active:scale-95 border-black/5 hover:bg-black/5"
            aria-label="القائمة"
          >
            <Menu size={20}/>
          </button>
        </div>
        
        <div className="flex flex-col items-center cursor-pointer select-none group" onClick={onLogoClick}>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tighter uppercase group-active:scale-95 transition-transform">VANTOR</h1>
        </div>

        <div className="flex items-center gap-2">
          {currentUser ? (
              <button onClick={onUserClick} className="px-3 py-2 bg-[#FFFFFD]/50 backdrop-blur-md border border-black/5 rounded-full font-bold text-xs sm:text-sm hover:bg-black/5 transition-all flex items-center gap-2 active:scale-95 shadow-sm">
                  <span className="truncate max-w-[60px] sm:max-w-[100px]">{currentUser.name.split(' ')[0]}</span>
                  <User size={18} className="flex-shrink-0"/>
              </button>
          ) : (
              <button onClick={onLoginClick} className="p-3 rounded-full transition-colors active:scale-95 hover:bg-black/5" aria-label="تسجيل الدخول / الحساب"><User size={22}/></button>
          )}
          <button onClick={onCartClick} className="relative p-3 transition-colors active:scale-95" aria-label="حقيبة التسوق">
            <ShoppingBag size={22} className="text-black" />
            {cartItemCount > 0 && <span className="absolute top-1 right-1 w-4 h-4 bg-black text-white text-[9px] rounded-full flex items-center justify-center font-bold shadow-md">{cartItemCount}</span>}
          </button>
        </div>
      </div>
    </header>
  );
}