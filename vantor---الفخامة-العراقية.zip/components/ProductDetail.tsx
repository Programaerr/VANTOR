import React, { useState, useEffect, useRef } from 'react';
import { Product } from '../types';
import { ArrowRight, Ruler, Check, Minus, Plus, Maximize, ChevronLeft, ChevronRight, ShoppingBag, ChevronUp, Share2 } from 'lucide-react';
import ZoomModal from './modals/ZoomModal';
import { parseOption } from '../utils';

interface ProductDetailProps {
  product: Product;
  onBack: () => void;
  onAddToCart: (product: Product, size: string, color: string, quantity: number) => void;
  onShowAlert: (alert: { message: string, type: 'warning' | 'info' }) => void;
}

export default function ProductDetail({ product, onBack, onAddToCart, onShowAlert }: ProductDetailProps) {
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [selectedColor, setSelectedColor] = useState<string>('');
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [productQuantity, setProductQuantity] = useState(1);
  const [isSizeGuideOpen, setIsSizeGuideOpen] = useState(false);
  const [isZoomModalOpen, setIsZoomModalOpen] = useState(false);
  
  const sizeGuideRef = useRef<HTMLDivElement>(null);

  // Swipe handlers ref
  const swipeStartRef = useRef<number | null>(null);

  useEffect(() => {
    // Reset selection if product changes
    setSelectedSize('');
    setSelectedColor('');
    setProductQuantity(1);
    setCurrentImageIndex(0);
  }, [product.id, product.sizes]);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [product.id]);

  const handleAddToCartClick = () => {
    onAddToCart(product, selectedSize, selectedColor, productQuantity);
  };
  
  const handleToggleSizeGuide = () => {
    setIsSizeGuideOpen(true);
    setTimeout(() => {
      sizeGuideRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 100);
  };

  const handleNextImage = (e?: React.MouseEvent | React.TouchEvent) => { 
      e?.stopPropagation(); 
      setCurrentImageIndex(prev => (prev < product.images.length - 1 ? prev + 1 : 0)); 
  };
  
  const handlePrevImage = (e?: React.MouseEvent | React.TouchEvent) => { 
      e?.stopPropagation(); 
      setCurrentImageIndex(prev => (prev > 0 ? prev - 1 : product.images.length - 1)); 
  };

  const handleShareProduct = async () => {
      const shareUrl = `${window.location.origin}?product_id=${product.id}`;
      const shareData = {
          title: `VANTOR - ${product.name}`,
          text: `شاهد هذا المنتج المميز من VANTOR: ${product.name}`,
          url: shareUrl
      };

      if (navigator.share) {
          try {
              await navigator.share(shareData);
          } catch (error) {
              console.log('Error sharing:', error);
          }
      } else {
          // Fallback to clipboard
          navigator.clipboard.writeText(shareUrl).then(() => {
              onShowAlert({ message: 'تم نسخ رابط المنتج بنجاح!', type: 'info' });
          });
      }
  };

  // Unified Swipe Handler for Mouse and Touch
  const handleSwipeStart = (clientX: number) => {
    swipeStartRef.current = clientX;
  };

  const handleSwipeEnd = (clientX: number) => {
    if (swipeStartRef.current === null) return;
    const distance = swipeStartRef.current - clientX;
    const minSwipeDistance = 50;

    if (distance > minSwipeDistance) {
        // Swiped Left (Finger moves Left) -> Next Image (LTR Logic)
        handleNextImage();
    } else if (distance < -minSwipeDistance) {
        // Swiped Right (Finger moves Right) -> Previous Image (LTR Logic)
        handlePrevImage();
    }
    swipeStartRef.current = null;
  };

  return (
    <div className="animate-slide-up space-y-6 pb-12 relative">
      {/* Sticky Top Bar for Mobile UX */}
      <div className="flex items-center justify-between px-2 sticky top-20 z-40 gap-3">
          <button onClick={onBack} className="flex-grow sm:flex-grow-0 flex items-center gap-2 font-bold text-xs bg-white/80 backdrop-blur-md px-5 py-3 rounded-full shadow-md border border-black/5 hover:bg-black hover:text-white transition-all uppercase tracking-widest active:scale-95 group">
             <ArrowRight size={16} className="group-hover:-translate-x-1 transition-transform"/> رجوع للمتجر
          </button>
          <button 
            onClick={handleShareProduct} 
            className="w-10 h-10 flex items-center justify-center bg-white/80 backdrop-blur-md rounded-full shadow-md border border-black/5 text-black hover:bg-black hover:text-white transition-all active:scale-95"
            title="مشاركة المنتج"
          >
            <Share2 size={18}/>
          </button>
      </div>
      
      <div className="bg-[#FFFFFD]/65 backdrop-blur-md rounded-[2.5rem] border border-white/60 shadow-2xl overflow-hidden">
        
        <div className="flex flex-col md:flex-row h-auto items-start">
          
          <div 
             className="w-full md:w-[55%] relative bg-gray-50 border-l border-black/5 aspect-square overflow-hidden"
             onTouchStart={(e) => handleSwipeStart(e.targetTouches[0].clientX)}
             onTouchEnd={(e) => handleSwipeEnd(e.changedTouches[0].clientX)}
             onMouseDown={(e) => { e.preventDefault(); handleSwipeStart(e.clientX); }}
             onMouseUp={(e) => { e.preventDefault(); handleSwipeEnd(e.clientX); }}
             onMouseLeave={() => { swipeStartRef.current = null; }}
          >
             <img 
                src={product.images[currentImageIndex]} 
                alt={`${product.name} - VANTOR - لون ${selectedColor}`} 
                className="w-full h-full object-cover cursor-grab active:cursor-grabbing select-none"
                decoding="async"
                draggable={false}
                // @ts-ignore
                fetchPriority="high"
                onClick={() => setIsZoomModalOpen(true)}
             />
             
             <button onClick={(e) => {e.stopPropagation(); setIsZoomModalOpen(true);}} className="absolute top-4 right-4 p-2.5 bg-black/20 backdrop-blur-md text-white rounded-full hover:bg-black/50 transition-colors z-10" aria-label="تكبير"><Maximize size={20}/></button>
             
             <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 flex justify-between px-2 pointer-events-none">
                <button onClick={handlePrevImage} className="p-2 bg-white/50 rounded-full shadow-md backdrop-blur-sm pointer-events-auto hover:bg-white transition-colors opacity-0 hover:opacity-100 md:opacity-100"><ChevronRight size={20}/></button>
                <button onClick={handleNextImage} className="p-2 bg-white/50 rounded-full shadow-md backdrop-blur-sm pointer-events-auto hover:bg-white transition-colors opacity-0 hover:opacity-100 md:opacity-100"><ChevronLeft size={20}/></button>
             </div>

             <div className="absolute bottom-4 inset-x-0 flex justify-center gap-2 overflow-x-auto px-4 py-2 scrollbar-hide pointer-events-none flex-row-reverse">
                {product.images.map((img, i) => (
                    <button key={i} onClick={(e) => { e.stopPropagation(); setCurrentImageIndex(i); }} className={`w-10 h-12 md:w-16 md:h-20 flex-shrink-0 rounded-xl overflow-hidden border-2 transition-all pointer-events-auto ${currentImageIndex === i ? 'border-black shadow-lg scale-110' : 'border-white/50 opacity-70'}`}>
                        <img src={img} className="w-full h-full object-cover" alt={`${product.name} - صورة ${i+1}`} draggable={false} />
                    </button>
                ))}
             </div>
          </div>

          <div className="w-full md:w-[45%] p-4 md:p-10 flex flex-col justify-between overflow-y-auto custom-scrollbar bg-white/40 h-full">
             
             <div className="space-y-2 md:space-y-5">
                <div className="flex justify-between items-start">
                    <span className="text-[10px] md:text-sm font-bold text-gray-400 uppercase tracking-widest">{product.category}</span>
                    {product.offerLabel && <span className="bg-red-500 text-white text-[9px] md:text-xs px-3 py-1 rounded-full font-bold">{product.offerLabel}</span>}
                </div>
                {/* Changed h2 to h1 for SEO optimization */}
                <h1 className="text-base md:text-4xl font-extrabold uppercase text-gray-900 leading-tight">{product.name}</h1>
                <div className="flex flex-col items-start pt-2">
                    {product.originalPrice > product.price && <span className="font-price text-xs md:text-lg text-red-500 line-through font-bold">{product.originalPrice.toLocaleString()}</span>}
                    <span className="font-price text-2xl md:text-5xl font-black text-black">{product.price.toLocaleString()} <span className="text-[12px] md:text-lg text-gray-500 font-bold font-sans">د.ع</span></span>
                </div>
             </div>

             <div className="space-y-4 md:space-y-8 mt-5 md:mt-10 flex-grow">
                
                <div className="space-y-2 md:space-y-3">
                    <div className="flex justify-between items-center">
                        <span className="text-[10px] md:text-xs font-bold text-gray-400 uppercase">المقاس المتوفر</span>
                    </div>
                    <div className="flex flex-wrap gap-2 md:gap-3">
                        {product.sizes && product.sizes.length > 0 && (
                            product.sizes.map(s => {
                                const { value, isSoldOut } = parseOption(s);
                                return (
                                    <button 
                                        key={s} 
                                        disabled={isSoldOut}
                                        onClick={() => setSelectedSize(value)} 
                                        className={`h-10 min-w-[40px] px-3 md:h-14 md:min-w-[56px] rounded-xl border font-bold text-xs md:text-lg transition-all 
                                            ${isSoldOut 
                                                ? 'bg-gray-100 text-gray-300 border-transparent cursor-not-allowed line-through decoration-red-500/50 decoration-2' 
                                                : selectedSize === value 
                                                    ? 'bg-black text-white border-black active:scale-95 shadow-md' 
                                                    : 'bg-white border-black/10 text-gray-600 active:scale-95'
                                            }`}
                                    >
                                        {value}
                                    </button>
                                );
                            })
                        )}
                        {(!product.sizes || product.sizes.length === 0) && (
                            <p className="text-xs font-bold text-red-500">لا توجد مقاسات متاحة حالياً</p>
                        )}
                    </div>
                </div>

                <div className="space-y-2 md:space-y-3">
                    <span className="text-[10px] md:text-xs font-bold text-gray-400 uppercase">اللون المختار</span>
                    <div className="flex flex-wrap gap-3 md:gap-4">
                        {product.colors.map(c => {
                            const { value, isSoldOut } = parseOption(c);
                            return (
                                <button 
                                    key={c} 
                                    disabled={isSoldOut}
                                    onClick={() => setSelectedColor(value)} 
                                    style={{backgroundColor: value}} 
                                    className={`w-8 h-8 md:w-12 md:h-12 rounded-full border shadow-md relative transition-transform
                                        ${isSoldOut ? 'opacity-50 cursor-not-allowed' : 'active:scale-95'}
                                        ${selectedColor === value ? 'ring-4 ring-black/10 ring-offset-2 scale-110' : 'border-gray-200'}
                                    `}
                                >
                                    {isSoldOut && (
                                        <div className="absolute inset-0 flex items-center justify-center">
                                            <div className="w-full h-1 bg-red-500 rotate-45 rounded-full"></div>
                                            <div className="w-full h-1 bg-red-500 -rotate-45 absolute rounded-full"></div>
                                        </div>
                                    )}
                                    {selectedColor === value && !isSoldOut && <Check size={16} className={`absolute inset-0 m-auto ${['#FFFFFF', '#ffffff', 'white'].includes(value) ? 'text-black' : 'text-white'}`} />}
                                </button>
                            );
                        })}
                    </div>
                </div>

                <div className="flex items-center gap-3 md:gap-6 bg-gray-50 w-fit p-1.5 md:p-2 rounded-2xl border border-black/5 mt-2">
                    <button onClick={() => setProductQuantity(p => Math.max(1, p - 1))} className="w-8 h-8 md:w-10 md:h-10 bg-white rounded-xl flex items-center justify-center shadow-sm active:scale-90 border border-black/5"><Minus size={14}/></button>
                    <span className="font-price font-bold text-base md:text-2xl w-8 text-center">{productQuantity}</span>
                    <button onClick={() => setProductQuantity(p => p + 1)} className="w-8 h-8 md:w-10 md:h-10 bg-white rounded-xl flex items-center justify-center shadow-sm active:scale-90 border border-black/5"><Plus size={14}/></button>
                </div>
             </div>

             <div className="mt-5 md:mt-12 pt-5 md:pt-10 border-t border-black/5 space-y-4">
                <button 
                    disabled={product.isOutOfStock} 
                    onClick={handleAddToCartClick} 
                    className={`w-full py-4 md:py-6 rounded-2xl md:rounded-3xl font-bold text-sm md:text-xl uppercase shadow-xl active:scale-95 transition-all flex items-center justify-center gap-3 ${product.isOutOfStock ? 'bg-gray-100 text-gray-400 cursor-not-allowed' : 'bg-black text-white hover:bg-gray-900 border-b-4 border-gray-800'}`}
                >
                    {product.isOutOfStock ? 'نفذت الكمية بالكامل' : <><ShoppingBag size={20} className="md:w-6 md:h-6"/> إضافة للحقيبة</>}
                </button>

                <button 
                  onClick={handleToggleSizeGuide} 
                  className="w-full py-4 md:py-6 rounded-2xl md:rounded-3xl font-bold text-sm md:text-xl uppercase shadow-xl active:scale-95 transition-all flex items-center justify-center gap-3 bg-black text-white hover:bg-gray-900 border-b-4 border-gray-800 group"
                >
                   <Ruler size={20} className="md:w-6 md:h-6 group-hover:scale-110 transition-transform"/> دليل القياسات الذكي
                </button>
             </div>
          </div>
        </div>
      </div>

      {isSizeGuideOpen && (
        <div ref={sizeGuideRef} className="animate-slide-up bg-white rounded-[2.5rem] p-8 sm:p-10 border-4 border-black/5 shadow-2xl mx-1 relative overflow-hidden">
            <div className="flex items-center justify-between mb-6 border-b border-black/5 pb-4">
                <h3 className="font-bold text-xl sm:text-2xl flex items-center gap-3 text-gray-900"><Ruler size={32} className="text-black"/> تفاصيل القياسات للموديل</h3>
                <button onClick={() => setIsSizeGuideOpen(false)} className="p-2.5 bg-gray-100 rounded-full hover:bg-red-50 hover:text-red-500 transition-colors"><ChevronUp size={24}/></button>
            </div>
            
            <div className="grid gap-4">
                {product.sizeGuide.split('\n').filter(l => l.trim()).map((line, i) => {
                    const parts = line.split(':');
                    if (!parts[1]) return null;
                    return (
                        <div key={i} className="flex justify-between items-center p-5 bg-gray-50 rounded-3xl border border-black/5 hover:border-black/20 transition-all hover:translate-x-1">
                            <span className="font-bold text-gray-700 text-sm sm:text-lg flex items-center gap-3">
                                <span className="w-3 h-3 rounded-full bg-black"></span>
                                {parts[0].replace('•', '').trim()}
                            </span>
                            <span className="font-bold font-price text-black text-lg sm:text-2xl" dir="ltr">{parts[1].trim()}</span>
                        </div>
                    )
                })}
            </div>
            <p className="text-[11px] text-gray-400 font-bold text-center mt-6 uppercase tracking-widest">تأكد من اختيار قياسك بدقة لضمان أفضل إطلالة</p>
        </div>
      )}

      <div className="px-3">
          <h3 className="font-bold text-xs text-gray-400 uppercase mb-3 tracking-[0.2em]">وصف الموديل وتفاصيله</h3>
          <p className="text-sm md:text-lg font-bold text-gray-800 leading-relaxed bg-[#FFFFFD]/50 backdrop-blur-md p-6 rounded-[2rem] border border-white shadow-sm whitespace-pre-line">
              {product.description}
          </p>
      </div>

      <ZoomModal isOpen={isZoomModalOpen} images={product.images} startIndex={currentImageIndex} onClose={() => setIsZoomModalOpen(false)} />
    </div>
  );
}