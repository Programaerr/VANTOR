
import React, { useState, useEffect, useRef } from 'react';
import { MessageCircle, X, Send, Headphones } from 'lucide-react';
import { forwardMessageToSupport } from '../services/apiService';
import { ChatMessage, Product, CurrentUser } from '../types';
import { supabase } from '../services/supabaseClient';
import type { RealtimeChannel } from '@supabase/supabase-js';

interface AIChatWidgetProps {
  isOpen: boolean;
  onToggle: () => void;
  products: Product[];
  currentUser: CurrentUser | null;
  onShowAlert: (alert: { message: string; type: 'warning' | 'info' }) => void;
}

export default function AIChatWidget({ isOpen, onToggle, products, currentUser, onShowAlert }: AIChatWidgetProps) {
  const [supportMessages, setSupportMessages] = useState<ChatMessage[]>([]);
  const [supportStep, setSupportStep] = useState<'INFO' | 'CHAT'>('INFO');
  const [chatInput, setChatInput] = useState('');
  
  const [guestInfo, setGuestInfo] = useState({ name: '', phone: '' });
  const [guestInfoError, setGuestInfoError] = useState('');
  const [sessionUser, setSessionUser] = useState<CurrentUser | null>(null);
  const [supportChannel, setSupportChannel] = useState<RealtimeChannel | null>(null);

  const chatEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // --- LOGIC: Handle UI state when widget is opened/closed ---
  useEffect(() => {
    if (isOpen) {
      // If there's no active session, decide what to show
      if (!sessionUser) {
        if (currentUser) {
          if (currentUser.phone && currentUser.phone.trim() !== '') {
            setSessionUser(currentUser);
            setSupportStep('CHAT');
            if (supportMessages.length === 0) {
              setSupportMessages([{ role: 'model', text: 'أهلاً بك مجدداً. كيف يمكننا خدمتك؟' }]);
            }
          } else {
            setSupportStep('INFO');
            setGuestInfo({ name: currentUser.name || '', phone: '' });
          }
        } else {
          setSupportStep('INFO');
          setGuestInfo({ name: '', phone: '' });
          setSupportMessages([]);
        }
      }
      // Focus input on desktop
      if (window.innerWidth >= 768) {
        setTimeout(() => inputRef.current?.focus(), 100);
      }
    }
  }, [isOpen, currentUser, sessionUser]);
  
  // --- LOGIC: Manage Realtime connection based on session state, NOT visibility ---
  useEffect(() => {
    let channel: RealtimeChannel | null = null;
    
    // Subscribe only when a chat session is active
    if (supportStep === 'CHAT' && sessionUser?.id) {
        channel = supabase.channel(`support-chat-${sessionUser.id}`);
        channel.on('broadcast', { event: 'admin_reply' }, ({ payload }) => {
            if (payload && payload.userId === sessionUser.id && payload.text) {
                const adminMsg: ChatMessage = { role: 'agent', text: payload.text };
                setSupportMessages(prev => [...prev, adminMsg]);
            }
        }).subscribe((status) => {
             if (status === 'SUBSCRIBED') { console.log('Connected to support chat channel.'); }
        });
        setSupportChannel(channel);
    }
    
    // Cleanup runs ONLY when session ends (sessionUser/supportStep changes), not on close.
    return () => {
      if (channel) {
        supabase.removeChannel(channel);
        setSupportChannel(null);
        console.log('Disconnected from support chat channel.');
      }
    };
  }, [supportStep, sessionUser]);


  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [supportMessages, supportStep]);

  const handleEndSupportSession = () => {
      if (supportMessages.length > 1) { // Only show if a conversation happened
          onShowAlert({ message: 'شكراً لتواصلك معنا. تم إنهاء المحادثة.', type: 'info' });
      }
      setSupportMessages([]); 
      setSupportStep('INFO'); 
      setSessionUser(null); // This triggers the channel cleanup effect
      
      if (!currentUser) {
          setGuestInfo({ name: '', phone: '' });
      }
  };

  const handleGuestInfoSubmit = () => {
    setGuestInfoError('');
    if (!guestInfo.name.trim() || !guestInfo.phone.trim()) {
      setGuestInfoError('يرجى ملء الاسم ورقم الهاتف.');
      return;
    }
    if (!/^07[0-9]{9}$/.test(guestInfo.phone)) {
      setGuestInfoError('صيغة الرقم غير صحيحة. يجب أن يبدأ بـ 07 ويتكون من 11 رقم.');
      return;
    }

    let finalUser: CurrentUser;
    if (currentUser) {
        finalUser = { ...currentUser, name: guestInfo.name, phone: guestInfo.phone };
    } else {
        finalUser = { id: `guest-${Date.now()}`, name: guestInfo.name, email: `guest-contact@vantor.placeholder`, phone: guestInfo.phone };
    }
    
    setSessionUser(finalUser);
    setSupportStep('CHAT');
    setSupportMessages([{ role: 'model', text: 'أهلاً بك في الدعم الفني المباشر. كيف يمكننا خدمتك اليوم؟' }]);
  };

  const sendSupportMessage = async () => {
    if (!chatInput.trim()) return;

    const msg = chatInput.trim();
    setChatInput('');
    
    const newUserMsg: ChatMessage = { role: 'user', text: msg };
    setSupportMessages(prev => [...prev, newUserMsg]);

    try {
        if (!sessionUser) throw new Error("بيانات المستخدم مفقودة");
        forwardMessageToSupport(msg, sessionUser).catch(e => console.error("Failed to send message in background:", e));
    } catch (error: any) {
        console.error("Support Chat error:", error);
    } finally {
        if (window.innerWidth >= 768) {
             setTimeout(() => inputRef.current?.focus(), 50);
        }
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
      if (e.key === 'Enter') { e.preventDefault(); sendSupportMessage(); }
  };

  if (!isOpen) {
    return (
      <div className="fixed bottom-5 left-4 z-[600] pointer-events-auto" style={{ direction: 'ltr' }}>
        <button onClick={onToggle} className="w-14 h-14 sm:w-16 sm:h-16 bg-black text-white rounded-full shadow-xl active:scale-90 transition-all flex items-center justify-center relative group border-2 border-white/10" aria-label="فتح الدعم الفني">
           <Headphones size={26} />
           <span className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-[#FFFFFD] shadow-lg"></span>
        </button>
      </div>
    );
  }

  return (
    <div className="fixed bottom-5 left-4 z-[600] flex flex-col-reverse items-start gap-4 pointer-events-none" style={{ direction: 'ltr' }}>
      <button onClick={onToggle} className="w-14 h-14 sm:w-16 sm:h-16 bg-black text-white rounded-full shadow-xl active:scale-90 transition-all flex items-center justify-center relative pointer-events-auto group border-2 border-white/10" aria-label="إغلاق المحادثة">
         <X size={26} />
         <span className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-[#FFFFFD] shadow-lg"></span>
      </button>
      
      <div className="bg-[#FFFFFD]/65 backdrop-blur-[50px] w-[85vw] max-w-xs sm:max-w-[320px] h-[60vh] rounded-3xl shadow-2xl border border-white/40 flex flex-col overflow-hidden animate-slide-up pointer-events-auto" style={{ direction: 'rtl' }} role="dialog" aria-modal="true" aria-label="نافذة المحادثة">
          
          <div className="p-4 flex justify-between items-center flex-shrink-0 bg-[#FFFFFD]/65 backdrop-blur-md text-black border-b border-black/5">
            <div className="flex items-center gap-3">
               <div className="relative">
                 <div className="w-8 h-8 rounded-xl flex items-center justify-center border bg-white/50 border-black/10 shadow-sm">
                   <Headphones size={18}/>
                 </div>
                 <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-gray-100"></div>
               </div>
               <div className="flex flex-col">
                   <span className="font-bold text-xs uppercase tracking-wider">الدعم الفني المباشر</span>
                   <span className="text-[9px] font-bold text-gray-400">رد مباشر</span>
               </div>
            </div>
            
            {supportStep === 'CHAT' && (
                <button onClick={handleEndSupportSession} className="bg-red-500 text-white text-[10px] font-bold px-2 py-1.5 rounded-lg hover:bg-red-600 transition-colors shadow-sm flex items-center gap-1 active:scale-95" title="إنهاء المحادثة">
                    <X size={12}/> إنهاء
                </button>
            )}
          </div>

          <div className="flex-grow p-4 overflow-y-auto space-y-4 text-right custom-scrollbar relative" role="log">
            {supportStep === 'INFO' ? (
                <div className="flex flex-col items-center justify-center h-full text-center space-y-4 animate-fade-in p-2">
                    <div className="w-16 h-16 bg-white/50 backdrop-blur-sm rounded-full shadow-md flex items-center justify-center border border-black/5 mb-2"><Headphones size={32} className="text-black"/></div>
                    <h4 className="font-bold text-sm text-gray-800">{currentUser ? 'لإكمال عملية الربط، يرجى تأكيد رقم الهاتف' : 'للتحدث مع موظف، يرجى إدخال معلوماتك'}</h4>
                    <div className="space-y-3 w-full">
                        <input value={guestInfo.name} onChange={e => setGuestInfo({...guestInfo, name: e.target.value})} placeholder="اسمك الكامل" className="w-full p-3 rounded-xl bg-white/50 backdrop-blur-sm border border-black/10 text-xs font-bold outline-none focus:border-black transition-all" />
                        <input type="tel" value={guestInfo.phone} onChange={e => setGuestInfo({...guestInfo, phone: e.target.value.replace(/[^0-9]/g, '').slice(0, 11)})} placeholder="رقم الهاتف (07...)" dir="ltr" className="w-full p-3 rounded-xl bg-white/50 backdrop-blur-sm border border-black/10 text-xs font-bold outline-none focus:border-black text-left transition-all" />
                    </div>
                    {guestInfoError && <p className="text-red-600 text-[10px] font-bold animate-shake bg-red-50/50 p-2 rounded-lg border border-red-100 w-full">{guestInfoError}</p>}
                    <button onClick={handleGuestInfoSubmit} className="w-full py-3.5 bg-black text-white rounded-xl font-bold text-xs uppercase shadow-lg active:scale-95 hover:bg-gray-900 transition-all">بدء المحادثة</button>
                </div>
            ) : (
                <>
                    {supportMessages.length === 0 && (
                        <div className="h-full w-full flex flex-col items-center justify-center opacity-40 gap-3">
                            <Headphones size={40}/>
                            <p className="text-center font-bold text-gray-500 text-xs px-8">أهلاً بك في الدعم المباشر. كيف يمكننا مساعدتك اليوم؟</p>
                        </div>
                    )}
                    {supportMessages.map((m, i) => {
                        const isUser = m.role === 'user'; const isAdmin = m.role === 'agent';
                        return (
                            <div key={i} className={`flex ${isUser ? 'justify-end' : 'justify-start'} animate-fade-in`}>
                                <div className={`max-w-[85%] p-3.5 rounded-2xl text-[11px] sm:text-xs font-bold shadow-sm leading-relaxed ${isUser ? 'bg-white/60 backdrop-blur-sm text-black border border-black/5 rounded-tr-none' : isAdmin ? 'bg-gray-800 text-white rounded-tl-none border border-gray-700' : 'bg-black text-white rounded-tl-none'}`}>
                                    {m.text}
                                </div>
                            </div>
                        );
                    })}
                    <div ref={chatEndRef} />
                </>
            )}
          </div>
          
          {supportStep === 'CHAT' && (
            <div className="p-3 bg-white/30 backdrop-blur-md border-t border-black/5 flex gap-2 flex-shrink-0 z-10">
              <input 
                  ref={inputRef}
                  value={chatInput} 
                  onChange={e => setChatInput(e.target.value)} 
                  onKeyDown={handleKeyDown} 
                  placeholder="اكتب للموظف..." 
                  className="flex-grow p-3 rounded-xl outline-none text-right text-[11px] bg-white/40 backdrop-blur-sm font-bold border border-transparent focus:border-black/10 transition-all disabled:opacity-50 placeholder:text-gray-500" 
                  aria-label="حقل إدخال الرسالة" 
              />
              <button 
                  onClick={sendSupportMessage} 
                  className="w-11 h-11 text-white rounded-xl active:scale-90 transition-all shadow-md flex items-center justify-center flex-shrink-0 bg-gray-800" 
                  aria-label="إرسال" 
              >
                <Send size={18}/>
              </button>
            </div>
          )}
      </div>
    </div>
  );
}
