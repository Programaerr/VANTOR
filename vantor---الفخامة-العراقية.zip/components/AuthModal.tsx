
import React, { useState } from 'react';
import { supabase } from '../services/supabaseClient';
import { LoaderCircle, User, Mail, Lock, CheckCircle2, AlertCircle, Eye, EyeOff, KeyRound, ArrowRight } from 'lucide-react';

interface AuthModalProps {
  onClose: () => void;
  onAuthSuccess: () => void;
}

export default function AuthModal({ onClose, onAuthSuccess }: AuthModalProps) {
  const [authMode, setAuthMode] = useState<'LOGIN' | 'REGISTER' | 'RESET'>('LOGIN');
  const [authForm, setAuthForm] = useState({ email: '', password: '', name: '' });
  const [authError, setAuthError] = useState('');
  const [authLoading, setAuthLoading] = useState(false);
  const [authMessage, setAuthMessage] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const handleAuth = async () => {
    setAuthError('');
    setAuthMessage('');
    setAuthLoading(true);
    
    const { email, password, name } = authForm;

    // 1. التحقق من البريد الإلكتروني (مشترك للكل)
    if (!email.trim()) {
        setAuthError('يرجى كتابة البريد الإلكتروني.');
        setAuthLoading(false); return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        setAuthError('صيغة البريد الإلكتروني غير صحيحة.');
        setAuthLoading(false); return;
    }

    try {
        // --- LOGIC: RESET PASSWORD ---
        if (authMode === 'RESET') {
            const { error } = await supabase.auth.resetPasswordForEmail(email, {
                redirectTo: window.location.origin, // سيعود للموقع لتغيير الباسورد
            });
            
            if (error) {
                // Supabase security: Rate limit errors or general API errors
                throw error;
            }
            
            setAuthMessage(`تم إرسال رابط استعادة كلمة المرور إلى (${email}). يرجى التحقق من بريدك.`);
            setAuthLoading(false);
            return;
        }

        // --- LOGIC: LOGIN / REGISTER ---
        
        // التحقق من كلمة المرور (للتسجيل والدخول فقط)
        if (!password) {
            setAuthError('يرجى كتابة كلمة المرور.');
            setAuthLoading(false); return;
        }

        if (password.length < 8) {
            setAuthError('كلمة المرور قصيرة جداً (يجب أن تكون 8 رموز على الأقل).');
            setAuthLoading(false); return;
        }

        if (authMode === 'REGISTER') {
            if (!name.trim()) {
                setAuthError('يرجى كتابة الاسم الكامل.');
                setAuthLoading(false); return;
            }

            const { data, error } = await supabase.auth.signUp({ 
                email, 
                password, 
                options: { 
                  data: { name },
                  emailRedirectTo: window.location.origin 
                } 
            });
            if (error) throw error;

            if (data.user && data.user.identities && data.user.identities.length === 0) {
                 setAuthError('هذا البريد الإلكتروني مسجل مسبقاً. يرجى تسجيل الدخول.');
                 setAuthLoading(false);
                 return;
            }

            if (data.user && !data.session) {
              setAuthMessage(`تم إرسال رابط التفعيل إلى (${email}).\nيرجى التحقق من البريد (أو الرسائل المهملة Spam).`);
              setAuthLoading(false);
            } else if (data.user) {
              onAuthSuccess();
            }
        } else {
            // LOGIN
            const { error } = await supabase.auth.signInWithPassword({ email, password });
            if (error) throw error;
            
            onAuthSuccess();
        }
    } catch (error: any) {
        let friendlyMessage = 'حدث خطأ. يرجى المحاولة مرة أخرى.';
        const lowerCaseError = (error.message || '').toLowerCase();
        
        if (lowerCaseError.includes('invalid login credentials')) {
            friendlyMessage = 'البريد الإلكتروني أو كلمة المرور غير صحيحة.';
        } else if (lowerCaseError.includes('email not confirmed')) {
            friendlyMessage = 'عذراً، لم يتم تفعيل الحساب بعد. تحقق من البريد، أو ربما أدخلت بريداً خاطئاً أثناء التسجيل.';
        } else if (lowerCaseError.includes('user already registered') || lowerCaseError.includes('unique constraint')) {
            friendlyMessage = 'هذا البريد الإلكتروني مستخدم بالفعل. حاول تسجيل الدخول.';
        } else if (lowerCaseError.includes('rate limit')) {
            friendlyMessage = 'لقد تجاوزت حد المحاولات المسموح به. يرجى الانتظار قليلاً.';
        } else {
            friendlyMessage = error.message;
        }
        
        setAuthError(friendlyMessage);
        setAuthLoading(false); 
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent, nextElementId?: string, isSubmit: boolean = false) => {
    if (e.key === 'Enter') {
        e.preventDefault();
        if (isSubmit) {
            handleAuth();
        } else if (nextElementId) {
            const nextEl = document.getElementById(nextElementId);
            if (nextEl) {
                nextEl.focus();
            }
        }
    }
  };

  return (
    <div className="fixed inset-0 z-[600] flex items-center justify-center p-4 bg-black/5 backdrop-blur-sm animate-fade-in" onClick={onClose}>
      <div 
        onClick={(e) => e.stopPropagation()} 
        className="bg-[#FFFFFD]/95 backdrop-blur-[50px] w-full max-w-sm p-8 sm:p-10 rounded-[2.5rem] shadow-2xl border border-white/40 animate-slide-up text-center space-y-6"
      >
        <div className="space-y-1">
            <h3 className="text-3xl sm:text-4xl font-bold uppercase tracking-tighter text-black">VANTOR</h3>
            <p className="text-xs sm:text-sm font-bold text-gray-500">مرحباً بك مجدداً في عالم الفخامة</p>
        </div>

        {/* Tab Switcher - Only visible if NOT in Reset mode */}
        {authMode !== 'RESET' && (
            <div className="flex p-1.5 bg-gray-100/80 rounded-2xl border border-black/5">
            <button 
                onClick={() => { setAuthMode('LOGIN'); setAuthError(''); setAuthMessage(''); }} 
                className={`flex-grow py-2.5 rounded-xl font-bold text-xs uppercase transition-all duration-300 ${authMode === 'LOGIN' ? 'bg-black text-white shadow-lg scale-[1.02]' : 'text-gray-500 hover:text-black'}`}
            >
                تسجيل الدخول
            </button>
            <button 
                onClick={() => { setAuthMode('REGISTER'); setAuthError(''); setAuthMessage(''); }} 
                className={`flex-grow py-2.5 rounded-xl font-bold text-xs uppercase transition-all duration-300 ${authMode === 'REGISTER' ? 'bg-black text-white shadow-lg scale-[1.02]' : 'text-gray-500 hover:text-black'}`}
            >
                إنشاء حساب
            </button>
            </div>
        )}

        {/* Reset Password Header */}
        {authMode === 'RESET' && (
            <div className="flex items-center justify-between pb-2 border-b border-black/5">
                <h4 className="font-bold text-lg text-black flex items-center gap-2"><KeyRound size={20}/> استعادة الحساب</h4>
                <button onClick={() => { setAuthMode('LOGIN'); setAuthError(''); }} className="p-2 bg-white/50 rounded-full hover:bg-black hover:text-white transition-colors"><ArrowRight size={18}/></button>
            </div>
        )}

        {authError && (
          <div className="text-red-600 text-[11px] font-bold text-center bg-red-50 p-3 rounded-xl border border-red-200 animate-shake flex items-center justify-center gap-2" role="alert">
            <AlertCircle size={14} className="flex-shrink-0" />
            <span>{authError}</span>
          </div>
        )}
        
        {authMessage && (
          <div className="text-green-700 text-[11px] font-bold text-center bg-green-50 p-3 rounded-xl border border-green-200 flex flex-col items-center justify-center gap-2 animate-fade-in" role="alert">
            <div className="flex items-center gap-2">
                <CheckCircle2 size={16}/> 
                <span>تم العملية بنجاح</span>
            </div>
            <span className="text-[10px] opacity-90 leading-relaxed px-2 whitespace-pre-line">{authMessage}</span>
          </div>
        )}
        
        {!authMessage && (
            <div className="space-y-4 text-right" dir="rtl">
            
            {/* NAME FIELD (Register Only) */}
            {authMode === 'REGISTER' && (
                <div className="space-y-2 animate-fade-in">
                    <label htmlFor="auth-name" className="text-[11px] font-black text-black mr-2 block">الاسم الكامل</label>
                    <div className="relative group">
                        <User size={16} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-black transition-colors" />
                        <input 
                            id="auth-name"
                            value={authForm.name} 
                            onChange={e => setAuthForm({...authForm, name: e.target.value})} 
                            onKeyDown={(e) => handleKeyDown(e, 'auth-email')}
                            className="w-full p-4 pr-11 rounded-2xl bg-white border border-black/10 outline-none focus:border-black focus:ring-1 focus:ring-black/50 font-bold text-xs transition-all shadow-sm placeholder:text-gray-400" 
                        />
                    </div>
                </div>
            )}
            
            {/* EMAIL FIELD (All Modes) */}
            <div className="space-y-2 animate-fade-in">
                <label htmlFor="auth-email" className="text-[11px] font-black text-black mr-2 block">البريد الإلكتروني</label>
                <div className="relative group">
                    <Mail size={16} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-black transition-colors" />
                    <input 
                    id="auth-email"
                    type="email" 
                    value={authForm.email} 
                    onChange={e => setAuthForm({...authForm, email: e.target.value})} 
                    onKeyDown={(e) => authMode === 'RESET' ? handleKeyDown(e, undefined, true) : handleKeyDown(e, 'auth-password')}
                    dir="ltr"
                    className="w-full p-4 pr-11 rounded-2xl bg-white border border-black/10 outline-none focus:border-black focus:ring-1 focus:ring-black/50 font-bold text-xs transition-all shadow-sm text-right placeholder:text-gray-400" 
                    />
                </div>
            </div>

            {/* PASSWORD FIELD (Login/Register Only) */}
            {authMode !== 'RESET' && (
                <div className="space-y-2 animate-fade-in">
                    <label htmlFor="auth-password" className="text-[11px] font-black text-black mr-2 block">
                        {authMode === 'REGISTER' ? 'كلمة المرور (8 رموز على الأقل)' : 'كلمة المرور'}
                    </label>
                    <div className="relative group">
                        <Lock size={16} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-black transition-colors" />
                        <input 
                        id="auth-password"
                        type={showPassword ? "text" : "password"} 
                        value={authForm.password} 
                        onChange={e => setAuthForm({...authForm, password: e.target.value})} 
                        onKeyDown={(e) => handleKeyDown(e, undefined, true)}
                        dir="ltr"
                        className="w-full p-4 pr-11 pl-10 rounded-2xl bg-white border border-black/10 outline-none focus:border-black focus:ring-1 focus:ring-black/50 font-bold text-xs transition-all shadow-sm text-right placeholder:text-gray-400" 
                        />
                        <button 
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-black transition-colors"
                        >
                        {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                        </button>
                    </div>
                </div>
            )}
            
            {/* Forgot Password Link (Login Only) */}
            {authMode === 'LOGIN' && (
                <div className="flex justify-end pt-1">
                    <button 
                        onClick={() => { setAuthMode('RESET'); setAuthError(''); setAuthMessage(''); }}
                        className="text-[10px] font-black text-black hover:opacity-75 transition-opacity underline decoration-dotted"
                    >
                        نسيت كلمة المرور؟
                    </button>
                </div>
            )}
            
            {/* Info text for Reset Mode */}
            {authMode === 'RESET' && (
                <p className="text-[10px] text-black font-black px-1 pt-1 leading-relaxed">
                    أدخل بريدك الإلكتروني المسجل وسنرسل لك رابطاً لإنشاء كلمة مرور جديدة.
                </p>
            )}

            </div>
        )}
        
        {!authMessage && (
            <button 
            onClick={handleAuth} 
            disabled={authLoading} 
            className="w-full py-5 bg-black text-white rounded-[1.5rem] font-bold uppercase shadow-2xl active:scale-95 transition-all text-sm border-b-4 border-gray-900 flex items-center justify-center gap-3 disabled:opacity-50"
            >
            {authLoading ? <LoaderCircle size={20} className="animate-spin" /> : (
                authMode === 'LOGIN' ? 'تسجيل الدخول' : 
                authMode === 'REGISTER' ? 'إشتراك' : 
                'إرسال الرابط'
            )}
            </button>
        )}

        <button 
          onClick={onClose} 
          className="text-[10px] font-bold text-black hover:opacity-75 transition-colors uppercase tracking-widest pt-2"
        >
          {authMessage ? 'إغلاق' : 'تخطي الآن'}
        </button>
      </div>
    </div>
  );
}
