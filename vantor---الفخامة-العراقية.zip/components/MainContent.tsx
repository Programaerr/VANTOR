import React, { useEffect, useState, useRef, memo } from 'react';
import { Product } from '../types';
import { ArchiveX, Grid, List, Clock, Sparkles, ChevronDown, ShoppingBag, ChevronLeft } from 'lucide-react';
import { getTopSellingProducts } from '../services/apiService';
import { parseOption } from '../utils';

interface MainContentProps {
  pageType: 'HOME' | 'STORE';
  onNavigateToStore: () => void;
  heroImageUrl: string;
  productDisplayMode: 'GRID' | 'VERTICAL_LIST';
  setProductDisplayMode: (mode: 'GRID' | 'VERTICAL_LIST') => void;
  activeCategory: string;
  filteredProducts: Product[];
  onProductClick: (product: Product) => void;
  productsGridRef: React.RefObject<HTMLDivElement>;
  showTimer?: boolean;
  deadline?: string; 
  allProducts: Product[];
}

const CountdownTimer = ({ deadline }: { deadline: string }) => {
    const [timeLeftString, setTimeLeftString] = useState('');

    useEffect(() => {
        if (!deadline) return;

        const interval = setInterval(() => {
            const now = new Date().getTime();
            const endTime = new Date(deadline).getTime();
            const distance = endTime - now;

            if (distance < 0) {
                setTimeLeftString("00:00:00");
                clearInterval(interval);
            } else {
                const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                const seconds = Math.floor((distance % (1000 * 60)) / 1000);
                
                const hStr = hours < 10 ? `0${hours}` : hours;
                const mStr = minutes < 10 ? `0${minutes}` : minutes;
                const sStr = seconds < 10 ? `0${seconds}` : seconds;
                
                setTimeLeftString(`${hStr}:${mStr}:${sStr}`);
            }
        }, 1000);

        return () => clearInterval(interval);
    }, [deadline]);

    if (!timeLeftString || timeLeftString === "00:00:00") return null;

    return (
        <div className="mt-4 flex items-center gap-2 bg-black/40 backdrop-blur-md px-4 py-2 rounded-full border border-white/10 animate-fade-in shadow-lg">
            <Clock size={16} className="text-white animate-pulse" />
            <span className="font-price font-bold text-sm text-white tracking-widest pt-1" dir="ltr">{timeLeftString}</span>
        </div>
    );
};

const LuxuryEmptyState = () => (
    <div className="w-full flex flex-col items-center justify-center py-24 sm:py-32 bg-[#FFFFFD]/50 border border-white/50 rounded-[3rem] relative overflow-hidden group mx-auto">
        {/* Decorative Background */}
        <h1 className="absolute text-[12rem] font-black text-black/[0.02] select-none pointer-events-none group-hover:scale-110 transition-transform duration-[2s]">
            VANTOR
        </h1>
        
        <div className="relative z-10 flex flex-col items-center gap-6 animate-fade-in">
            <div className="w-20 h-20 bg-black/5 rounded-full flex items-center justify-center border border-black/5 mb-2">
                <ShoppingBag size={32} className="text-black/40" />
            </div>
            
            <div className="space-y-2 text-center">
                <h3 className="text-xl font-bold uppercase tracking-[0.2em] text-black">
                    لا توجد منتجات حالياً
                </h3>
                <p className="text-xs text-gray-500 font-bold tracking-wide">
                    ترقبوا تشكيلتنا الحصرية قريباً
                </p>
            </div>
            
            <div className="w-16 h-0.5 bg-black/10 rounded-full mt-4"></div>
        </div>
    </div>
);

const PRODUCTS_PER_PAGE = 12;

const MainContent = memo(({
  pageType, onNavigateToStore, heroImageUrl, productDisplayMode, setProductDisplayMode,
  activeCategory, filteredProducts, onProductClick, productsGridRef, showTimer, deadline, allProducts
}: MainContentProps) => {

  const [topProducts, setTopProducts] = useState<Product[]>([]);
  const [newArrivals, setNewArrivals] = useState<Product[]>([]);
  const [visibleCount, setVisibleCount] = useState(PRODUCTS_PER_PAGE);
  const [activeMobilePage, setActiveMobilePage] = useState(0);
  const mobileScrollRef = useRef<HTMLDivElement>(null);
  
  // Refs for Home Page Sliders
  const newArrivalsScrollRef = useRef<HTMLDivElement>(null);
  const selectedModelsScrollRef = useRef<HTMLDivElement>(null);

  // Drag Scroll Logic
  const isDragging = useRef(false);
  const startX = useRef(0);
  const scrollLeft = useRef(0);

  const startDrag = (e: React.MouseEvent, ref: React.RefObject<HTMLDivElement>) => {
    if(!ref.current) return;
    isDragging.current = true;
    startX.current = e.pageX - ref.current.offsetLeft;
    scrollLeft.current = ref.current.scrollLeft;
    ref.current.style.cursor = 'grabbing';
    ref.current.style.userSelect = 'none';
  };

  const stopDrag = (ref: React.RefObject<HTMLDivElement>) => {
    isDragging.current = false;
    if(ref.current) {
        ref.current.style.cursor = 'grab';
        ref.current.style.removeProperty('user-select');
    }
  };

  const moveDrag = (e: React.MouseEvent, ref: React.RefObject<HTMLDivElement>) => {
    if(!isDragging.current || !ref.current) return;
    e.preventDefault();
    const x = e.pageX - ref.current.offsetLeft;
    const walk = (x - startX.current) * 1.5; 
    // السحب لليسار يعرض المنتجات التالية (LTR Logic)
    ref.current.scrollLeft = scrollLeft.current - walk;
  };

  useEffect(() => {
    if (allProducts && allProducts.length > 0) {
        getTopSellingProducts(allProducts).then(setTopProducts);
        setNewArrivals(allProducts.slice(0, 8));
    } else {
        setTopProducts([]);
        setNewArrivals([]);
    }
  }, [allProducts]);
  
  useEffect(() => {
    if (pageType === 'STORE') {
      setVisibleCount(PRODUCTS_PER_PAGE);
    }
  }, [pageType, activeCategory]);

  const renderProductCard = (p: Product) => {
      // --- HOME PAGE SHOWCASE CARD ---
      if (pageType === 'HOME') {
        return (
            <div 
                key={p.id} 
                dir="rtl" // الحفاظ على اتجاه النص العربي داخل البطاقة
                onClick={() => onProductClick(p)} 
                className="group cursor-pointer flex flex-col items-center gap-3 transition-transform duration-500 active:scale-95 w-full"
            >
                <div className="w-full aspect-[3/4] rounded-3xl overflow-hidden relative shadow-md group-hover:shadow-xl transition-all duration-500 border border-black/5 bg-gray-50">
                     <img 
                        src={p.images[0]} 
                        alt={p.name} 
                        loading="lazy" 
                        decoding="async" 
                        className={`w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000 ease-out`} 
                        draggable={false}
                     />
                     <div className="absolute inset-0 bg-gradient-to-t from-black/10 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                     
                     {/* شارة نفذت الكمية - أسفل اليسار */}
                     {p.isOutOfStock && (
                        <div className="absolute bottom-3 left-3 bg-black/90 backdrop-blur-sm text-white px-3 py-1.5 rounded-xl shadow-lg z-10 border border-white/10">
                            <span className="font-bold text-[10px] uppercase tracking-wider">نفذت الكمية</span>
                        </div>
                     )}
                </div>
                <h4 className="font-bold text-sm sm:text-base md:text-lg uppercase tracking-[0.05em] text-center text-gray-800 group-hover:text-black transition-colors px-1 leading-relaxed truncate w-full">
                    {p.name}
                </h4>
            </div>
        );
      }

      const isListView = productDisplayMode === 'VERTICAL_LIST';

      // --- STORE LIST VIEW CARD ---
      if (isListView) {
          return (
              <div key={p.id} dir="rtl" onClick={() => onProductClick(p)} role="listitem"
                   className="bg-white rounded-3xl border border-black/5 shadow-sm hover:shadow-md transition-all group active:scale-95 cursor-pointer relative overflow-hidden flex items-center p-3 sm:p-4 gap-4 w-full">
                  <div className="w-24 h-24 sm:w-32 sm:h-32 flex-shrink-0 rounded-2xl overflow-hidden bg-gray-50 relative border border-black/5 shadow-inner">
                      <img src={p.images[0]} alt={p.name} loading="lazy" decoding="async" className={`w-full h-full object-cover group-hover:scale-110 transition-all duration-1000`} draggable={false} />
                      
                      {/* شارة نفذت الكمية - قائمة */}
                      {p.isOutOfStock && (
                          <div className="absolute bottom-1 left-1 bg-black/90 text-white px-2 py-1 rounded-md shadow-md z-10">
                              <span className="font-bold text-[9px] uppercase tracking-wider">نفذت الكمية</span>
                          </div>
                      )}
                  </div>
                  <div className="flex-grow min-w-0 text-right flex flex-col justify-center gap-1.5">
                      <h4 className="font-bold truncate text-gray-900 uppercase text-sm sm:text-lg tracking-wide leading-tight">{p.name}</h4>
                      <div className="flex flex-wrap gap-1">
                          {(p.sizes && p.sizes.length > 0 ? p.sizes.slice(0, 4) : []).map((s, idx) => {
                              const { value } = parseOption(s);
                              return <span key={idx} className="text-[10px] bg-black/5 px-2 py-0.5 rounded-md border border-black/5 text-black/80 font-bold">{value}</span>
                          })}
                          {p.sizes && p.sizes.length > 4 && <span className="text-[10px] text-gray-400 font-bold self-center">+</span>}
                      </div>
                      <div className="flex items-center gap-2 mt-1">
                          <span className="font-price font-extrabold text-black text-lg sm:text-xl">{Number(p.price).toLocaleString()} <span className="text-[10px] font-bold text-gray-500 font-sans">د.ع</span></span>
                          {p.originalPrice > p.price && <span className="line-through font-bold text-red-400 font-price text-xs">{Number(p.originalPrice).toLocaleString()}</span>}
                      </div>
                  </div>
                  <div className="pl-2 hidden sm:block">
                      <div className="w-10 h-10 flex-shrink-0 bg-black text-white rounded-full flex items-center justify-center shadow-md group-hover:bg-gray-800 transition-all">
                          <ChevronLeft size={18} />
                      </div>
                  </div>
              </div>
          );
      }

      // --- STORE GRID VIEW CARD ---
      return (
        <div key={p.id} dir="rtl" className="bg-white rounded-3xl border border-black/5 shadow-sm hover:shadow-md transition-all group active:scale-95 cursor-pointer relative overflow-hidden flex flex-col p-2.5 h-full" onClick={() => onProductClick(p)} role="listitem">
          <div className="aspect-[3/4] w-full rounded-2xl overflow-hidden bg-gray-50 relative border border-black/5 shadow-inner mb-2">
            <img 
                src={p.images[0]} 
                alt={p.name} 
                loading="lazy" 
                decoding="async" 
                className={`w-full h-full object-cover group-hover:scale-110 transition-all duration-1000`} 
                draggable={false}
            />
            {/* شارة نفذت الكمية - شبكة */}
            {p.isOutOfStock && (
                <div className="absolute bottom-2 left-2 bg-black/90 backdrop-blur-sm text-white px-3 py-1 rounded-lg shadow-lg z-10 border border-white/10">
                    <span className="font-bold text-[10px] sm:text-xs uppercase tracking-widest">نفذت الكمية</span>
                </div>
            )}
            
            {p.offerLabel && <div className="absolute bottom-2 right-2 bg-red-600/90 backdrop-blur-sm text-white px-2 py-1 rounded-lg text-[9px] font-bold uppercase shadow-sm tracking-widest">{p.offerLabel}</div>}
          </div>
          <div className="flex flex-col gap-1.5 flex-grow text-right px-1 pb-1">
            <h4 className="font-bold truncate text-gray-900 uppercase text-xs sm:text-sm tracking-wide leading-tight" title={p.name}>
                {p.name}
            </h4>
            <div className="flex flex-wrap items-baseline gap-2">
                <span className="font-price font-extrabold text-black text-sm sm:text-lg">
                    {Number(p.price).toLocaleString()} <span className="text-[9px] text-gray-500 font-sans">د.ع</span>
                </span>
                {p.originalPrice > p.price && (
                    <span className="line-through font-bold text-red-400 font-price text-[10px] sm:text-xs">
                        {Number(p.originalPrice).toLocaleString()}
                    </span>
                )}
            </div>
          </div>
        </div>
      );
  };


  if (pageType === 'HOME') {
    const hasProducts = topProducts.length > 0 || newArrivals.length > 0;
    
    return (
       <div className="w-full animate-fade-in">
        <section className="relative w-full h-[50vh] sm:h-[60vh] md:h-[80vh] overflow-hidden shadow-xl bg-black group">
            <img src={heroImageUrl} alt="خلفية VANTOR العصرية" loading="eager" className="absolute inset-0 w-full h-full object-cover opacity-80 group-hover:scale-105 transition-all duration-[10s]" />
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-4 sm:p-6 bg-gradient-to-t from-black/80 via-transparent">
                <h2 className="text-3xl sm:text-4xl md:text-6xl lg:text-7xl font-bold text-white leading-none tracking-tighter drop-shadow-2xl uppercase">VANTOR</h2>
                <p className="text-[#FFFFFD] text-sm sm:text-base md:text-xl lg:text-2xl font-bold uppercase tracking-[0.4em] sm:tracking-[0.5em] mt-4 sm:mt-6 opacity-90">أيقونة الفخامة العراقية</p>
                <button onClick={onNavigateToStore} className="mt-8 sm:mt-10 bg-black/40 backdrop-blur-md text-white px-8 py-4 rounded-full font-bold uppercase text-sm sm:text-base border border-white/20 shadow-lg hover:bg-black/60 transition-all active:scale-95 flex items-center gap-3 animate-fade-in">
                  <ShoppingBag size={20}/>
                  المتجر
                </button>
                {showTimer && deadline && <CountdownTimer deadline={deadline} />}
            </div>
        </section>
        
        <div className="max-w-[1400px] mx-auto pb-10 sm:pb-16 space-y-16 overflow-hidden">
           
           {!hasProducts ? (
              <div className="mt-16 px-4">
                 <LuxuryEmptyState />
              </div>
           ) : (
              <>
                {/* --- SELECTED MODELS SLIDER --- */}
                {topProducts.length > 0 && (
                    <div className="mt-16">
                        <div className="flex items-center justify-between px-6 mb-8">
                            <div className="flex items-center gap-2">
                                <Sparkles size={24} className="text-black"/>
                                <h3 className="text-2xl font-bold uppercase tracking-wider">موديلات مختارة</h3>
                            </div>
                        </div>
                        
                        <div 
                            ref={selectedModelsScrollRef} 
                            className="flex overflow-x-auto snap-x snap-mandatory scrollbar-hide w-full gap-4 px-6 pb-6 cursor-grab active:cursor-grabbing"
                            style={{direction: 'ltr'}} 
                            onMouseDown={(e) => startDrag(e, selectedModelsScrollRef)}
                            onMouseLeave={() => stopDrag(selectedModelsScrollRef)}
                            onMouseUp={() => stopDrag(selectedModelsScrollRef)}
                            onMouseMove={(e) => moveDrag(e, selectedModelsScrollRef)}
                        >
                            {topProducts.map(p => (
                                <div key={p.id} className="snap-center flex-shrink-0 w-[45vw] sm:w-[28vw] md:w-[22vw] lg:w-[18vw] select-none">
                                    {renderProductCard(p)}
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                {/* --- NEW ARRIVALS SLIDER --- */}
                {newArrivals.length > 0 && (
                        <div className="pt-10 border-t border-black/5">
                            <div className="flex items-center justify-between px-6 mb-8">
                                <div className="flex items-center gap-2">
                                    <Clock size={24} className="text-black"/>
                                    <h3 className="text-2xl font-bold uppercase tracking-wider">وصل حديثاً</h3>
                                </div>
                            </div>
                            <div 
                                ref={newArrivalsScrollRef} 
                                className="flex overflow-x-auto snap-x snap-mandatory scrollbar-hide w-full gap-4 px-6 pb-6 cursor-grab active:cursor-grabbing"
                                style={{direction: 'ltr'}}
                                onMouseDown={(e) => startDrag(e, newArrivalsScrollRef)}
                                onMouseLeave={() => stopDrag(newArrivalsScrollRef)}
                                onMouseUp={() => stopDrag(newArrivalsScrollRef)}
                                onMouseMove={(e) => moveDrag(e, newArrivalsScrollRef)}
                            >
                                {newArrivals.map(p => (
                                    <div key={p.id} className="snap-center flex-shrink-0 w-[45vw] sm:w-[28vw] md:w-[22vw] lg:w-[18vw] select-none">
                                        {renderProductCard(p)}
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                <div className="flex justify-center pt-8 px-4">
                    <button onClick={onNavigateToStore} className="px-10 py-5 bg-black text-white border-b-4 border-gray-800 rounded-[1.5rem] font-bold uppercase shadow-xl hover:bg-gray-800 transition-all active:scale-95 flex items-center gap-3">
                        <ShoppingBag size={20}/> اكتشف كل الموديلات
                    </button>
                </div>
              </>
           )}
        </div>
       </div>
    );
  }

  // --- STORE PAGE ---
  const visibleProducts = filteredProducts.slice(0, visibleCount);
  const hasMoreProducts = visibleCount < filteredProducts.length;
  const handleShowMore = () => { setVisibleCount(prev => prev + PRODUCTS_PER_PAGE); };
  
  // GRID CALCULATION
  const getGridClasses = () => {
    switch (productDisplayMode) {
      case 'VERTICAL_LIST': return 'grid grid-cols-1 gap-4';
      case 'GRID': default: return 'hidden md:grid md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 md:gap-6'; // Reduced columns for bigger cards
    }
  };
  
  const chunkArray = (array: Product[], size: number) => { const result = []; for (let i = 0; i < array.length; i += size) { result.push(array.slice(i, i + size)); } return result; };
  const mobileChunks = chunkArray(visibleProducts, 4);
  const handleMobileScroll = () => { if (mobileScrollRef.current) { const scrollLeft = Math.abs(mobileScrollRef.current.scrollLeft); const width = mobileScrollRef.current.offsetWidth; const page = Math.round(scrollLeft / width); setActiveMobilePage(page); } };

  return (
    <div className="w-full animate-fade-in">
      <div className="max-w-[1400px] mx-auto px-4 md:px-10 py-10 sm:py-16 space-y-10 sm:space-y-16">
          <div ref={productsGridRef} className="space-y-6">
            <div className="flex justify-between items-center px-2">
                <h3 className="font-bold text-lg uppercase tracking-wider">{activeCategory} <span className="text-gray-400 font-mono text-sm">({filteredProducts.length})</span></h3>
                <div className="flex items-center gap-1 bg-white/50 p-1 rounded-full border border-black/10 shadow-sm">
                    <button onClick={() => setProductDisplayMode('GRID')} className={`p-2 rounded-full transition-colors ${productDisplayMode === 'GRID' ? 'bg-black text-white' : 'hover:bg-black/5'}`} aria-label="عرض شبكي"><Grid size={18} /></button>
                    <button onClick={() => setProductDisplayMode('VERTICAL_LIST')} className={`p-2 rounded-full transition-colors ${productDisplayMode === 'VERTICAL_LIST' ? 'bg-black text-white' : 'hover:bg-black/5'}`} aria-label="عرض قائمة"><List size={18} /></button>
                </div>
            </div>

            {filteredProducts.length > 0 ? (
              <>
                {productDisplayMode === 'GRID' && (
                    <div className="md:hidden relative">
                        <div 
                            ref={mobileScrollRef}
                            onScroll={handleMobileScroll}
                            className="flex overflow-x-auto snap-x snap-mandatory scrollbar-hide w-full gap-5 pb-6 cursor-grab active:cursor-grabbing"
                            style={{direction: 'ltr'}} // LTR لعرض المنتجات من اليسار
                            onMouseDown={(e) => startDrag(e, mobileScrollRef)}
                            onMouseLeave={() => stopDrag(mobileScrollRef)}
                            onMouseUp={() => stopDrag(mobileScrollRef)}
                            onMouseMove={(e) => moveDrag(e, mobileScrollRef)}
                        >
                            {mobileChunks.map((chunk, idx) => (
                                <div key={idx} className="min-w-full snap-center px-1 select-none">
                                    <div className="grid grid-cols-2 gap-4">
                                        {chunk.map(p => renderProductCard(p))}
                                    </div>
                                </div>
                            ))}
                        </div>
                        {mobileChunks.length > 1 && (
                            // إضافة flex-row-reverse لعكس ترتيب النقاط
                            <div className="flex justify-center gap-2 mt-2 flex-row-reverse">
                                {mobileChunks.map((_, idx) => (
                                    <div 
                                        key={idx} 
                                        className={`h-2 rounded-full transition-all duration-300 ${activeMobilePage === idx ? 'w-8 bg-black' : 'w-2 bg-black/20'}`}
                                    ></div>
                                ))}
                            </div>
                        )}
                    </div>
                )}

                <div className={getGridClasses()} dir="ltr">
                  {visibleProducts.map(p => renderProductCard(p))}
                </div>

                {hasMoreProducts && (
                  <div className="flex justify-center pt-8">
                     <button 
                       onClick={handleShowMore} 
                       className="px-10 py-4 bg-white text-black border border-black/10 rounded-[1.5rem] font-bold uppercase shadow-sm hover:bg-black hover:text-white transition-all active:scale-95 flex items-center gap-2"
                     >
                        عرض المزيد <ChevronDown size={20}/>
                     </button>
                  </div>
                )}
              </>
            ) : (
                <LuxuryEmptyState />
            )}
          </div>
      </div>
    </div>
  );
});

export default MainContent;