import React, { useState, useEffect } from 'react';
import { CurrentUser, OrderRecord } from '../types';
import { UserCheck, Save, LogOut, LoaderCircle, Settings, X, Package, ShoppingBag, ChevronLeft, ArrowRight, Briefcase } from 'lucide-react';
import { getUserOrders } from '../services/apiService';

interface ProfileViewProps {
  user: CurrentUser;
  onClose: () => void;
  onUpdateProfile: (profile: { name: string; phone: string; address: string }) => Promise<void>;
  onLogout: () => void;
  isAdmin: boolean;
  isOrderManager: boolean; // NEW PROP
  onAdminPanelClick: () => void;
  onViewOrderDetails: (order: OrderRecord) => void;
}

export default function ProfileView({ user, onClose, onUpdateProfile, onLogout, isAdmin, isOrderManager, onAdminPanelClick, onViewOrderDetails }: ProfileViewProps) {
  const [profileForm, setProfileForm] = useState({ name: '', phone: '', address: '' });
  const [isProfileSaving, setIsProfileSaving] = useState(false);
  const [viewMode, setViewMode] = useState<'PROFILE' | 'ORDERS'>('PROFILE');
  const [userOrders, setUserOrders] = useState<OrderRecord[]>([]);
  const [isLoadingOrders, setIsLoadingOrders] = useState(false);

  useEffect(() => {
    setProfileForm({
      name: user.name || '',
      phone: user.phone || '',
      address: user.address || '',
    });
  }, [user]);

  const handleUpdate = async () => {
    if (!profileForm.name) return;
    setIsProfileSaving(true);
    await onUpdateProfile(profileForm);
    setIsProfileSaving(false);
  };

  const handleShowOrders = async () => {
    setViewMode('ORDERS');
    if (userOrders.length === 0) {
      setIsLoadingOrders(true);
      try {
        const orders = await getUserOrders(user.id);
        setUserOrders(orders);
      } catch (e) {
        console.error("Failed to fetch user orders", e);
      } finally {
        setIsLoadingOrders(false);
      }
    }
  };

  const getStatusLabel = (status: string | undefined) => {
      switch(status) {
          case 'delivered': return { text: 'تم التوصيل', color: 'bg-green-100 text-green-700' };
          case 'out_for_delivery': return { text: 'قيد التوصيل', color: 'bg-blue-100 text-blue-700' };
          case 'cancelled': case 'failed': return { text: 'ملغي', color: 'bg-red-100 text-red-700' };
          case 'returned': return { text: 'راجع', color: 'bg-orange-100 text-orange-700' };
          case 'replacement': return { text: 'استبدال', color: 'bg-purple-100 text-purple-700' };
          case 'processing': default: return { text: 'قيد المعالجة', color: 'bg-yellow-100 text-yellow-700' };
      }
  };

  return (
    <div className="fixed inset-0 z-[600] flex items-center justify-center p-4 bg-black/5 backdrop-blur-sm animate-fade-in" onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} className="bg-[#FFFFFD]/65 backdrop-blur-[50px] w-full max-w-sm p-8 rounded-[2.5rem] shadow-2xl border border-white/40 animate-slide-up text-right space-y-6 relative overflow-hidden flex flex-col max-h-[85vh]">
        <button onClick={onClose} className="absolute top-4 right-4 p-2 text-black hover:bg-black/10 rounded-full transition-colors z-10" aria-label="إغلاق"><X size={20}/></button>
        
        {viewMode === 'PROFILE' ? (
          <>
            <div className="text-center space-y-2">
              <UserCheck size={48} className="mx-auto text-black p-3 bg-white/40 backdrop-blur-md rounded-full shadow-inner border border-white/30" />
              <h3 className="text-2xl font-bold uppercase tracking-tight">ملفي الشخصي</h3>
            </div>
            
            <div className="space-y-3 flex-grow overflow-y-auto custom-scrollbar px-1">
              <input value={profileForm.name} onChange={e => setProfileForm({...profileForm, name: e.target.value})} placeholder="الاسم الكامل" className="w-full p-3 rounded-xl bg-white/60 border border-black/5 outline-none focus:border-black/20 font-bold text-sm backdrop-blur-sm placeholder:text-gray-500" />
              <input type="tel" value={profileForm.phone} onChange={e => setProfileForm({...profileForm, phone: e.target.value.replace(/[^0-9]/g, '')})} placeholder="رقم الهاتف" className="w-full p-3 rounded-xl bg-white/60 border border-black/5 outline-none focus:border-black/20 font-bold text-sm backdrop-blur-sm placeholder:text-gray-500" />
              <textarea value={profileForm.address} onChange={e => setProfileForm({...profileForm, address: e.target.value})} placeholder="العنوان الكامل" className="w-full p-3 rounded-xl bg-white/60 border border-black/5 outline-none focus:border-black/20 font-bold text-sm resize-none h-24 backdrop-blur-sm placeholder:text-gray-500"></textarea>
              <p className="w-full p-3 rounded-xl bg-white/40 border border-black/5 font-bold text-sm text-gray-500 text-center">{user.email}</p>
              
              <button onClick={handleShowOrders} className="w-full py-3 bg-white/60 border border-black/5 text-black rounded-xl font-bold uppercase hover:bg-black hover:text-white active:scale-95 transition-all text-sm flex items-center justify-between px-4 shadow-sm group">
                  <span className="flex items-center gap-2"><ShoppingBag size={18}/> طلباتي</span>
                  <ChevronLeft size={16} className="text-gray-400 group-hover:text-white"/>
              </button>
            </div>

            <div className="border-t border-black/10 pt-4 space-y-3 mt-auto">
              <button onClick={handleUpdate} disabled={isProfileSaving} className="w-full py-3 bg-black text-white rounded-xl font-bold uppercase shadow-lg hover:opacity-90 active:scale-95 transition-all text-base flex items-center justify-center gap-2 disabled:opacity-50">
                {isProfileSaving ? <LoaderCircle size={20} className="animate-spin" /> : <Save size={18} />}
                حفظ التعديلات
              </button>
              
              {(isAdmin || isOrderManager) && (
                <button 
                  onClick={onAdminPanelClick} 
                  className="w-full py-3 bg-white/60 text-black border border-black/10 rounded-xl font-bold uppercase shadow-md hover:bg-black hover:text-white active:scale-95 transition-all text-sm flex items-center justify-center gap-2"
                >
                  {isAdmin ? <Settings size={18} /> : <Briefcase size={18} />}
                  {isAdmin ? 'لوحة التحكم (Admin)' : 'لوحة الموظفين'}
                </button>
              )}
              
              <button onClick={onLogout} className="w-full py-2 bg-transparent text-red-500 rounded-xl font-bold text-xs uppercase hover:bg-red-50/50 active:scale-95 transition-all flex items-center justify-center gap-2">
                <LogOut size={16}/> تسجيل الخروج
              </button>
            </div>
          </>
        ) : (
          <>
            <div className="flex items-center gap-2 pb-2 border-b border-black/10">
                <button onClick={() => setViewMode('PROFILE')} className="p-2 hover:bg-black/5 rounded-full"><ArrowRight size={20}/></button>
                <h3 className="text-xl font-bold uppercase tracking-tight">سجل طلباتي</h3>
            </div>
            
            <div className="flex-grow overflow-y-auto custom-scrollbar space-y-3 p-1">
                {isLoadingOrders ? (
                    <div className="flex justify-center py-10"><LoaderCircle size={32} className="animate-spin text-black/50"/></div>
                ) : userOrders.length === 0 ? (
                    <div className="text-center py-10 space-y-4 opacity-50">
                        <Package size={48} className="mx-auto"/>
                        <p className="font-bold text-sm">لا توجد طلبات سابقة</p>
                    </div>
                ) : (
                    userOrders.map(order => {
                        const status = getStatusLabel(order.status);
                        return (
                            <div key={order.orderId} onClick={() => onViewOrderDetails(order)} className="bg-white/60 backdrop-blur-sm p-4 rounded-2xl border border-black/5 shadow-sm hover:border-black/20 cursor-pointer transition-colors group">
                                <div className="flex justify-between items-center mb-2">
                                    <span className="font-bold text-xs font-mono bg-white/50 px-2 py-0.5 rounded-lg text-gray-600 border border-black/5">{order.orderId}</span>
                                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${status.color}`}>{status.text}</span>
                                </div>
                                <div className="flex justify-between items-end">
                                    <div>
                                        <p className="text-xs text-gray-500 font-bold mb-1">{new Date(order.timestamp).toLocaleDateString('ar-IQ')}</p>
                                        <p className="text-xs font-bold text-gray-800">{order.cartItems.length} منتجات</p>
                                    </div>
                                    <p className="font-extrabold text-sm">{order.finalTotal.toLocaleString()} د.ع</p>
                                </div>
                            </div>
                        );
                    })
                )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}