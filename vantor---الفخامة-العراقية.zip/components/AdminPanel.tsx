import React, { useState, useEffect, useMemo } from 'react';
import { Product, OrderRecord, VisitorRecord } from '../types';
import { STANDARD_SIZE_GUIDE } from '../constants';
import { updateOrderStatus, getOrderManagers, getOrdersPaginated, addCategory, updateCategory, getVisitorStats } from '../services/apiService';
import { Package, List, ChartBar, Edit3, Trash2, X, Loader, Settings, ArrowLeft, Plus, DollarSign, RefreshCw, Search, Filter as FilterIcon, Check, MoreHorizontal, Clock, TrendingUp, Truck, ChevronDown, Smartphone, Monitor, Globe, Link, RotateCcw, Repeat, Tag } from 'lucide-react';
import { parseOption, toggleOptionStock } from '../utils';

interface AdminPanelProps {
  products: Product[];
  categories: string[];
  orders: OrderRecord[];
  onSaveProduct: (product: Partial<Product>) => Promise<boolean>;
  onDeleteProduct: (id: string, name: string) => void;
  onCategoryUpdate: () => void;
  onDeleteCategory: (id: string, name: string) => void;
  onSaveSettings: (settings: any) => void;
  initialHeroUrl: string;
  initialAnnouncement?: string;
  initialTimerEnabled?: boolean;
  initialDeadline?: string;
  initialBgColor?: string;
  initialTextColor?: string;
  initialSpeed?: number;
  initialTiktokUrl?: string;
  initialInstagramUrl?: string;
  initialFacebookUrl?: string;
  initialWhatsappUrl?: string;
  onViewOrderDetails: (order: OrderRecord) => void;
  onClose: () => void;
  isSuperAdmin: boolean;
  onShowAlert: (alert: { message: string, type: 'warning' | 'info' }) => void;
}

// تصميم العدادات المخفف للأداء
const StatCard = ({ title, value, subValue, icon: Icon, variant = 'default', bgClass }: { title: string, value: string, subValue?: string, icon: any, variant?: 'default' | 'profit', bgClass?: string }) => {
    const isProfit = variant === 'profit';
    const isFilled = isProfit || !!bgClass; 
    
    const containerClasses = isFilled 
        ? `${isProfit ? 'bg-black border-black' : bgClass + ' border-transparent'}` 
        : 'bg-white text-black border-black/5';
        
    const textColor = isFilled ? 'text-white' : 'text-black';
    const subTextColor = isFilled ? 'text-white/80' : 'text-black/60';
    
    const iconBgClass = isFilled ? 'bg-white/20 border-white/10' : 'bg-gray-50 border-black/5';
    const iconColor = isFilled ? 'text-white' : 'text-black';
    
    const badgeBgClass = isFilled ? 'bg-white/20 border-white/10 text-white' : 'bg-gray-100 border-black/5 text-gray-600';

    return (
        <div className={`p-5 sm:p-6 rounded-[2rem] relative overflow-hidden group hover:shadow-lg transition-shadow aspect-square flex flex-col justify-between border-2 ${containerClasses} shadow-sm`}>
            <div className="flex justify-between items-start z-10">
                <div className={`p-2.5 sm:p-3 rounded-2xl border ${iconBgClass}`}>
                    <Icon size={20} className={`sm:w-6 sm:h-6 ${iconColor}`} />
                </div>
                {subValue && (
                    <span className={`text-[9px] sm:text-[10px] font-bold px-2 py-1 rounded-full border ${badgeBgClass}`}>
                        {subValue}
                    </span>
                )}
            </div>
            <div className="z-10 mt-2 sm:mt-4">
                <h3 className={`font-black tracking-tight leading-none mb-1 sm:mb-2 text-2xl sm:text-3xl lg:text-4xl ${textColor}`}>
                    {value}
                </h3>
                <p className={`font-bold text-[10px] sm:text-[11px] uppercase tracking-wider ${subTextColor} truncate`}>
                    {title}
                </p>
            </div>
        </div>
    );
};

export default function AdminPanel({
  products, categories, orders: initialOrders,
  onSaveProduct, onDeleteProduct, onCategoryUpdate, onDeleteCategory, onSaveSettings,
  initialHeroUrl, initialAnnouncement = '', initialTimerEnabled = false, initialDeadline = '',
  initialBgColor = '#000000', initialTextColor = '#FFFFFF', initialSpeed = 30, 
  initialTiktokUrl = '', initialInstagramUrl = '', initialFacebookUrl = '', initialWhatsappUrl = '',
  onViewOrderDetails, onClose, isSuperAdmin, onShowAlert
}: AdminPanelProps) {
  const [adminTab, setAdminTab] = useState<'PRODUCTS' | 'CATEGORIES' | 'ORDERS' | 'ANALYTICS' | 'SETTINGS'>(isSuperAdmin ? 'PRODUCTS' : 'ORDERS');
  
  // Product State
  const [editingId, setEditingId] = useState<string | null>(null);
  const [productForm, setProductForm] = useState<Partial<Product>>({
    name: '', price: 25000, originalPrice: 45000, category: '', description: '', images: [], sizes: [], colors: [], sizeGuide: STANDARD_SIZE_GUIDE, isOutOfStock: false, offerLabel: ''
  });
  const [validationErrors, setValidationErrors] = useState<{ [key: string]: boolean }>({});
  const [newImageUrl, setNewImageUrl] = useState('');
  const [newSize, setNewSize] = useState('');
  const [newColor, setNewColor] = useState('#000000'); 
  const [isSaving, setIsSaving] = useState(false);

  // Settings State
  const [heroUrlInput, setHeroUrlInput] = useState(initialHeroUrl);
  const [announcementInput, setAnnouncementInput] = useState(initialAnnouncement);
  const [timerEnabled, setTimerEnabled] = useState(initialTimerEnabled);
  const [deadlineInput, setDeadlineInput] = useState(initialDeadline);
  const [bgColorInput, setBgColorInput] = useState(initialBgColor);
  const [textColorInput, setTextColorInput] = useState(initialTextColor);
  const [speedInput, setSpeedInput] = useState(initialSpeed);
  const [tiktokUrlInput, setTiktokUrlInput] = useState(initialTiktokUrl);
  const [instagramUrlInput, setInstagramUrlInput] = useState(initialInstagramUrl);
  const [facebookUrlInput, setFacebookUrlInput] = useState(initialFacebookUrl);
  const [whatsappUrlInput, setWhatsappUrlInput] = useState(initialWhatsappUrl);
  const [isSettingsSaving, setIsSettingsSaving] = useState(false);

  // Categories State
  const [categoryInput, setCategoryInput] = useState('');
  const [editingCategory, setEditingCategory] = useState<string | null>(null);
  const [isCategorySaving, setIsCategorySaving] = useState(false);

  // Orders State
  const [localOrders, setLocalOrders] = useState<OrderRecord[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [isLoadingMoreOrders, setIsLoadingMoreOrders] = useState(false);

  // Visitors State
  const [visitorStats, setVisitorStats] = useState<VisitorRecord[]>([]);
  const [loadingVisitors, setLoadingVisitors] = useState(false);
  const [sourceFilter, setSourceFilter] = useState<string>('ALL');

  useEffect(() => { setLocalOrders(initialOrders); }, [initialOrders]);
  
  useEffect(() => {
    if (adminTab === 'ANALYTICS') {
        setLoadingVisitors(true);
        getVisitorStats()
            .then(setVisitorStats)
            .finally(() => setLoadingVisitors(false));
    }
  }, [adminTab]);

  const stats = useMemo(() => {
    let revenue = 0;
    let pendingRevenue = 0;
    let cancelledRevenue = 0;
    let returnedRevenue = 0; 
    let replacementRevenue = 0;
    
    let deliveredCount = 0;
    let cancelledCount = 0;
    let returnedCount = 0;
    let replacementCount = 0;
    let processingCount = 0;
    let activeOrders = 0;
    let outForDeliveryCount = 0; 

    localOrders.forEach(o => {
        const amount = Number(o.finalTotal) || 0;
        if (o.status === 'delivered') { revenue += amount; deliveredCount++; } 
        else if (o.status === 'cancelled') { cancelledCount++; cancelledRevenue += amount; } 
        else if (o.status === 'returned') { returnedCount++; returnedRevenue += amount; } 
        else if (o.status === 'replacement') { replacementCount++; replacementRevenue += amount; } 
        else if (o.status === 'processing') { processingCount++; pendingRevenue += amount; activeOrders++; } 
        else if (o.status === 'out_for_delivery') { pendingRevenue += amount; activeOrders++; outForDeliveryCount++; }
    });

    return { totalOrders: localOrders.length, revenue, pendingRevenue, cancelledRevenue, returnedRevenue, replacementRevenue, deliveredCount, cancelledCount, returnedCount, replacementCount, processingCount, activeOrders, outForDeliveryCount };
  }, [localOrders]);
  
  const { sourceCounts, uniqueSources, totalSources } = useMemo(() => {
    const counts: { [key: string]: number } = {};
    let total = 0;
    visitorStats.forEach(v => { const source = v.source || 'مباشر'; counts[source] = (counts[source] || 0) + 1; total++; });
    const sortedEntries = Object.entries(counts).sort(([, a], [, b]) => b - a);
    return { sourceCounts: sortedEntries, uniqueSources: sortedEntries.map(([key]) => key), totalSources: total };
  }, [visitorStats]);

  const filteredVisitorStats = useMemo(() => {
    if (sourceFilter === 'ALL') return visitorStats;
    return visitorStats.filter(v => (v.source || 'مباشر') === sourceFilter);
  }, [visitorStats, sourceFilter]);

  const filteredOrders = useMemo(() => {
    return localOrders.filter(order => {
      const matchesSearch = (order.orderId || '').toLowerCase().includes(searchTerm.toLowerCase()) || (order.customerInfo.name || '').toLowerCase().includes(searchTerm.toLowerCase()) || (order.customerInfo.phone || '').includes(searchTerm);
      const matchesStatus = statusFilter === 'ALL' || order.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [localOrders, searchTerm, statusFilter]);

  const handleLoadMoreOrders = async () => {
      setIsLoadingMoreOrders(true);
      try {
          const currentCount = localOrders.length;
          const newOrders = await getOrdersPaginated(currentCount, currentCount + 49);
          if (newOrders.length > 0) {
              setLocalOrders(prev => {
                  const existingIds = new Set(prev.map(o => o.orderId));
                  const uniqueNewOrders = newOrders.filter(o => !existingIds.has(o.orderId));
                  return [...prev, ...uniqueNewOrders];
              });
          } else {
              onShowAlert({ message: 'لا توجد طلبات أخرى.', type: 'info' });
          }
      } catch (error: any) { onShowAlert({ message: 'فشل تحميل المزيد.', type: 'warning' }); } finally { setIsLoadingMoreOrders(false); }
  };

  const handleStatusChange = async (orderId: string, newStatus: string) => {
      setLocalOrders(prev => prev.map(o => o.orderId === orderId ? { ...o, status: newStatus as any } : o));
      try { await updateOrderStatus(orderId, newStatus); } catch (error) { onShowAlert({ message: 'فشل تحديث الحالة.', type: 'warning' }); }
  };

  const getStatusColor = (status: string) => {
      switch(status) {
          case 'processing': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
          case 'out_for_delivery': return 'bg-blue-100 text-blue-700 border-blue-200';
          case 'delivered': return 'bg-green-100 text-green-700 border-green-200';
          case 'cancelled': return 'bg-red-100 text-red-700 border-red-200';
          case 'returned': return 'bg-orange-100 text-orange-700 border-orange-200';
          case 'replacement': return 'bg-purple-100 text-purple-700 border-purple-200';
          default: return 'bg-gray-100 text-gray-700 border-gray-200';
      }
  };

  const saveProductHandler = async () => {
    const newErrors: { [key: string]: boolean } = {};
    if (!productForm.name?.trim()) newErrors.name = true;
    const cleanCategory = productForm.category?.trim();
    if (!cleanCategory || !categories.includes(cleanCategory)) { onShowAlert({ message: 'يرجى اختيار قسم صالح من القائمة.', type: 'warning' }); newErrors.category = true; }
    if (!productForm.images || productForm.images.length === 0) newErrors.images = true;
    let currentPrice = Number(productForm.price);
    const originalPrice = Number(productForm.originalPrice);
    if ((!currentPrice || currentPrice <= 0) && originalPrice > 0) currentPrice = originalPrice;
    if (isNaN(currentPrice) || currentPrice < 0) { onShowAlert({ message: 'يرجى إدخال سعر صحيح.', type: 'warning' }); newErrors.price = true; }
    if (Object.keys(newErrors).length > 0) { setValidationErrors(newErrors); return; }
    setIsSaving(true);
    try {
        const success = await onSaveProduct({ ...productForm, price: currentPrice, category: cleanCategory });
        if (success) { setEditingId(null); setProductForm({ name: '', price: 25000, originalPrice: 45000, category: '', description: '', images: [], sizes: [], colors: [], sizeGuide: STANDARD_SIZE_GUIDE, isOutOfStock: false, offerLabel: '' }); onShowAlert({ message: 'تم الحفظ بنجاح!', type: 'info' }); }
    } catch (error: any) { onShowAlert({ message: `فشل الحفظ: ${error.message}`, type: 'warning' }); } finally { setIsSaving(false); }
  };

  const handleEditProduct = (p: Product) => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      setEditingId(p.id);
      const categoryExists = categories.includes(p.category);
      setProductForm({ ...p, category: categoryExists ? p.category : '' });
      if (!categoryExists) onShowAlert({ message: `تنبيه: قسم هذا المنتج (${p.category}) غير موجود.`, type: 'warning' });
  };

  const handleSaveCategory = async () => {
    if (!categoryInput.trim()) return;
    setIsCategorySaving(true);
    try {
      if (editingCategory) { await updateCategory(editingCategory, categoryInput); } else { await addCategory(categoryInput); }
      onCategoryUpdate(); setCategoryInput(''); setEditingCategory(null); onShowAlert({ message: 'تم حفظ القسم.', type: 'info' });
    } catch (error: any) { onShowAlert({ message: `فشل: ${error.message}`, type: 'warning' }); } finally { setIsCategorySaving(false); }
  };

  const handleAddImage = () => { if (newImageUrl.trim()) { setProductForm(prev => ({ ...prev, images: [...(prev.images || []), newImageUrl.trim()] })); setNewImageUrl(''); } };
  const handleRemoveImage = (index: number) => { setProductForm(prev => ({ ...prev, images: (prev.images || []).filter((_, i) => i !== index) })); };
  const handleAddSize = () => { const s = newSize.trim().toUpperCase(); if (s && !(productForm.sizes || []).includes(s)) { setProductForm(prev => ({ ...prev, sizes: [...(prev.sizes || []), s] })); setNewSize(''); } };
  const handleRemoveSize = (e: React.MouseEvent, index: number) => { e.stopPropagation(); setProductForm(prev => { const newSizes = (prev.sizes || []).filter((_, i) => i !== index); let newOutOfStock = prev.isOutOfStock; if (newSizes.length === 0) { newOutOfStock = true; onShowAlert({ message: 'تنبيه: تم تحديد المنتج كـ "نافذ" بسبب حذف آخر مقاس.', type: 'warning' }); } return { ...prev, sizes: newSizes, isOutOfStock: newOutOfStock }; }); };
  const handleToggleSizeStock = (index: number) => { setProductForm(prev => { const newSizes = [...(prev.sizes || [])]; newSizes[index] = toggleOptionStock(newSizes[index]); return { ...prev, sizes: newSizes }; }); };
  const handleAddColor = () => { const c = newColor.trim().toUpperCase(); if (c && !(productForm.colors || []).includes(c)) { setProductForm(prev => ({ ...prev, colors: [...(prev.colors || []), c] })); setNewColor('#000000'); } };
  const handleRemoveColor = (e: React.MouseEvent, index: number) => { e.stopPropagation(); setProductForm(prev => { const newColors = (prev.colors || []).filter((_, i) => i !== index); let newOutOfStock = prev.isOutOfStock; if (newColors.length === 0) { newOutOfStock = true; onShowAlert({ message: 'تنبيه: تم تحديد المنتج كـ "نافذ" بسبب حذف آخر لون.', type: 'warning' }); } return { ...prev, colors: newColors, isOutOfStock: newOutOfStock }; }); };
  const handleToggleColorStock = (index: number) => { setProductForm(prev => { const newColors = [...(prev.colors || [])]; newColors[index] = toggleOptionStock(newColors[index]); return { ...prev, colors: newColors }; }); };

  const handleSaveSettings = async () => {
    setIsSettingsSaving(true);
    try {
      await onSaveSettings({ heroImageUrl: heroUrlInput, announcementText: announcementInput, announcementTimerEnabled: timerEnabled, announcementDeadline: deadlineInput, announcementBgColor: bgColorInput, announcementTextColor: textColorInput, announcementSpeed: speedInput, tiktokUrl: tiktokUrlInput, instagramUrl: instagramUrlInput, facebookUrl: facebookUrlInput, whatsappUrl: whatsappUrlInput });
      onShowAlert({ message: 'تم حفظ الإعدادات.', type: 'info' });
    } catch (error: any) { onShowAlert({ message: `فشل: ${error.message}`, type: 'warning' }); } finally { setIsSettingsSaving(false); }
  };

  const NavButton = ({ label, icon: Icon, id, activeId, onClick, danger = false }: any) => (
      <button onClick={() => onClick(id)} className={`w-full py-3 px-4 rounded-xl text-right font-bold text-xs sm:text-sm flex flex-col sm:flex-row items-center sm:justify-between gap-1 transition-all ${activeId === id ? 'bg-black text-white shadow-lg scale-105' : danger ? 'bg-red-50 text-red-500 hover:bg-red-100' : 'bg-white/40 text-gray-600 hover:bg-white/60 hover:text-black'}`} >
        <span className="order-2 sm:order-1">{label}</span><Icon size={18} className="order-1 sm:order-2 mb-1 sm:mb-0"/>
      </button>
  );

  return (
    <div className="max-w-[1600px] mx-auto px-3 sm:px-6 lg:px-8 py-4 sm:py-8 animate-slide-up">
      <div className="flex flex-col lg:flex-row gap-6">
        {/* Navigation Sidebar */}
        <nav className="w-full lg:w-64 flex-shrink-0 flex flex-col gap-4">
            <div className="bg-[#FFFFFD]/65 backdrop-blur-[50px] p-4 sm:p-6 rounded-[2rem] border border-white/40 shadow-xl space-y-4 lg:sticky lg:top-24 z-20">
                <div className="text-center pb-2 border-b border-black/5"><h3 className="font-bold text-xl sm:text-2xl uppercase tracking-tighter">لوحة التحكم</h3></div>
                <div className="grid grid-cols-3 lg:flex lg:flex-col gap-2">
                    {isSuperAdmin && (<><NavButton id="PRODUCTS" activeId={adminTab} onClick={setAdminTab} label="الموديلات" icon={Package} /><NavButton id="CATEGORIES" activeId={adminTab} onClick={setAdminTab} label="الأقسام" icon={List} /></>)}
                    <NavButton id="ORDERS" activeId={adminTab} onClick={setAdminTab} label="الطلبات" icon={ChartBar} />
                    {isSuperAdmin && (<><NavButton id="ANALYTICS" activeId={adminTab} onClick={setAdminTab} label="التحليلات" icon={Globe} /><NavButton id="SETTINGS" activeId={adminTab} onClick={setAdminTab} label="الإعدادات" icon={Settings} /></>)}
                </div>
                <div className="pt-2 border-t border-black/5">
                    <button onClick={onClose} type="button" className="w-full py-3 px-4 rounded-xl text-center sm:text-right font-bold text-xs sm:text-sm flex flex-col sm:flex-row items-center justify-between gap-1 transition-all text-red-500 hover:bg-red-50/50"><span>خروج</span><ArrowLeft size={18}/></button>
                </div>
            </div>
        </nav>

        <main className="flex-grow min-w-0">
            {/* --- ORDERS TAB --- */}
            {adminTab === 'ORDERS' && (
                <div className="space-y-6 animate-fade-in">
                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
                        <StatCard title="صافي الأرباح (واصل)" value={`${stats.revenue.toLocaleString()} د.ع`} icon={DollarSign} variant="profit" />
                        <StatCard title="الربح المعلق" value={`${stats.pendingRevenue.toLocaleString()} د.ع`} subValue={`${stats.activeOrders} طلب`} icon={TrendingUp} bgClass="bg-blue-600" />
                        <StatCard title="قيد التوصيل" value={`${stats.outForDeliveryCount} طلب`} icon={Truck} bgClass="bg-indigo-600" />
                        <StatCard title="إجمالي الطلبات" value={stats.totalOrders.toString()} icon={Package} bgClass="bg-gray-800" />
                        <StatCard title="طلبات ملغاة" value={stats.cancelledCount.toString()} subValue={`${stats.cancelledRevenue.toLocaleString()} د.ع`} icon={X} bgClass="bg-red-600" />
                        <StatCard title="طلبات راجعة" value={stats.returnedCount.toString()} subValue={`${stats.returnedRevenue.toLocaleString()} د.ع`} icon={RotateCcw} bgClass="bg-orange-600" />
                        <StatCard title="طلبات استبدال" value={stats.replacementCount.toString()} subValue={`${stats.replacementRevenue.toLocaleString()} د.ع`} icon={Repeat} bgClass="bg-purple-600" />
                    </div>
                    <div className="bg-[#FFFFFD]/65 backdrop-blur-[50px] p-4 rounded-[2rem] border border-white/40 shadow-sm flex flex-col md:flex-row gap-4 items-center">
                        <div className="relative flex-grow w-full md:w-auto"><Search className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400" size={18}/><input value={searchTerm} onChange={e => setSearchTerm(e.target.value)} placeholder="بحث برقم الطلب، الاسم، أو الهاتف..." className="w-full p-3 pr-11 rounded-2xl border border-black/5 bg-white/50 backdrop-blur-sm font-bold text-sm outline-none focus:border-black/20" /></div>
                        <div className="relative flex-shrink-0 w-full md:w-auto"><FilterIcon className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400" size={18}/><select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} className="w-full md:w-48 p-3 pr-11 rounded-2xl border border-black/5 bg-white/50 backdrop-blur-sm font-bold text-sm outline-none focus:border-black/20 appearance-none"><option value="ALL">كل الحالات</option><option value="processing">قيد المعالجة</option><option value="out_for_delivery">قيد التوصيل</option><option value="delivered">تم التوصيل</option><option value="cancelled">ملغي</option><option value="returned">راجع</option><option value="replacement">استبدال</option></select></div>
                    </div>
                    <div className="bg-transparent rounded-[2.5rem] border-0 p-0 overflow-hidden">
                        <div className="max-h-[600px] overflow-y-auto custom-scrollbar p-2 space-y-3">
                            {filteredOrders.length === 0 && (<div className="text-center py-10 opacity-50"><Package size={48} className="mx-auto mb-2"/><p className="font-bold">لا توجد طلبات مطابقة</p></div>)}
                            {filteredOrders.map(order => (
                                <div key={order.orderId} className="bg-white p-4 sm:p-5 rounded-[2rem] border border-black/5 shadow-sm transition-shadow flex flex-col md:flex-row gap-4 items-start md:items-center justify-between group">
                                    <div className="flex gap-4 items-center flex-grow w-full md:w-auto">
                                        <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-black/5 flex items-center justify-center font-bold text-gray-500 group-hover:bg-black group-hover:text-white transition-colors flex-shrink-0 text-xs sm:text-sm">#{order.orderId.slice(-4)}</div>
                                        <div className="min-w-0"><h4 className="font-bold text-sm truncate">{order.customerInfo.name}</h4><p className="text-xs text-gray-500 font-bold font-mono">{order.customerInfo.phone}</p><p className="text-[10px] text-gray-400 font-bold mt-1 flex items-center gap-1"><Clock size={10}/>{new Date(order.timestamp).toLocaleString('ar-IQ')}</p></div>
                                    </div>
                                    <div className="flex justify-between w-full md:w-auto md:flex-col md:items-end gap-1">
                                        <div className="flex flex-col md:items-end"><span className="font-bold text-sm">{order.finalTotal.toLocaleString()} د.ع</span><span className="text-[10px] text-gray-400 font-bold">{order.cartItems.length} منتجات</span></div>
                                        <div className="flex gap-2 items-center md:hidden"><button onClick={() => onViewOrderDetails(order)} className="p-2 bg-gray-50 rounded-xl border border-black/5"><MoreHorizontal size={16}/></button></div>
                                    </div>
                                    <div className="flex gap-2 w-full md:w-auto items-center mt-2 md:mt-0">
                                        <div className="relative group/status flex-grow md:flex-grow-0"><select value={order.status || 'processing'} onChange={(e) => handleStatusChange(order.orderId, e.target.value)} className={`appearance-none w-full md:w-40 py-2.5 px-4 pr-8 rounded-xl text-xs font-bold border outline-none cursor-pointer transition-all ${getStatusColor(order.status || 'processing')}`}><option value="processing">قيد المعالجة</option><option value="out_for_delivery">قيد التوصيل</option><option value="delivered">تم التوصيل</option><option value="returned">راجع</option><option value="replacement">استبدال</option><option value="cancelled">ملغي</option></select><ChevronDown size={14} className="absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none opacity-50"/></div>
                                        <button onClick={() => onViewOrderDetails(order)} className="hidden md:block p-2.5 bg-gray-50 rounded-xl hover:bg-black hover:text-white transition-colors border border-black/5"><MoreHorizontal size={18}/></button>
                                    </div>
                                </div>
                            ))}
                            <div className="pt-2"><button onClick={handleLoadMoreOrders} disabled={isLoadingMoreOrders} className="w-full py-3 bg-white/50 border border-black/10 rounded-2xl font-bold text-xs text-gray-500 hover:text-black hover:border-black/30 transition-all flex items-center justify-center gap-2">{isLoadingMoreOrders ? <Loader size={16} className="animate-spin"/> : 'تحميل المزيد'}</button></div>
                        </div>
                    </div>
                </div>
            )}
            
            {/* --- ANALYTICS TAB (FIXED RESPONSIVENESS) --- */}
            {adminTab === 'ANALYTICS' && isSuperAdmin && (
                <div className="w-full space-y-6 animate-fade-in">
                    <div className="bg-[#FFFFFD]/65 backdrop-blur-[50px] p-6 rounded-[3rem] shadow-xl border border-white/40">
                        <div className="flex justify-between items-center mb-6"><h4 className="text-xl sm:text-2xl font-bold uppercase flex items-center gap-3"><Globe size={24}/> تحليلات الزوار</h4><button onClick={() => { setLoadingVisitors(true); getVisitorStats().then(setVisitorStats).finally(() => setLoadingVisitors(false)); }} className="p-3 bg-white/50 rounded-full shadow-sm hover:rotate-180 transition-all duration-500"><RefreshCw size={20}/></button></div>
                        {loadingVisitors ? (<div className="flex justify-center py-20"><Loader size={40} className="animate-spin text-black/20"/></div>) : visitorStats.length === 0 ? (<div className="text-center py-20 opacity-50 font-bold">لم يتم تسجيل أي زيارات بعد.</div>) : (
                            <div className="grid lg:grid-cols-3 gap-6">
                                {/* Column 1: Source Breakdown */}
                                <div className="lg:col-span-1 bg-white/40 backdrop-blur-md rounded-[2rem] border border-black/5 p-4 space-y-3">
                                    <h5 className="font-bold text-sm text-center uppercase text-gray-500 pb-2 border-b border-black/5">مصادر الزيارات</h5>
                                    <div className="space-y-2 max-h-96 overflow-y-auto custom-scrollbar pr-1">
                                        {sourceCounts.map(([source, count]) => { const percentage = totalSources > 0 ? (count / totalSources) * 100 : 0; return (<div key={source} className="text-xs font-bold"><div className="flex justify-between items-center mb-1"><span className="truncate text-gray-800">{source}</span><span className="text-gray-500">{count}</span></div><div className="w-full bg-black/5 rounded-full h-1.5"><div className="bg-black h-1.5 rounded-full" style={{ width: `${percentage}%` }}></div></div></div>); })}
                                    </div>
                                </div>
                                {/* Column 2: Visitor List & Stats */}
                                <div className="lg:col-span-2 space-y-4">
                                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                        <div className="bg-white/40 backdrop-blur-md p-4 rounded-2xl border border-black/5 shadow-sm text-center"><p className="text-xs text-gray-400 font-bold uppercase">إجمالي الزيارات</p><p className="text-2xl font-black">{visitorStats.length}</p></div>
                                        <div className="bg-white/40 backdrop-blur-md p-4 rounded-2xl border border-black/5 shadow-sm text-center"><p className="text-xs text-gray-400 font-bold uppercase">الهواتف</p><p className="text-2xl font-black">{visitorStats.filter(v => v.device_type === 'Mobile').length}</p></div>
                                        <div className="bg-white/40 backdrop-blur-md p-4 rounded-2xl border border-black/5 shadow-sm text-center"><p className="text-xs text-gray-400 font-bold uppercase">الحواسيب</p><p className="text-2xl font-black">{visitorStats.filter(v => v.device_type === 'Desktop').length}</p></div>
                                        <div className="bg-white/40 backdrop-blur-md p-4 rounded-2xl border border-black/5 shadow-sm text-center"><p className="text-xs text-gray-400 font-bold uppercase">آخر زيارة</p><p className="text-lg font-black font-mono" dir="ltr">{new Date(visitorStats[0]?.created_at).toLocaleTimeString('en-US', {hour: '2-digit', minute:'2-digit'})}</p></div>
                                    </div>

                                    {/* Responsive Visitor Log */}
                                    <div className="bg-white/40 backdrop-blur-md rounded-[2rem] md:rounded-[2.5rem] border border-black/5 overflow-hidden flex flex-col">
                                        <div className="p-3 border-b border-black/5 flex items-center gap-3 bg-white/30">
                                            <label htmlFor="source-filter" className="font-bold text-xs text-gray-500 flex-shrink-0">تصفية:</label>
                                            <div className="relative flex-grow">
                                                <FilterIcon className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={14}/>
                                                <select id="source-filter" value={sourceFilter} onChange={e => setSourceFilter(e.target.value)} className="w-full p-2 pr-8 rounded-xl border border-black/5 bg-white/50 backdrop-blur-sm font-bold text-xs outline-none focus:border-black/20 appearance-none">
                                                    <option value="ALL">كل المصادر</option>{uniqueSources.map(source => (<option key={source} value={source}>{source}</option>))}
                                                </select>
                                            </div>
                                        </div>
                                        
                                        {/* Desktop Table View */}
                                        <div className="hidden md:block overflow-x-auto">
                                            <table className="w-full text-right">
                                                <thead className="bg-gray-50/50 border-b border-black/5 text-gray-500 font-bold text-xs uppercase"><tr><th className="p-4">الوقت</th><th className="p-4">الموقع</th><th className="p-4">الجهاز</th><th className="p-4">المصدر</th></tr></thead>
                                                <tbody className="divide-y divide-gray-100/50">
                                                    {filteredVisitorStats.map((visit) => (
                                                        <tr key={visit.id} className="hover:bg-gray-50/50 transition-colors">
                                                            <td className="p-4 font-bold text-xs font-mono text-gray-600" dir="ltr">{new Date(visit.created_at).toLocaleString('en-US')}</td>
                                                            <td className="p-4 font-bold text-sm">{visit.city !== 'Unknown' ? `${visit.city}, ${visit.country}` : <span className="text-gray-400">غير محدد</span>}</td>
                                                            <td className="p-4"><div className="flex items-center gap-2">{visit.device_type === 'Mobile' ? <Smartphone size={16} className="text-blue-500"/> : <Monitor size={16} className="text-purple-500"/>}<span className="font-bold text-xs">{visit.os}</span></div></td>
                                                            <td className="p-4"><div className="flex items-center gap-2"><Link size={14} className="text-gray-400"/><span className="font-bold text-xs text-gray-700">{visit.source || 'مباشر'}</span></div></td>
                                                        </tr>
                                                    ))}
                                                </tbody>
                                            </table>
                                        </div>

                                        {/* Mobile Card List View */}
                                        <div className="md:hidden max-h-[60vh] overflow-y-auto custom-scrollbar p-3 space-y-3">
                                            {filteredVisitorStats.map((visit) => (
                                                <div key={visit.id} className="bg-white/60 p-4 rounded-2xl border border-black/5 shadow-sm flex flex-col gap-2">
                                                    <div className="flex justify-between items-center border-b border-black/5 pb-2 mb-1">
                                                        <span className="font-bold text-xs text-black flex items-center gap-1.5"><Link size={12} className="text-gray-400"/>{visit.source || 'مباشر'}</span>
                                                        <span className="text-[10px] font-bold font-mono text-gray-400" dir="ltr">{new Date(visit.created_at).toLocaleTimeString('en-US', {hour: '2-digit', minute:'2-digit'})}</span>
                                                    </div>
                                                    <div className="flex justify-between items-center">
                                                        <div className="flex items-center gap-1.5 bg-gray-50 px-2 py-1 rounded-lg">
                                                            {visit.device_type === 'Mobile' ? <Smartphone size={14} className="text-blue-500"/> : <Monitor size={14} className="text-purple-500"/>}
                                                            <span className="text-[10px] font-bold text-gray-600">{visit.os}</span>
                                                        </div>
                                                        <span className="text-xs font-bold text-gray-800">{visit.city !== 'Unknown' ? visit.city : 'غير محدد'}</span>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            )}

            {/* --- PRODUCTS TAB --- */}
            {adminTab === 'PRODUCTS' && isSuperAdmin && (
               <div className="flex flex-col xl:flex-row gap-6 animate-fade-in">
                  <section className="w-full xl:w-7/12 bg-[#FFFFFD]/65 backdrop-blur-[50px] p-6 sm:p-8 rounded-[3rem] shadow-xl border border-white/40 flex flex-col">
                    <h4 className="text-xl sm:text-2xl font-bold uppercase mb-6 flex items-center gap-3"><Edit3 size={24}/>{editingId ? 'تعديل موديل' : 'إضافة موديل'}</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                          <div className="space-y-1"><label className="font-bold text-xs text-gray-400 uppercase">اسم الموديل</label><input value={productForm.name || ''} onChange={e => setProductForm({...productForm, name: e.target.value})} className={`w-full p-4 rounded-2xl bg-white/50 backdrop-blur-sm border font-bold ${validationErrors.name ? 'border-red-500' : 'border-black/10'}`} /></div>
                          <div className="space-y-1"><label className="font-bold text-xs text-gray-400 uppercase">القسم</label><select value={productForm.category || ''} onChange={e => setProductForm({...productForm, category: e.target.value})} className={`w-full p-4 rounded-2xl bg-white/50 backdrop-blur-sm border font-bold text-sm ${validationErrors.category ? 'border-red-500' : 'border-black/10'}`}><option value="">اختر القسم</option>{categories.map(c => <option key={c} value={c}>{c}</option>)}</select></div>
                          <div className="grid grid-cols-2 gap-4">
                              <div className="space-y-1"><label className="font-bold text-xs text-gray-400 uppercase">السعر الأصلي (قبل الخصم)</label><input type="number" value={productForm.originalPrice || ''} onChange={e => setProductForm({...productForm, originalPrice: Number(e.target.value)})} className="w-full p-4 rounded-2xl bg-white/50 backdrop-blur-sm border border-black/10 font-bold font-price" placeholder="45000"/></div>
                              <div className="space-y-1"><label className="font-bold text-xs text-gray-400 uppercase">السعر الحالي (بعد الخصم)</label><input type="number" value={productForm.price || ''} onChange={e => setProductForm({...productForm, price: Number(e.target.value)})} className={`w-full p-4 rounded-2xl bg-white/50 backdrop-blur-sm border font-bold font-price ${validationErrors.price ? 'border-red-500' : 'border-black/10'}`} placeholder="25000"/></div>
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-1"><label className="font-bold text-xs text-gray-400 uppercase">علامة مميزة</label><input value={productForm.offerLabel || ''} onChange={e => setProductForm({...productForm, offerLabel: e.target.value})} placeholder="جديد / خصم" className="w-full p-4 rounded-2xl bg-white/50 backdrop-blur-sm border border-black/10 font-bold text-xs" /></div>
                                <div className="flex items-end"><label className={`w-full p-4 rounded-2xl border cursor-pointer flex items-center justify-center gap-2 transition-all ${productForm.isOutOfStock ? 'bg-red-500 text-white border-red-600 shadow-md' : 'bg-white/50 border-black/10 text-gray-500 hover:bg-white'}`}><input type="checkbox" checked={productForm.isOutOfStock || false} onChange={e => setProductForm({...productForm, isOutOfStock: e.target.checked})} className="hidden" /><span className="font-bold text-xs uppercase">{productForm.isOutOfStock ? 'المنتج نافذ' : 'متوفر'}</span>{productForm.isOutOfStock ? <X size={16}/> : <Check size={16}/>}</label></div>
                          </div>
                      </div>
                      <div className="space-y-4">
                          <div className={`p-4 bg-white/40 backdrop-blur-md rounded-2xl border space-y-2 ${validationErrors.images ? 'border-red-500' : 'border-black/5'}`}><label className="font-bold text-xs text-gray-400 uppercase">الصور</label><div className="flex gap-2"><input value={newImageUrl} onChange={e => setNewImageUrl(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleAddImage()} placeholder="URL الصورة" className="flex-1 min-w-0 p-3 rounded-xl bg-white/60 border border-black/5 text-xs font-bold" dir="ltr" /><button onClick={handleAddImage} className="w-12 flex-shrink-0 bg-black text-white rounded-xl font-bold">+</button></div><div className="flex flex-wrap gap-2 pt-2">{(productForm.images || []).map((img, i) => <img key={i} src={img} className="w-12 h-12 object-cover rounded-lg cursor-pointer border border-black/10" onClick={() => handleRemoveImage(i)} alt="" />)}</div></div>
                          <div className="p-4 bg-white/40 backdrop-blur-md rounded-2xl border border-black/5 space-y-2"><label className="font-bold text-xs text-gray-400 uppercase">المقاسات</label><div className="flex gap-2"><input value={newSize} onChange={e => setNewSize(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleAddSize()} placeholder="مثال: XL" className="flex-1 min-w-0 p-3 rounded-xl bg-white/60 border border-black/5 text-xs font-bold" /><button onClick={handleAddSize} className="w-12 flex-shrink-0 bg-black text-white rounded-xl font-bold">+</button></div><div className="flex flex-wrap items-center gap-2 pt-2">{(productForm.sizes || []).map((s, i) => { const { value, isSoldOut } = parseOption(s); return (<div key={i} onClick={() => handleToggleSizeStock(i)} className={`h-8 px-3 rounded-lg border-2 shadow-sm cursor-pointer flex items-center justify-center font-bold text-xs relative ${isSoldOut ? 'bg-gray-100 text-gray-400 border-gray-200 line-through decoration-red-500/80 decoration-2' : 'bg-white text-black border-black/10'}`}>{value}<button onClick={(e) => handleRemoveSize(e, i)} className="absolute -top-1 -right-1 w-4 h-4 bg-white text-red-500 rounded-full border shadow-sm flex items-center justify-center">×</button></div>); })}</div></div>
                          <div className="p-4 bg-white/40 backdrop-blur-md rounded-2xl border border-black/5 space-y-2"><label className="font-bold text-xs text-gray-400 uppercase">الألوان</label><div className="flex gap-2 items-center"><input type="color" value={newColor} onChange={e => setNewColor(e.target.value)} className="h-12 w-12 rounded-xl cursor-pointer bg-white p-1 border border-black/5" /><button onClick={handleAddColor} className="flex-grow h-12 bg-black text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2"><Plus size={16}/>إضافة</button></div><div className="flex flex-wrap gap-2 pt-2">{(productForm.colors || []).map((c, i) => { const { value, isSoldOut } = parseOption(c); return (<div key={i} onClick={() => handleToggleColorStock(i)} style={{backgroundColor: value}} className={`w-8 h-8 rounded-full border-2 shadow-sm cursor-pointer relative ${isSoldOut ? 'border-red-500' : 'border-white'}`}>{isSoldOut && <div className="absolute inset-0 flex items-center justify-center bg-black/10 rounded-full"><div className="w-full h-0.5 bg-red-500 rotate-45"></div></div>}<button onClick={(e) => handleRemoveColor(e, i)} className="absolute -top-1 -right-1 w-4 h-4 bg-white text-red-500 rounded-full border shadow-sm">×</button></div>); })}</div></div>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                        <div className="space-y-1"><label className="font-bold text-xs text-gray-400 uppercase">الوصف</label><textarea value={productForm.description || ''} onChange={e => setProductForm({...productForm, description: e.target.value})} className="w-full p-4 rounded-2xl bg-white/50 backdrop-blur-sm border border-black/10 font-bold text-sm h-32 resize-none"></textarea></div>
                        <div className="space-y-1"><label className="font-bold text-xs text-gray-400 uppercase">دليل المقاسات الذكي</label><textarea value={productForm.sizeGuide || ''} onChange={e => setProductForm({...productForm, sizeGuide: e.target.value})} className="w-full p-4 rounded-2xl bg-white/50 backdrop-blur-sm border border-black/10 font-bold text-sm h-32 resize-none"></textarea></div>
                    </div>
                    <div className="flex gap-4 mt-8 pt-8 border-t border-black/5"><button onClick={saveProductHandler} disabled={isSaving} className="flex-grow py-4 bg-black text-white rounded-[1.8rem] font-bold uppercase shadow-2xl active:scale-95 disabled:opacity-50 flex items-center justify-center">{isSaving ? <Loader size={22} className="animate-spin" /> : (editingId ? 'تحديث الموديل' : 'إضافة الموديل')}</button>{editingId && (<button onClick={() => { setEditingId(null); setProductForm({ name: '', price: 25000, originalPrice: 45000, category: '', description: '', images: [], sizes: [], colors: [], sizeGuide: STANDARD_SIZE_GUIDE, isOutOfStock: false, offerLabel: '' }); }} className="px-6 bg-white/50 text-black border border-black/10 rounded-[1.8rem]"><X size={20}/></button>)}</div>
                  </section>
                  <section className="w-full xl:w-5/12 bg-[#FFFFFD]/65 backdrop-blur-[50px] p-6 rounded-[3rem] shadow-xl border border-white/40 max-h-[80vh] flex flex-col"><h4 className="text-xl font-bold uppercase mb-4 flex-shrink-0">قائمة الموديلات</h4>
                  <div className="overflow-y-auto custom-scrollbar -mr-2 pr-2 space-y-3">
                      {products.map(p => (
                          <div key={p.id} className="flex gap-3 bg-white/40 backdrop-blur-sm p-3 rounded-2xl border border-black/5 items-center">
                              <img src={p.images[0]} alt={p.name} className="w-12 h-12 object-cover rounded-lg flex-shrink-0" />
                              <div className="flex-grow min-w-0"><div className="flex items-center gap-2 mb-0.5"><p className="font-bold truncate text-sm">{p.name}</p>{p.offerLabel && <span className="flex-shrink-0 bg-red-100 text-red-600 text-[9px] px-1.5 py-0.5 rounded-md font-bold border border-red-200">{p.offerLabel}</span>}</div><div className="flex items-center gap-2"><p className="text-xs text-gray-500 font-bold font-price">{p.price.toLocaleString()} د.ع</p>{p.originalPrice > p.price && <span className="text-[10px] text-red-300 line-through font-bold font-price">{p.originalPrice.toLocaleString()}</span>}</div></div>
                              <div className="flex gap-2 flex-shrink-0"><button onClick={() => handleEditProduct(p)} className="p-2 bg-gray-100/50 rounded-lg hover:bg-black hover:text-white transition-colors"><Edit3 size={14}/></button><button onClick={() => onDeleteProduct(p.id, p.name)} className="p-2 bg-red-50/50 text-red-500 rounded-lg hover:bg-red-500 hover:text-white transition-colors"><Trash2 size={14}/></button></div>
                          </div>
                      ))}
                  </div>
                  </section>
               </div>
            )}

            {/* --- CATEGORIES & SETTINGS TABS (Kept as is) --- */}
            {adminTab === 'CATEGORIES' && isSuperAdmin && (
                <div className="w-full bg-[#FFFFFD]/65 backdrop-blur-[50px] p-6 md:p-8 rounded-[3rem] shadow-xl border border-white/40 animate-fade-in space-y-8">
                    <h4 className="text-2xl font-bold uppercase flex items-center gap-3"><List size={24}/> إدارة الأقسام</h4>
                    <div className="flex flex-col sm:flex-row gap-3 max-w-2xl mx-auto w-full"><input value={categoryInput} onChange={(e) => setCategoryInput(e.target.value)} placeholder="اسم القسم الجديد..." className="flex-grow p-4 rounded-2xl bg-white/50 backdrop-blur-sm border border-black/10 font-bold"/><button onClick={handleSaveCategory} disabled={isCategorySaving} className="px-6 py-4 sm:py-0 bg-black text-white rounded-2xl font-bold uppercase shadow-lg active:scale-95 disabled:opacity-50 flex items-center justify-center">{isCategorySaving ? <Loader size={20} className="animate-spin"/> : <Plus size={24}/>}</button></div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4 max-h-[60vh] overflow-y-auto custom-scrollbar pr-2">
                        {categories.map(cat => (<div key={cat} className="flex justify-between items-center bg-white/40 backdrop-blur-md p-4 rounded-2xl border border-black/5 shadow-sm hover:border-black/20 transition-all"><span className="font-bold text-sm md:text-base truncate">{cat}</span><div className="flex gap-2 flex-shrink-0"><button onClick={() => { setCategoryInput(cat); setEditingCategory(cat); }} className="p-2 bg-gray-100/50 rounded-xl hover:bg-black hover:text-white transition-colors"><Edit3 size={16}/></button><button onClick={() => onDeleteCategory('cat_id', cat)} className="p-2 bg-red-50/50 text-red-500 rounded-xl hover:bg-red-500 hover:text-white transition-colors"><Trash2 size={16}/></button></div></div>))}
                        {categories.length === 0 && <p className="col-span-full text-center text-gray-400 font-bold py-10">لا توجد أقسام حالياً</p>}
                    </div>
                </div>
            )}
            {adminTab === 'SETTINGS' && isSuperAdmin && (
                 <section className="bg-[#FFFFFD]/65 backdrop-blur-[50px] p-8 rounded-[3rem] shadow-xl border border-white/40 animate-fade-in space-y-6">
                    <h4 className="text-2xl font-bold uppercase flex items-center gap-3"><Settings size={24}/>إعدادات المتجر</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2"><label className="font-bold text-xs text-gray-400 uppercase">الصورة الرئيسية للمتجر</label><input value={heroUrlInput} onChange={e => setHeroUrlInput(e.target.value)} className="w-full p-4 rounded-2xl bg-white/50 backdrop-blur-sm border border-black/10 font-bold text-xs" dir="ltr" placeholder="https://..." /></div>
                        <div className="space-y-2"><label className="font-bold text-xs text-gray-400 uppercase">نص شريط الإعلان</label><input value={announcementInput} onChange={e => setAnnouncementInput(e.target.value)} className="w-full p-4 rounded-2xl bg-white/50 backdrop-blur-sm border border-black/10 font-bold" /></div>
                    </div>
                    <div className="bg-white/40 backdrop-blur-md p-6 rounded-2xl border border-black/5 space-y-4">
                        <h5 className="font-bold text-sm uppercase">روابط التواصل الاجتماعي</h5>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div className="space-y-2"><label className="font-bold text-xs text-gray-400 uppercase">فيسبوك</label><input value={facebookUrlInput} onChange={e => setFacebookUrlInput(e.target.value)} className="w-full p-3 rounded-xl bg-white/60 border border-black/10 font-bold text-xs" dir="ltr" /></div>
                            <div className="space-y-2"><label className="font-bold text-xs text-gray-400 uppercase">انستغرام</label><input value={instagramUrlInput} onChange={e => setInstagramUrlInput(e.target.value)} className="w-full p-3 rounded-xl bg-white/60 border border-black/10 font-bold text-xs" dir="ltr" /></div>
                            <div className="space-y-2"><label className="font-bold text-xs text-gray-400 uppercase">تيك توك</label><input value={tiktokUrlInput} onChange={e => setTiktokUrlInput(e.target.value)} className="w-full p-3 rounded-xl bg-white/60 border border-black/10 font-bold text-xs" dir="ltr" /></div>
                            <div className="space-y-2"><label className="font-bold text-xs text-gray-400 uppercase">واتساب</label><input value={whatsappUrlInput} onChange={e => setWhatsappUrlInput(e.target.value)} className="w-full p-3 rounded-xl bg-white/60 border border-black/10 font-bold text-xs" dir="ltr" placeholder="https://wa.me/964..." /></div>
                        </div>
                    </div>
                    <div className="bg-white/40 backdrop-blur-md p-6 rounded-2xl border border-black/5 space-y-4">
                        <h5 className="font-bold text-sm uppercase">إعدادات المؤقت والأسلوب</h5>
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                            <div className="space-y-2"><label className="font-bold text-xs text-gray-400 uppercase">تاريخ الانتهاء</label><input type="datetime-local" value={deadlineInput} onChange={e => setDeadlineInput(e.target.value)} className="w-full p-3 rounded-xl bg-white/60 border border-black/10 font-bold text-xs" /></div>
                            <div className="space-y-2"><label className="font-bold text-xs text-gray-400 uppercase">سرعة الحركة (ث)</label><input type="number" value={speedInput} onChange={e => setSpeedInput(Number(e.target.value))} className="w-full p-3 rounded-xl bg-white/60 border border-black/10 font-bold text-xs" /></div>
                            <div className="flex items-center gap-4">
                                <div className="space-y-2"><label className="font-bold text-xs text-gray-400 uppercase">لون الخلفية</label><input type="color" value={bgColorInput} onChange={e => setBgColorInput(e.target.value)} className="w-16 h-12 p-1 rounded-xl bg-white border border-black/10" /></div>
                                <div className="space-y-2"><label className="font-bold text-xs text-gray-400 uppercase">لون النص</label><input type="color" value={textColorInput} onChange={e => setTextColorInput(e.target.value)} className="w-16 h-12 p-1 rounded-xl bg-white border border-black/10" /></div>
                            </div>
                            <div className="flex items-center pt-5"><label className="flex items-center gap-3 cursor-pointer p-3 bg-white/50 rounded-2xl border border-black/5"><input type="checkbox" checked={timerEnabled} onChange={e => setTimerEnabled(e.target.checked)} className="accent-black w-6 h-6" /><span className="font-bold text-xs uppercase">تفعيل المؤقت</span></label></div>
                        </div>
                    </div>
                    <button onClick={handleSaveSettings} disabled={isSettingsSaving} className="w-full py-4 bg-black text-white rounded-2xl font-bold uppercase shadow-xl flex items-center justify-center disabled:opacity-50">{isSettingsSaving ? <Loader size={20} className="animate-spin"/> : 'حفظ الإعدادات'}</button>
                </section>
            )}
        </main>
      </div>
    </div>
  );
}