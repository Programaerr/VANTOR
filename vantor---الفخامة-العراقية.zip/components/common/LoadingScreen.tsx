import React from 'react';

export default function LoadingScreen() {
  return (
    <div className="fixed inset-0 z-[2000] bg-[#FFFFFD] flex flex-col items-center justify-center animate-fade-in">
      <div className="relative flex flex-col items-center gap-6">
        <h1 className="text-5xl md:text-7xl font-bold tracking-tighter animate-pulse uppercase">VANTOR</h1>
        <div className="w-32 h-1 bg-black/10 rounded-full overflow-hidden">
           <div className="h-full bg-black animate-loading-bar w-1/3 rounded-full"></div>
        </div>
      </div>

      <style>{`
        @keyframes loading-bar {
          0% { transform: translateX(-150%); }
          50% { transform: translateX(100%); }
          100% { transform: translateX(300%); }
        }
        .animate-loading-bar {
          animation: loading-bar 1.5s infinite ease-in-out;
        }
      `}</style>
    </div>
  );
}