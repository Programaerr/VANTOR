
import React, { useEffect, useRef } from 'react';
import { AlertTriangle, CheckCircle2, X } from 'lucide-react';

interface AlertProps {
  showAlert: { message: string; type: 'warning' | 'info' } | null;
  onClose: () => void;
}

export default function Alert({ showAlert, onClose }: AlertProps) {
  if (!showAlert) {
    return null;
  }

  return (
    <div
      className={`fixed top-20 left-1/2 -translate-x-1/2 z-[1000] w-[90%] max-w-sm sm:max-w-md p-4 rounded-2xl shadow-2xl border flex items-center justify-between gap-3 animate-fade-in-down ${showAlert.type === 'warning' ? 'bg-red-50 border-red-200' : 'bg-green-50 border-green-200'} backdrop-blur-md`}
      role="alert"
      aria-live="assertive"
    >
      <style>{`
        @keyframes fade-in-down {
          from { opacity: 0; transform: translate(-50%, -20px); }
          to { opacity: 1; transform: translate(-50%, 0); }
        }
        .animate-fade-in-down { animation: fade-in-down 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
      `}</style>
      
      {showAlert.type === 'warning' ? (
        <AlertTriangle size={24} className="text-red-600 flex-shrink-0" />
      ) : (
        <CheckCircle2 size={24} className="text-green-600 flex-shrink-0" />
      )}
      
      <span className="text-sm font-bold text-black flex-grow text-right leading-snug">{showAlert.message}</span>
      <button onClick={onClose} className="p-1.5 text-black/40 hover:text-black hover:bg-black/5 rounded-full flex-shrink-0 transition-colors" aria-label="إغلاق التنبيه">
        <X size={18}/>
      </button>
    </div>
  );
}
