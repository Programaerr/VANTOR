// =================================================================================
// VANTOR – TELEGRAM SENDER & WORD INVOICE GENERATOR (DOCX) - v53 (QR Code & English Numerals)
// =================================================================================

declare const Deno: {
  env: {
    get: (key: string) => string | undefined;
  };
};

import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { 
  Document, Packer, Paragraph, Table, TableCell, TableRow, WidthType, 
  TextRun, AlignmentType, BorderStyle, VerticalAlign, PageOrientation, ImageRun
} from "https://esm.sh/docx@8.5.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "x-client-info, apikey, content-type, authorization",
};

// FIX: Use en-US locale for English numerals but keep the Arabic currency symbol.
function formatCurrency(num: number): string {
  return `${Number(num).toLocaleString('en-US')} د.ع`;
}

// FIX: Added full implementation for createInvoiceDocx to ensure it returns a value.
async function createInvoiceDocx(order: any): Promise<Uint8Array> {
  const VANTOR_BLACK = "000000";
  const VANTOR_WHITE = "FFFFFF";
  const VANTOR_BG = "FFFFFD"; 
  
  // FIX: Reconstruct date to ensure English numerals for day and year.
  const d = new Date(order.timestamp);
  const orderDate = `${d.getDate()} ${d.toLocaleString('ar-IQ', { month: 'long' })} ${d.getFullYear()}`;


  // 1. Build Items Table Rows (No Changes Here)
  const tableHeaderCells = [
    new TableCell({ width: { size: 40, type: WidthType.PERCENTAGE }, children: [new Paragraph({ text: "القطعة", alignment: AlignmentType.CENTER, style: "HeaderStyle" })], shading: { fill: VANTOR_BLACK }, verticalAlign: VerticalAlign.CENTER }),
    new TableCell({ width: { size: 15, type: WidthType.PERCENTAGE }, children: [new Paragraph({ text: "النوع", alignment: AlignmentType.CENTER, style: "HeaderStyle" })], shading: { fill: VANTOR_BLACK }, verticalAlign: VerticalAlign.CENTER }),
    new TableCell({ width: { size: 10, type: WidthType.PERCENTAGE }, children: [new Paragraph({ text: "القياس", alignment: AlignmentType.CENTER, style: "HeaderStyle" })], shading: { fill: VANTOR_BLACK }, verticalAlign: VerticalAlign.CENTER }),
    new TableCell({ width: { size: 10, type: WidthType.PERCENTAGE }, children: [new Paragraph({ text: "العدد", alignment: AlignmentType.CENTER, style: "HeaderStyle" })], shading: { fill: VANTOR_BLACK }, verticalAlign: VerticalAlign.CENTER }),
    new TableCell({ width: { size: 10, type: WidthType.PERCENTAGE }, children: [new Paragraph({ text: "اللون", alignment: AlignmentType.CENTER, style: "HeaderStyle" })], shading: { fill: VANTOR_BLACK }, verticalAlign: VerticalAlign.CENTER }),
    new TableCell({ width: { size: 15, type: WidthType.PERCENTAGE }, children: [new Paragraph({ text: "السعر", alignment: AlignmentType.CENTER, style: "HeaderStyle" })], shading: { fill: VANTOR_BLACK }, verticalAlign: VerticalAlign.CENTER }),
  ];
  const tableRows = [new TableRow({ tableHeader: true, children: tableHeaderCells })];
  (order.cartItems || []).forEach((item: any) => {
    const lineTotal = item.price * item.quantity;
    const nameCell = new TableCell({ width: { size: 40, type: WidthType.PERCENTAGE }, children: [new Paragraph({ text: item.name, alignment: AlignmentType.CENTER })], verticalAlign: VerticalAlign.CENTER });
    const categoryCell = new TableCell({ width: { size: 15, type: WidthType.PERCENTAGE }, children: [new Paragraph({ text: item.category, alignment: AlignmentType.CENTER })], verticalAlign: VerticalAlign.CENTER });
    const sizeCell = new TableCell({ width: { size: 10, type: WidthType.PERCENTAGE }, children: [new Paragraph({ text: item.selectedSize, alignment: AlignmentType.CENTER })], verticalAlign: VerticalAlign.CENTER });
    const quantityCell = new TableCell({ width: { size: 10, type: WidthType.PERCENTAGE }, children: [new Paragraph({ text: String(item.quantity), alignment: AlignmentType.CENTER })], verticalAlign: VerticalAlign.CENTER });
    const colorCell = new TableCell({ width: { size: 10, type: WidthType.PERCENTAGE }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: item.selectedColor, bidirectional: false })] })], verticalAlign: VerticalAlign.CENTER });
    const priceCell = new TableCell({ width: { size: 15, type: WidthType.PERCENTAGE }, children: [new Paragraph({ text: formatCurrency(lineTotal), alignment: AlignmentType.CENTER, style: "PriceStyle" })], verticalAlign: VerticalAlign.CENTER });
    tableRows.push(new TableRow({ children: [nameCell, categoryCell, sizeCell, quantityCell, colorCell, priceCell] }));
  });

  // 2. Define Document Components
  const vantorHeaderTable = new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    bidiVisual: true,
    rows: [new TableRow({ children: [new TableCell({ shading: { fill: VANTOR_BLACK }, children: [new Paragraph({ children: [new TextRun({ text: "VANTOR", color: VANTOR_WHITE, bold: true, size: 48 })], alignment: AlignmentType.CENTER, spacing: { before: 200, after: 200 } })], borders: { top: { style: BorderStyle.NONE }, bottom: { style: BorderStyle.NONE }, left: { style: BorderStyle.NONE }, right: { style: BorderStyle.NONE } } })] })]
  });

  const customerNamePara = new Paragraph({ alignment: AlignmentType.RIGHT, children: [new TextRun({ text: `الاسم: `, bold: true, size: 28 }), new TextRun({ text: `  ${order.customerInfo.name}`, size: 28 })] });
  const customerPhonePara = new Paragraph({ alignment: AlignmentType.RIGHT, children: [new TextRun({ text: `الهاتف: `, bold: true, size: 28 }), new TextRun({ text: `  ${order.customerInfo.phone}`, size: 28, bidirectional: false })] });
  const customerAddressPara = new Paragraph({ alignment: AlignmentType.RIGHT, children: [new TextRun({ text: `العنوان: `, bold: true, size: 28 }), new TextRun({ text: `  ${order.customerInfo.address}`, size: 28 })] });
  const orderIdPara = new Paragraph({ alignment: AlignmentType.LEFT, children: [new TextRun({ text: `Order ID: `, bold: true, size: 24 }), new TextRun({ text: `${order.orderId}`, size: 24, bidirectional: false })] });
  const orderDatePara = new Paragraph({ alignment: AlignmentType.LEFT, children: [new TextRun({ text: `Date: `, bold: true, size: 24 }), new TextRun({ text: orderDate, size: 24, bidirectional: false })] });

  const itemsTable = new Table({
      width: { size: 100, type: WidthType.PERCENTAGE },
      bidiVisual: true,
      rows: tableRows,
      borders: {
          top: { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" },
          bottom: { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" },
          left: { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" },
          right: { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" },
          insideHorizontal: { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" },
          insideVertical: { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" },
      },
  });

  const totalsTable = new Table({
      width: { size: 40, type: WidthType.PERCENTAGE },
      rows: [
          new TableRow({
              children: [
                  new TableCell({ children: [new Paragraph({ text: formatCurrency(order.totalAmount), alignment: AlignmentType.LEFT, style: "PriceStyle" })] }),
                  new TableCell({ children: [new Paragraph({ text: "المجموع", alignment: AlignmentType.RIGHT, style: "TotalLabelStyle" })] }),
              ],
          }),
          new TableRow({
              children: [
                  new TableCell({ children: [new Paragraph({ text: formatCurrency(order.deliveryFee), alignment: AlignmentType.LEFT, style: "PriceStyle" })] }),
                  new TableCell({ children: [new Paragraph({ text: "التوصيل", alignment: AlignmentType.RIGHT, style: "TotalLabelStyle" })] }),
              ],
          }),
          new TableRow({
              children: [
                  new TableCell({ children: [new Paragraph({ text: formatCurrency(order.finalTotal), alignment: AlignmentType.LEFT, style: "FinalPriceStyle" })] }),
                  new TableCell({ children: [new Paragraph({ text: "الإجمالي", alignment: AlignmentType.RIGHT, style: "FinalTotalLabelStyle" })] }),
              ],
          }),
      ],
      float: { horizontalAnchor: "page", verticalAnchor: "page", align: AlignmentType.LEFT },
      borders: { top: { style: BorderStyle.NONE }, bottom: { style: BorderStyle.NONE }, left: { style: BorderStyle.NONE }, right: { style: BorderStyle.NONE } },
  });

  const notesPara = order.customerNotes ? new Paragraph({
      alignment: AlignmentType.RIGHT,
      children: [new TextRun({ text: `ملاحظات الزبون: `, bold: true, size: 24 }), new TextRun({ text: `${order.customerNotes}`, size: 24 })],
      spacing: { before: 200 }
  }) : new Paragraph({});

  const doc = new Document({
      background: { color: VANTOR_BG },
      styles: {
          paragraphStyles: [
              { id: "HeaderStyle", name: "Header Style", run: { color: VANTOR_WHITE, bold: true, size: 24 }, paragraph: { alignment: AlignmentType.CENTER } },
              { id: "PriceStyle", name: "Price Style", run: { bold: true, size: 24, font: "Arial" }, paragraph: { alignment: AlignmentType.CENTER } },
              { id: "FinalPriceStyle", name: "Final Price", run: { bold: true, size: 28, font: "Arial" }, paragraph: { alignment: AlignmentType.LEFT } },
              { id: "TotalLabelStyle", name: "Total Label", run: { bold: true, size: 24 }, paragraph: { alignment: AlignmentType.RIGHT } },
              { id: "FinalTotalLabelStyle", name: "Final Label", run: { bold: true, size: 28 }, paragraph: { alignment: AlignmentType.RIGHT } },
          ],
      },
      sections: [{
          properties: { page: { size: { width: 11906, height: 16838 }, orientation: PageOrientation.LANDSCAPE } },
          children: [
              vantorHeaderTable,
              new Paragraph({ text: "", spacing: { after: 200 } }),
              orderIdPara, orderDatePara,
              new Paragraph({ text: "", spacing: { after: 200 } }),
              customerNamePara, customerPhonePara, customerAddressPara,
              new Paragraph({ text: "", spacing: { after: 400 } }),
              itemsTable,
              new Paragraph({ text: "", spacing: { after: 200 } }),
              notesPara,
              totalsTable,
          ],
      }],
  });

  return await Packer.toUint8Array(doc);
}

function escapeMarkdown(text: string | number | undefined | null): string {
  const str = String(text ?? '');
  return str.replace(/[_*[\]()~`>#+\-=|{}.!]/g, '\\$&');
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const order = await req.json();
    const botToken = Deno.env.get("TELEGRAM_BOT_TOKEN");
    const chatId = Deno.env.get("TELEGRAM_CHAT_ID");
    const isStaging = Deno.env.get("IS_STAGING_ENV") === "true";

    if (!botToken || !chatId) {
      throw new Error("Missing Telegram credentials.");
    }
    
    // Generate Invoice
    const docxBuffer = await createInvoiceDocx(order);

    // Format Message
    let message = `*VANTOR \\- طلب جديد* ✨\n\n`;
    if (isStaging) message = `*\\(TESTING\\)* ${message}`;
    message += `*الزبون:* ${escapeMarkdown(order.customerInfo.name)}\n`;
    message += `*الهاتف:* \`${escapeMarkdown(order.customerInfo.phone)}\`\n`;
    message += `*العنوان:* ${escapeMarkdown(order.customerInfo.address)}\n`;
    message += `*ID:* \`${escapeMarkdown(order.orderId)}\`\n\n`;
    message += `*المنتجات:*\n`;
    
    order.cartItems.forEach((item: any) => {
      message += `\\- ${escapeMarkdown(item.name)} \\| ${escapeMarkdown(item.selectedSize)} \\| ${escapeMarkdown(item.selectedColor)} \\(x${item.quantity}\\) \\- *${escapeMarkdown(formatCurrency(item.price * item.quantity))}*\n`;
    });

    if (order.customerNotes) {
        message += `\n*ملاحظات الزبون:* ${escapeMarkdown(order.customerNotes)}\n`;
    }

    message += `\n*الإجمالي: ${escapeMarkdown(formatCurrency(order.finalTotal))}*`;

    // Send to Telegram
    const formData = new FormData();
    formData.append('chat_id', chatId);
    formData.append('document', new Blob([docxBuffer]), `VANTOR_Order_${order.orderId}.docx`);
    formData.append('caption', message);
    formData.append('parse_mode', 'MarkdownV2');
    
    const tgUrl = `https://api.telegram.org/bot${botToken}/sendDocument`;
    const tgResponse = await fetch(tgUrl, {
        method: 'POST',
        body: formData,
    });

    if (!tgResponse.ok) {
        const errorData = await tgResponse.json();
        console.error("Telegram API Error:", errorData);
        throw new Error(`Telegram API Error: ${errorData.description}`);
    }

    return new Response(JSON.stringify({ success: true }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });

  } catch (error) {
    console.error("Handler Error:", error);
    return new Response(JSON.stringify({ error: error.message }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
