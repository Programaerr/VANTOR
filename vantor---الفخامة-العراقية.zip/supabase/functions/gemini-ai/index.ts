// =================================================================================
// VANTOR - GEMINI AI ASSISTANT "Abood" - v25 (Tool Fix & Token Optimization)
// Model: gemini-3-flash-preview
// =================================================================================

import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { GoogleGenAI, FunctionDeclaration, Type } from "https://esm.sh/@google/genai@0.14.0";

// --- START: Inlined Prompt ---
const getSystemPrompt = (productContext: string) => `
الدور: أنت "عبود"، المساعد الذكي لمبيعات متجر "VANTOR" للأزياء الرجالية الفاخرة في العراق.

القواعد الصارمة للشخصية (Strict Persona Rules):
1.  اللهجة (Dialect): تحدث بلهجة عراقية بغدادية مهذبة جداً و"مثقفة".
    - ممنوع منعاً باتاً استخدام الفصحى أو اللهجات العامية المبتذلة.
    - أمثلة: "أهلاً وسهلاً بيك أستاذي"، "تأمرني"، "بالخدمة"، "صار تدلل".
2.  التعامل: كن مهذباً لأبعد الحدود. خاطب الزبون دائماً بصيغة الاحترام القصوى مثل "أستاذي" أو "حضرتك".
3.  اسم البراند: اذكر اسم المتجر دائماً بالإنجليزية "VANTOR" ولا تكتبه بالعربية (فانتور) أبداً.
4.  الممنوعات: ممنوع كلمات الدلع (عيوني، قلبي..)، وممنوع الفصحى.
5.  الإجابات: كن مختصراً ومباشراً جداً. جاوب على قدر السؤال فقط بجملة أو جملتين. **ممنوع منعاً باتاً طرح أي أسئلة على الزبون.** فقط أجب عن سؤاله.

---

**تعليمات استخدام الأدوات والردود (Tools & Responses Instructions):**

1.  **أداة البحث عن المنتجات (\`search_products\`):**
    - **متى تستخدمها:** فقط إذا سأل الزبون عن منتج معين (مثلاً "عندكم قميص أبيض؟" أو "أريد أشوف البناطير").
    - **ممنوع:** لا تجاوب من عندك أو من المعلومات العامة. ابحث أولاً ثم جاوب بشكل مختصر.

2.  **تتبع حالة الطلب (مهم جداً):**
    - إذا سأل الزبون عن حالة طلبه (مثلاً "وين صار طلبي؟")، **ممنوع منعاً باتاً** أن تحاول الإجابة أو البحث.
    - **مهمتك الوحيدة** هي أن تطلب منه بأدب التحدث مع موظف الدعم الفني.
    - **الرد النموذجي:** "تتدلل أستاذي، بخصوص متابعة الطلب، لازم تتواصل ويا الموظف المختص حتى ينطيك التفاصيل الدقيقة. اضغط على زر 'موظف' وراح يساعدك فوراً."

---

معلومات المنتجات العامة بالمخزن (للاسئلة العامة جداً فقط):
${productContext}

أمثلة للكلام (Style Examples):
- الزبون: "السلام عليكم"
- ردك: "وعليكم السلام أستاذي، أهلاً وسهلاً بحضرتك في VANTOR."
- الزبون: "عندكم بناطير جينز؟"
- ردك (بعد استخدام الأداة): "إي أستاذي متوفر. عدنا بنطرون جينز أسود سعره 35 ألف دينار." (إجابة مباشرة ومختصرة بدون سؤال إضافي).
- الزبون: "وين صار طلبي؟"
- ردك: "صار تدلل أستاذي، بخصوص متابعة الطلب، لازم تتواصل ويا الموظف المختص. اضغط على زر 'موظف' وراح يكون بخدمتك."

تذكر: كن مهذباً جداً، عراقياً، ومختصراً. لا تطرح أسئلة.
`;
// --- END: Inlined Prompt ---

declare const Deno: {
  env: { get: (key: string) => string | undefined; };
};

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "x-client-info, apikey, content-type, authorization",
};

// Tool 1: Search Products
const searchProductsTool: FunctionDeclaration = {
  name: "search_products",
  description: "Search for available products in VANTOR store based on a query.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      search_query: { type: Type.STRING, description: "Search term like 't-shirt' or 'black pants'." },
    },
    required: ["search_query"],
  },
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const geminiApiKey = Deno.env.get("GEMINI_API_KEY");
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || Deno.env.get("SUPABASE_ANON_KEY");

    if (!geminiApiKey || !supabaseUrl || !supabaseServiceKey) {
      return new Response(JSON.stringify({ error: "Configuration missing." }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const supabaseClient = createClient(supabaseUrl, supabaseServiceKey);
    const body = await req.json();
    const { query, history = [], products = [] } = body;
    
    if (!query) return new Response(JSON.stringify({ error: "Query is required" }), { status: 400, headers: corsHeaders });

    const ai = new GoogleGenAI({ apiKey: geminiApiKey });
    const productContextString = products.length > 0 ? products.slice(0, 30).map((p: any) => `- ${p.name} (${p.category}): ${Number(p.price).toLocaleString()} دينار ${p.isOutOfStock ? '(نفذت الكمية)' : ''}`).join('\n') : "المتجر قيد التحديث.";
    const systemPrompt = getSystemPrompt(productContextString);
    
    // TOKEN OPTIMIZATION: Limit conversation history
    const HISTORY_LIMIT = 6; // 3 user turns, 3 model turns
    const limitedHistory = (history || []).slice(-HISTORY_LIMIT);
    const geminiHistory = limitedHistory.map((msg: any) => ({
        role: msg.role,
        parts: [{ text: msg.text }],
    }));
    
    const contents = [...geminiHistory, { role: 'user', parts: [{ text: query }] }];

    const initialResponse = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents,
        config: {
            systemInstruction: systemPrompt,
            tools: [{ functionDeclarations: [searchProductsTool] }],
            toolConfig: {
                functionCallingConfig: {
                    mode: 'AUTO',
                },
            },
            temperature: 0.5,
        },
    });

    const modelResponse = initialResponse.candidates?.[0];

    // Handle Tool Calls
    if (modelResponse?.content?.parts?.some(p => p.functionCall)) {
      contents.push(modelResponse.content);
      const functionResponses = [];

      for (const part of modelResponse.content.parts) {
        if (part.functionCall) {
          const call = part.functionCall;
          let toolResultObject: object = {};

          if (call.name === 'search_products') {
            const q = String(call.args.search_query || '').trim();
            const { data, error } = await supabaseClient
              .from('products')
              .select('name, price, is_out_of_stock')
              .ilike('name', `%${q}%`)
              .limit(5);

            if (error) {
              console.error("DB Error on product search:", error);
              toolResultObject = { error: "صار خطأ فني بالبحث عن الموديلات." };
            } else {
              toolResultObject = {
                products: (data || []).map((p: any) => ({
                  name: p.name,
                  price: p.price,
                  is_out_of_stock: p.is_out_of_stock,
                })),
              };
            }
          }
          functionResponses.push({ functionResponse: { name: call.name, response: toolResultObject } });
        }
      }
      
      if (functionResponses.length > 0) {
        contents.push({ role: 'function', parts: functionResponses });
      }

      // BUG FIX: Explicitly set tool calling mode to NONE for the final response generation.
      // This prevents the "missing thought_signature" error.
      const finalResponse = await ai.models.generateContent({
          model: "gemini-3-flash-preview",
          contents,
          config: { 
            systemInstruction: systemPrompt,
            temperature: 0.5,
            toolConfig: {
                functionCallingConfig: {
                    mode: 'NONE',
                },
            },
          },
      });
      
      return new Response(JSON.stringify({ text: (finalResponse.text || '').trim() }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const reply = initialResponse.text || "هلا بيك أستاذ، تفضل شلون أقدر أساعدك؟";
    return new Response(JSON.stringify({ text: reply.trim() }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });

  } catch (error: any) {
    console.error("Gemini Function Error:", error);
    let errorMessage = "صارت مشكلة بسيطة، عيد السؤال بلا زحمة.";
    const lowerCaseError = (error.message || '').toLowerCase();

    if (lowerCaseError.includes("429") || lowerCaseError.includes("quota exceeded")) {
      errorMessage = "تم استهلاك الحصة اليومية للخطة المجانية. يرجى ترقية مشروعك في Google AI Studio لضمان استمرار عمل المساعد. لمعرفة المزيد: ai.google.dev/gemini-api/docs/billing";
    } else if (lowerCaseError.includes("503") || lowerCaseError.includes("service unavailable") || lowerCaseError.includes("high demand")) {
      errorMessage = "المساعد الذكي يواجه ضغطاً حالياً بسبب كثرة الطلبات. يرجى المحاولة مرة أخرى بعد قليل.";
    } else if (lowerCaseError.includes("function call is missing a thought_signature")) {
      errorMessage = "المساعد يواجه مشكلة تقنية حالياً، نعمل على إصلاحها.";
    }
    
    return new Response(JSON.stringify({ error: errorMessage }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
