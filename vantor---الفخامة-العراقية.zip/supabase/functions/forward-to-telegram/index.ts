
// =================================================================================
// VANTOR - BI-DIRECTIONAL SUPPORT CHAT - v12 (Long Message Splitter)
// =================================================================================

import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

declare const Deno: {
  env: {
    get: (key: string) => string | undefined;
  };
};

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "x-client-info, apikey, content-type, authorization",
};

// Helper to escape Markdown characters for Telegram
function escapeMarkdown(text: string | number | undefined | null): string {
  const str = String(text ?? '');
  return str.replace(/[_*[\]()~`>#+\-=|{}.!]/g, '\\$&');
}

// Helper to split long messages into chunks
function splitMessage(text: string, maxLength: number = 4000): string[] {
    const parts: string[] = [];
    let current = text;
    while (current.length > 0) {
        if (current.length <= maxLength) {
            parts.push(current);
            break;
        }
        let chunk = current.substring(0, maxLength);
        // Try to break at a space to avoid cutting words
        const lastSpace = chunk.lastIndexOf(' ');
        if (lastSpace > maxLength * 0.8) { // Only if space is near the end
            chunk = current.substring(0, lastSpace);
            current = current.substring(lastSpace + 1);
        } else {
            current = current.substring(maxLength);
        }
        parts.push(chunk);
    }
    return parts;
}

serve(async (req: Request) => {
  const logPrefix = "[forward-to-telegram v12]";

  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  try {
    const body = await req.json();

    const botToken = Deno.env.get("TELEGRAM_CLIENT_BOT_TOKEN");
    const adminChatId = Deno.env.get("TELEGRAM_CLIENT_CHAT_ID");

    if (!botToken || !adminChatId) {
      console.error(`${logPrefix}: CRITICAL - Missing secrets.`);
      return new Response(JSON.stringify({ error: "خطأ في إعدادات الخادم (Token/ChatID)." }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!supabaseUrl || !supabaseServiceKey) {
        throw new Error("Missing Supabase secrets.");
    }
    const supabaseClient = createClient(supabaseUrl, supabaseServiceKey, {
      auth: { autoRefreshToken: false, persistSession: false }
    });

    // --- LOGIC ROUTER ---
    
    // A. Telegram Webhook (Admin is replying)
    if (body.update_id && body.message) {
      const { message } = body;
      
      // Check if it's a reply in a forum topic
      if (message.is_topic_message && message.message_thread_id && message.reply_to_message) {
        const adminReplyText = message.text || "ملف/صورة (غير مدعوم حالياً)";
        const threadId = message.message_thread_id;
        
        // Find who owns this thread
        const { data: sessionData, error: sessionError } = await supabaseClient
            .from('support_sessions')
            .select('session_id')
            .eq('telegram_thread_id', threadId)
            .single();

        if (sessionError || !sessionData) {
            console.warn(`${logPrefix}: Session not found for thread ${threadId}`);
            return new Response(JSON.stringify({ success: true, message: "Ignored: Session not found." }), { status: 200, headers: { "Content-Type": "application/json" } });
        }

        // Broadcast to frontend
        const clientId = sessionData.session_id;
        
        // If message is massive (rare from Admin manual typing, but good for safety), split it too
        const chunks = splitMessage(adminReplyText, 4000);
        for (const chunk of chunks) {
            await supabaseClient.channel(`support-chat-${clientId}`).send({ 
                type: 'broadcast', 
                event: 'admin_reply', 
                payload: { userId: clientId, text: chunk } 
            });
        }
      }
      return new Response(JSON.stringify({ success: true }), { status: 200, headers: { "Content-Type": "application/json" } });
    }
    
    // B. Website Call (Customer is sending a message)
    else if (body.message && body.user) {
        const { message, user } = body;
        
        // 1. Check if we already have a thread for this user
        let threadId: number | null = null;
        const { data: sessionData, error: sessionError } = await supabaseClient
            .from('support_sessions')
            .select('telegram_thread_id')
            .eq('session_id', user.id)
            .maybeSingle(); 

        if (sessionData) {
            threadId = sessionData.telegram_thread_id;
        } else {
            // 2. Create New Topic in Telegram
            const safeName = (user.name || 'User').substring(0, 30);
            const topicName = `${safeName} | ${user.phone || 'No Phone'}`;
            
            const createTopicUrl = `https://api.telegram.org/bot${botToken}/createForumTopic`;
            const topicRes = await fetch(createTopicUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ chat_id: adminChatId, name: topicName })
            });

            if (!topicRes.ok) {
                const errData = await topicRes.json();
                console.error(`${logPrefix}: Create Topic Failed:`, errData);
                let friendlyError = "فشل إنشاء محادثة مع الدعم.";
                if (errData.description?.includes("not enough rights")) friendlyError = "خطأ صلاحيات: البوت لا يملك صلاحية 'إدارة المواضيع'.";
                else if (errData.description?.includes("not a forum")) friendlyError = "خطأ إعدادات: المجموعة ليست من نوع Forum.";
                return new Response(JSON.stringify({ success: false, error: friendlyError }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
            }
            
            const topicData = await topicRes.json();
            threadId = topicData.result.message_thread_id;

            // 3. Save Session
            await supabaseClient.from('support_sessions').insert({ session_id: user.id, telegram_thread_id: threadId });

            // 4. Send Intro Message
            const introMsg = `👤 *عميل جديد*\nالاسم: ${escapeMarkdown(user.name)}\nالهاتف: \`${escapeMarkdown(user.phone)}\`\nID: \`${escapeMarkdown(user.id)}\``;
            await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ chat_id: adminChatId, message_thread_id: threadId, text: introMsg, parse_mode: 'MarkdownV2' })
            });
        }

        // 5. Send User Message (Chunked & Robust)
        const messageChunks = splitMessage(message, 4000); // 4000 chars safety limit (Telegram max 4096)
        
        for (const chunk of messageChunks) {
            const userMsg = `💬 ${escapeMarkdown(chunk)}`;
            const sendRes = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ chat_id: adminChatId, message_thread_id: threadId, text: userMsg, parse_mode: 'MarkdownV2' })
            });

            if (!sendRes.ok) {
                const errText = await sendRes.text();
                console.error(`${logPrefix}: Send Message Failed:`, errText);
                // If markdown fails (rare edge case), fallback to plain text
                if (errText.includes("Markdown") || errText.includes("parse")) {
                     console.warn(`${logPrefix}: Retrying as plain text due to markdown error`);
                     await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
                        method: 'POST', headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ chat_id: adminChatId, message_thread_id: threadId, text: `💬 ${chunk}` }) // No parse_mode
                    });
                }
            }
        }
        
        return new Response(JSON.stringify({ success: true }), { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 200 });
    }
    
    return new Response(JSON.stringify({ error: "Invalid request" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });

  } catch (error: any) {
    console.error(`${logPrefix}: Global Error:`, error.message);
    return new Response(JSON.stringify({ success: false, error: error.message }), { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 500 });
  }
});
