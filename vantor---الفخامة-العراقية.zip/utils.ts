
// utils.ts

// الثابت المستخدم لتمييز العناصر النافذة في قاعدة البيانات (كنص)
export const OUT_OF_STOCK_SUFFIX = '__SOLDOUT__';

/**
 * تحليل خيار (مقاس أو لون) لمعرفة ما إذا كان نافذاً واستخراج القيمة الأصلية
 */
export function parseOption(option: string) {
  if (!option) return { value: '', isSoldOut: false };
  const isSoldOut = option.endsWith(OUT_OF_STOCK_SUFFIX);
  const value = isSoldOut ? option.replace(OUT_OF_STOCK_SUFFIX, '') : option;
  return { value, isSoldOut };
}

/**
 * تبديل حالة النفاذ للخيار (إضافة أو إزالة العلامة)
 */
export function toggleOptionStock(option: string): string {
  if (option.endsWith(OUT_OF_STOCK_SUFFIX)) {
    return option.replace(OUT_OF_STOCK_SUFFIX, '');
  } else {
    return `${option}${OUT_OF_STOCK_SUFFIX}`;
  }
}

export function withTimeout<T>(promise: Promise<T>, ms: number, errorMessage = 'Request timed out'): Promise<T> {
  return new Promise((resolve, reject) => {
    const timeoutId = setTimeout(() => { reject(new Error(errorMessage)); }, ms);
    promise.then(res => { clearTimeout(timeoutId); resolve(res); }).catch(err => { clearTimeout(timeoutId); reject(err); });
  });
}

/**
 * Helper to retry async functions (e.g. network requests)
 * يعيد المحاولة عند الفشل لعدد محدد من المرات مع تأخير تصاعدي
 */
export async function retry<T>(
  fn: () => Promise<T>, 
  retries = 3, 
  delay = 500
): Promise<T> {
  let lastError: any;
  for (let i = 0; i <= retries; i++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error;
      // Don't delay on the last attempt
      if (i < retries) {
        const backoff = delay * Math.pow(1.5, i); // Exponential backoff
        await new Promise(resolve => setTimeout(resolve, backoff));
      }
    }
  }
  throw lastError;
}
