
import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';

// Global Error Handler
window.onerror = function(message, source, lineno, colno, error) {
  console.error("Critical Runtime Error:", message, error);
  // نمنع استبدال الشاشة إلا في حالة الخطأ الكارثي الذي يمنع التحميل
  return false;
};

const container = document.getElementById('root');

if (container) {
  try {
    const root = createRoot(container);
    root.render(
      <React.StrictMode>
        <App />
      </React.StrictMode>
    );
  } catch (e) {
    console.error("React Mount Error:", e);
    container.innerHTML = `<div style="padding:20px;text-align:center;color:red"><h1>فشل تحميل التطبيق</h1><p>${e}</p></div>`;
  }
} else {
  console.error("Root element not found");
}
