
import { createClient } from '@supabase/supabase-js';

export const supabaseUrl = "https://xdkiyhdsqncltaxwkwow.supabase.co";
export const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inhka2l5aGRzcW5jbHRheHdrd293Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njk2MjU4NzksImV4cCI6MjA4NTIwMTg3OX0.8j96zq0HKXRON_IAkgjs6J-qxWRwfKrbE9TkyRbHiNM";

// Extract project reference from the URL
export const SUPABASE_PROJECT_REF = supabaseUrl.split('//')[1].split('.')[0];

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error("Supabase URL and Anon Key must be provided.");
}

// Simplified Json type
export type Json = any;

// Define the database schema for type safety
export interface Database {
  public: {
    Tables: {
      products: {
        Row: {
          id: string;
          created_at: string;
          name: string;
          price: number;
          original_price: number;
          description: string;
          category: string;
          images: string[];
          is_out_of_stock: boolean;
          colors: string[];
          sizes: string[];
          size_guide: string;
          offer_label: string;
        };
        Insert: {
          id?: string;
          name: string;
          price: number;
          original_price?: number;
          description?: string;
          category: string;
          images?: string[];
          is_out_of_stock?: boolean;
          colors?: string[];
          sizes?: string[];
          size_guide?: string;
          offer_label?: string;
        };
        Update: {
          id?: string;
          name?: string;
          price?: number;
          original_price?: number;
          description?: string;
          category?: string;
          images?: string[];
          is_out_of_stock?: boolean;
          colors?: string[];
          sizes?: string[];
          size_guide?: string;
          offer_label?: string;
        };
        Relationships: [];
      };
      categories: {
        Row: { name: string, created_at: string };
        Insert: { name: string };
        Update: { name?: string };
        Relationships: [];
      };
      orders: {
        Row: {
          id: number;
          orderid: string;
          timestamp: string;
          customerinfo: Json;
          cartitems: Json;
          totalamount: number;
          deliveryfee: number;
          finaltotal: number;
          userid: string | null;
          status: string | null;
          customer_notes: string | null;
        };
        Insert: {
          orderid: string;
          timestamp: string;
          customerinfo: Json;
          cartitems: Json;
          totalamount: number;
          deliveryfee: number;
          finaltotal: number;
          userid?: string | null;
          status?: string | null;
          customer_notes?: string | null;
        };
        Update: {
          orderid?: string;
          timestamp?: string;
          customerinfo?: Json;
          cartitems?: Json;
          totalamount?: number;
          deliveryfee?: number;
          finaltotal?: number;
          userid?: string | null;
          status?: string | null;
          customer_notes?: string | null;
        };
        Relationships: [];
      };
      settings: {
        Row: { key: string; value: string };
        Insert: { key: string; value: string };
        Update: { key?: string; value?: string };
        Relationships: [];
      };
      site_visits: {
        Row: {
          id: number;
          created_at: string;
          source: string | null; // Changed from ip_address
          city: string | null;
          country: string | null;
          device_type: string | null;
          os: string | null;
          browser: string | null;
          user_agent: string | null;
        };
        Insert: {
          source?: string | null; // Changed from ip_address
          city?: string | null;
          country?: string | null;
          device_type?: string | null;
          os?: string | null;
          browser?: string | null;
          user_agent?: string | null;
        };
        Update: {
          city?: string | null;
          country?: string | null;
        };
        Relationships: [];
      };
      admins: {
        Row: { id: string; created_at: string };
        Insert: { id: string };
        Update: { id?: string };
        Relationships: [];
      };
      order_managers: {
        Row: { id: string; email: string; created_at: string };
        Insert: { id: string; email: string };
        Update: { email?: string };
        Relationships: [];
      };
      support_sessions: {
        Row: {
          session_id: string;
          telegram_thread_id: number;
          created_at: string;
        };
        Insert: {
          session_id: string;
          telegram_thread_id: number;
        };
        Update: {
          session_id?: string;
          telegram_thread_id?: number;
        };
        Relationships: [];
      };
    };
    Views: {
      [_ in never]: never;
    };
    CompositeTypes: {
      [_ in never]: never;
    };
    Enums: {
      [_ in never]: never;
    };
    Functions: {
      [_ in never]: never;
    };
  };
}

// Basic client initialization without complex options to avoid potential conflicts
export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey);

export const checkConnection = async () => {
    try {
        const { error } = await supabase.from('products').select('count', { count: 'exact', head: true });
        if (error) throw error;
        return true;
    } catch {
        return false;
    }
}
