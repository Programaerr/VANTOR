
import { ChatMessage, Product } from '../types';
import { supabaseUrl, supabaseAnonKey } from './supabaseClient';
import { withTimeout } from '../utils';

/**
 * دالة استدعاء المساعد الذكي "مؤمل" (Gemini Edition)
 */
export const getAIAdvice = async (query: string, history: ChatMessage[], products: Product[]): Promise<string> => {
  try {
    const functionUrl = `${supabaseUrl}/functions/v1/gemini-ai`; // <-- تم التغيير إلى دالة Gemini

    // تقليل حجم البيانات المرسلة
    const minimalProducts = products.slice(0, 30).map(({ name, category, price, isOutOfStock }) => ({
        name, category, price, isOutOfStock
    }));

    // مهلة 40 ثانية
    const response = await withTimeout(
      fetch(functionUrl, {
        method: 'POST',
        headers: {
          'apikey': supabaseAnonKey,
          'authorization': `Bearer ${supabaseAnonKey}`,
          'content-type': 'application/json',
        },
        body: JSON.stringify({ query, history, products: minimalProducts }),
      }),
      40000, 
      "تأخر الخادم في الرد."
    );

    const data = await response.json();

    if (!response.ok) {
        // إذا أعاد الخادم خطأ (مثل 500)، تعامل معه بأناقة.
        const errorMessage = data.error || `حدث خطأ في الخادم (رمز الخطأ: ${response.status}).`;
        
        // التعامل مع خطأ المفتاح المفقود
        if (errorMessage.includes("API key not valid") || errorMessage.includes("GEMINI_API_KEY")) {
            return "⚠️ عذراً، المتجر يحتاج لإعداد مفتاح الذكاء الاصطناعي (GEMINI_API_KEY) في لوحة التحكم.";
        }
        
        return errorMessage;
    }
    
    return data.text || "حدث خطأ في قراءة الرد.";

  } catch (e: any) {
    console.error("AI Service Error:", e);
    const msg = (e.message || '').toLowerCase();

    if (msg.includes('timeout') || msg.includes('تأخر')) {
        return "شبكة الإنترنت ضعيفة قليلاً، حاول مرة أخرى.";
    }
    
    if (msg.includes('failed to fetch')) {
        return "فشل الاتصال بالخادم. يرجى التأكد من تشغيل الدالة السحابية.";
    }

    return "واجهت مشكلة بسيطة، هل يمكنك إعادة السؤال؟";
  }
};

export const checkAIServiceHealth = async (): Promise<{ ok: boolean; error?: string }> => {
  if (!supabaseUrl || !supabaseAnonKey) {
    return { ok: false, error: 'Missing API Configuration' };
  }
  return { ok: true };
};
