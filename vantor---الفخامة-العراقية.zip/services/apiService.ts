import { supabase, type Database, supabaseAnonKey } from './supabaseClient';
import { Product, OrderRecord, CurrentUser, VisitorRecord } from '../types';
import { withTimeout, retry } from '../utils';

// --- CACHING SYSTEM (CRITICAL FOR HIGH TRAFFIC ON FREE TIER) ---
const CACHE_DURATION = 1000 * 60 * 5; // 5 minutes cache
const CACHE = {
    products: { data: null as Product[] | null, timestamp: 0 },
    categories: { data: null as string[] | null, timestamp: 0 },
    settings: { data: null as any, timestamp: 0 }
};

// --- VISITOR ANALYTICS ---

export const recordVisit = async () => {
  // Check if session already recorded visit to avoid spamming (using sessionStorage)
  if (sessionStorage.getItem('vantor_visit_recorded')) return;

  try {
    // 1. Gather Client Info
    const ua = navigator.userAgent;
    const width = window.innerWidth;
    const deviceType = width < 768 ? 'Mobile' : 'Desktop';
    
    let os = 'Unknown';
    if (ua.indexOf("Win") !== -1) os = "Windows";
    if (ua.indexOf("Mac") !== -1) os = "MacOS";
    if (ua.indexOf("Linux") !== -1) os = "Linux";
    if (ua.indexOf("Android") !== -1) os = "Android";
    if (ua.indexOf("like Mac") !== -1) os = "iOS";

    let browser = 'Unknown';
    if (ua.indexOf("Chrome") !== -1) browser = "Chrome";
    else if (ua.indexOf("Safari") !== -1) browser = "Safari";
    else if (ua.indexOf("Firefox") !== -1) browser = "Firefox";
    else if (ua.indexOf("Edg") !== -1) browser = "Edge";

    // --- SOURCE DETECTION LOGIC ---
    let source = 'مباشر / غير معروف';
    const uaLower = ua.toLowerCase();
    
    if (uaLower.includes('instagram')) source = 'Instagram App';
    else if (uaLower.includes('fban') || uaLower.includes('fbav')) source = 'Facebook App';
    else if (uaLower.includes('tiktok')) source = 'TikTok App';
    else if (uaLower.includes('snapchat')) source = 'Snapchat';
    else if (uaLower.includes('twitter')) source = 'Twitter';
    else if (uaLower.includes('telegram')) source = 'Telegram';
    else if (document.referrer) {
        const referrer = document.referrer.toLowerCase();
        if (referrer.includes('instagram.com')) source = 'Instagram Web';
        else if (referrer.includes('facebook.com')) source = 'Facebook Web';
        else if (referrer.includes('tiktok.com')) source = 'TikTok Web';
        else if (referrer.includes('google')) source = 'Google Search';
        else {
            try { source = new URL(document.referrer).hostname; } catch { source = 'External Link'; }
        }
    }

    // 2. Fetch Approximate Location (Client-side, free API)
    // Optimization: Skip this on heavy load or slow connections if needed
    let city = 'Unknown';
    let country = 'Unknown';
    
    try {
        const geoRes = await withTimeout(fetch('https://ipapi.co/json/'), 2000, "Geo Timeout");
        if (geoRes.ok) {
            const geoData = await geoRes.json();
            city = geoData.city || 'Unknown';
            country = geoData.country_name || 'Unknown';
        }
    } catch (e) {
        // Silent fail for geo to keep app fast
    }

    // 3. Save to Supabase (Fire and Forget with Error Logging)
    supabase.from('site_visits').insert({
        device_type: deviceType,
        os: os,
        browser: browser,
        user_agent: ua,
        city: city,
        country: country,
        source: source
    }).then(({ error }) => {
        if (error) {
            // Suppress trivial network errors in analytics to keep console clean
            if (!error.message?.includes('Failed to fetch')) {
                console.warn('VANTOR Analytics Warning:', error.message);
            }
        } else {
            // Only set the flag on successful recording.
            sessionStorage.setItem('vantor_visit_recorded', 'true');
        }
    }).catch(err => {
        // Silently catch fetch errors for analytics
    });
    
  } catch (error) {
    // Ignore any other analytics errors
  }
};

export const getVisitorStats = async (limit = 200): Promise<VisitorRecord[]> => {
    const { data, error } = await supabase
        .from('site_visits')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(limit); 
    
    if (error) return [];
    return data || [];
};

// --- PRODUCTS (OPTIMIZED WITH CACHE) ---

export const getProducts = async (forceRefresh = false): Promise<Product[]> => {
  const now = Date.now();
  
  // Return cached data if available and fresh
  if (!forceRefresh && CACHE.products.data && (now - CACHE.products.timestamp < CACHE_DURATION)) {
      return CACHE.products.data;
  }

  // Try to get from SessionStorage (Fastest Load)
  if (!forceRefresh && !CACHE.products.data) {
      const stored = sessionStorage.getItem('vantor_products_cache');
      if (stored) {
          try {
              const parsed = JSON.parse(stored);
              if (now - parsed.timestamp < CACHE_DURATION) {
                  CACHE.products.data = parsed.data;
                  CACHE.products.timestamp = parsed.timestamp;
                  return parsed.data;
              }
          } catch (e) {}
      }
  }

  // WRAP WITH RETRY: Retry 3 times if network fails
  const data = await retry(async () => {
      const { data, error } = await supabase
        .from('products')
        .select('id, name, price, original_price, category, images, is_out_of_stock, offer_label, created_at, colors, sizes, description, size_guide')
        .order('created_at', { ascending: false })
        .limit(200);
        
      if (error) throw new Error(error.message);
      return data;
  }, 3, 500);

  const products = (data || []).map((p: any) => ({
    id: p.id,
    name: p.name || 'منتج غير معروف',
    price: Number(p.price) || 0,
    originalPrice: Number(p.original_price) || 0,
    description: p.description || '', 
    category: p.category || 'عام',
    images: Array.isArray(p.images) ? p.images : [],
    isOutOfStock: p.is_out_of_stock || false, 
    colors: Array.isArray(p.colors) ? p.colors : [], 
    sizes: Array.isArray(p.sizes) ? p.sizes : [], 
    sizeGuide: p.size_guide || '', 
    offerLabel: p.offer_label || '',
  }));

  // Update Cache
  CACHE.products.data = products;
  CACHE.products.timestamp = now;
  sessionStorage.setItem('vantor_products_cache', JSON.stringify({ data: products, timestamp: now }));

  return products;
};

export const getProductById = async (id: string): Promise<Product | null> => {
  // Check cache first
  if (CACHE.products.data) {
      const cached = CACHE.products.data.find(p => p.id === id);
      if (cached) return cached;
  }

  const { data, error } = await supabase
    .from('products')
    .select('id, name, price, original_price, category, images, is_out_of_stock, offer_label, created_at, colors, sizes, description, size_guide')
    .eq('id', id)
    .single();

  if (error || !data) return null;

  return {
    id: data.id,
    name: data.name,
    price: Number(data.price),
    originalPrice: Number(data.original_price),
    description: data.description || '',
    category: data.category,
    images: Array.isArray(data.images) ? data.images : [],
    isOutOfStock: data.is_out_of_stock || false,
    colors: Array.isArray(data.colors) ? data.colors : [],
    sizes: Array.isArray(data.sizes) ? data.sizes : [],
    sizeGuide: data.size_guide || '',
    offerLabel: data.offer_label || ''
  };
};

export const upsertProduct = async (product: Partial<Product>) => {
  const payload: Database['public']['Tables']['products']['Insert'] = {
    name: product.name!,
    price: Number(product.price) || 0,
    original_price: Number(product.originalPrice) || 0,
    description: product.description,
    category: product.category!,
    images: product.images || [],
    is_out_of_stock: product.isOutOfStock || false,
    colors: product.colors || [],
    sizes: product.sizes || [],
    size_guide: product.sizeGuide,
    offer_label: product.offerLabel,
  };

  if (product.id) payload.id = product.id;

  const { data, error } = await supabase.from('products').upsert(payload).select();
  if (error) { console.error('Supabase upsert error:', error); throw error; }
  
  // Invalidate Cache
  CACHE.products.data = null;
  sessionStorage.removeItem('vantor_products_cache');
  
  return data;
};

export const deleteProduct = async (id: string) => { 
    const { error } = await supabase.from('products').delete().eq('id', id); 
    if (error) throw error; 
    // Invalidate Cache
    CACHE.products.data = null;
    sessionStorage.removeItem('vantor_products_cache');
};

export const getCategories = async (): Promise<string[]> => { 
    const now = Date.now();
    if (CACHE.categories.data && (now - CACHE.categories.timestamp < CACHE_DURATION)) return CACHE.categories.data;

    // WRAP WITH RETRY
    const data = await retry(async () => {
        const { data, error } = await supabase.from('categories').select('name'); 
        if (error) throw new Error(error.message);
        return data;
    }, 3, 500);
    
    const cats = data ? data.map(c => c.name) : [];
    CACHE.categories.data = cats;
    CACHE.categories.timestamp = now;
    return cats;
};

export const addCategory = async (name: string) => { 
    const { error } = await supabase.from('categories').insert({ name }); 
    if (error) throw error;
    CACHE.categories.data = null; // Invalidate
};

export const updateCategory = async (originalName: string, newName: string) => {
    const { error: categoryUpdateError } = await supabase.from('categories').update({ name: newName }).eq('name', originalName);
    if (categoryUpdateError) throw new Error('فشل تحديث اسم القسم.');
    const { error: productUpdateError } = await supabase.from('products').update({ category: newName }).eq('category', originalName);
    if (productUpdateError) { await supabase.from('categories').update({ name: originalName }).eq('name', newName); throw new Error('فشل تحديث المنتجات.'); }
    
    CACHE.categories.data = null; // Invalidate
    CACHE.products.data = null;
    sessionStorage.removeItem('vantor_products_cache');
};

export const deleteCategory = async (name: string) => {
    const fallbackCategory = 'عام';
    if (name !== fallbackCategory) {
        const { data } = await supabase.from('categories').select('name').eq('name', fallbackCategory).maybeSingle();
        if (!data) await supabase.from('categories').insert({ name: fallbackCategory });
        await supabase.from('products').update({ category: fallbackCategory }).eq('category', name);
    }
    const { error } = await supabase.from('categories').delete().eq('name', name);
    if (error) throw error;
    
    CACHE.categories.data = null; // Invalidate
    CACHE.products.data = null;
    sessionStorage.removeItem('vantor_products_cache');
};

export const getSettings = async () => {
  const now = Date.now();
  if (CACHE.settings.data && (now - CACHE.settings.timestamp < CACHE_DURATION)) return CACHE.settings.data;

  try {
      // WRAP WITH RETRY
      const data = await retry(async () => {
        const { data, error } = await supabase.from('settings').select('*'); 
        if (error) throw new Error(error.message);
        return data;
      }, 3, 500);

      const settings: { [key: string]: string } = {};
      data?.forEach(item => { settings[item.key] = item.value; });
      
      const parsedSettings = { 
        heroImageUrl: settings.hero_image_url || 'https://raw.githubusercontent.com/Programaerr/ymg/main1/imgs/mos/mo1.jpg',
        announcementText: settings.announcement_text || '',
        announcementTimerEnabled: settings.announcement_timer_enabled === 'true',
        announcementDeadline: settings.announcement_deadline || '',
        announcementBgColor: settings.announcement_bg_color || '#000000',
        announcementTextColor: settings.announcement_text_color || '#FFFFFF',
        announcementSpeed: Number(settings.announcement_speed) || 30,
        tiktokUrl: settings.tiktok_url || '',
        instagramUrl: settings.instagram_url || '',
        facebookUrl: settings.facebook_url || '',
        whatsappUrl: settings.whatsapp_url || ''
      };
      
      CACHE.settings.data = parsedSettings;
      CACHE.settings.timestamp = now;
      return parsedSettings;
      
  } catch(e) {
      console.warn("Settings fetch warning:", e);
  }

  // Fallback default
  return { 
      heroImageUrl: 'https://raw.githubusercontent.com/Programaerr/ymg/main1/imgs/mos/mo1.jpg',
      announcementText: '',
      announcementTimerEnabled: false,
      announcementDeadline: '',
      announcementBgColor: '#000000',
      announcementTextColor: '#FFFFFF',
      announcementSpeed: 30,
      tiktokUrl: '',
      instagramUrl: '',
      facebookUrl: '',
      whatsappUrl: ''
  };
};

export const saveSettings = async (settings: any) => { 
  const updates = [];
  if (settings.heroImageUrl !== undefined) updates.push({ key: 'hero_image_url', value: settings.heroImageUrl });
  if (settings.announcementText !== undefined) updates.push({ key: 'announcement_text', value: settings.announcementText });
  if (settings.announcementTimerEnabled !== undefined) updates.push({ key: 'announcement_timer_enabled', value: String(settings.announcementTimerEnabled) });
  if (settings.announcementDeadline !== undefined) updates.push({ key: 'announcement_deadline', value: settings.announcementDeadline });
  if (settings.announcementBgColor !== undefined) updates.push({ key: 'announcement_bg_color', value: settings.announcementBgColor });
  if (settings.announcementTextColor !== undefined) updates.push({ key: 'announcement_text_color', value: settings.announcementTextColor });
  if (settings.announcementSpeed !== undefined) updates.push({ key: 'announcement_speed', value: String(settings.announcementSpeed) });
  if (settings.tiktokUrl !== undefined) updates.push({ key: 'tiktok_url', value: settings.tiktokUrl });
  if (settings.instagramUrl !== undefined) updates.push({ key: 'instagram_url', value: settings.instagramUrl });
  if (settings.facebookUrl !== undefined) updates.push({ key: 'facebook_url', value: settings.facebookUrl });
  if (settings.whatsappUrl !== undefined) updates.push({ key: 'whatsapp_url', value: settings.whatsappUrl });

  if (updates.length > 0) {
    const { error } = await supabase.from('settings').upsert(updates); 
    if (error) throw error; 
    CACHE.settings.data = null; // Invalidate
  }
};

const mapOrderRow = (o: any): OrderRecord => {
    let safeTimestamp = Date.now();
    if (o.timestamp) { 
        const parsed = new Date(o.timestamp).getTime();
        if (!isNaN(parsed)) safeTimestamp = parsed;
    }
    
    let customerInfo = o.customerinfo;
    if (typeof customerInfo === 'string') {
        try { customerInfo = JSON.parse(customerInfo); } catch(e) { customerInfo = {}; }
    }
    customerInfo = customerInfo || {};

    let cartItems = o.cartitems;
    if (typeof cartItems === 'string') {
        try { cartItems = JSON.parse(cartItems); } catch(e) { cartItems = []; }
    }
    cartItems = cartItems || [];
    
    return {
      orderId: o.orderid || `UNK-${Math.random().toString(36).substr(2, 5)}`, 
      timestamp: safeTimestamp,
      customerInfo: {
        name: customerInfo.name || 'غير معروف',
        phone: customerInfo.phone || '',
        address: customerInfo.address || ''
      },
      customerNotes: o.customer_notes || '',
      cartItems: Array.isArray(cartItems) ? cartItems.map((item: any) => ({
          id: item.id || 'unk', 
          name: item.name || 'منتج', 
          price: Number(item.price) || 0, 
          originalPrice: Number(item.original_price || item.originalPrice) || 0, 
          description: item.description || '', 
          category: item.category || '', 
          images: item.images || [], 
          isOutOfStock: item.is_out_of_stock || item.isOutOfStock || false, 
          colors: item.colors || [], 
          sizes: item.sizes || [], 
          sizeGuide: item.size_guide || item.sizeGuide || '', 
          offerLabel: item.offer_label || item.offerLabel || '', 
          quantity: Number(item.quantity) || 1, 
          selectedSize: item.selected_size || item.selectedSize || '', 
          selectedColor: item.selected_color || item.selectedColor || '',
      })) : [],
      totalAmount: Number(o.totalamount) || 0, 
      deliveryFee: Number(o.deliveryfee) || 0, 
      finalTotal: Number(o.finaltotal) || 0,
      userid: o.userid, 
      status: o.status || 'processing', 
    };
};

export const getOrders = async (limit: number = 50): Promise<OrderRecord[]> => {
    // Orders are usually live data, we don't cache them aggressively like products
    const { data, error } = await supabase
        .from('orders')
        .select('*')
        .order('timestamp', { ascending: false })
        .limit(limit);

    if (error) { console.error("getOrders error:", error); throw error; }
    return (data || []).map(mapOrderRow);
};

export const getOrdersLight = async (): Promise<Partial<OrderRecord>[]> => {
    const { data, error } = await supabase
        .from('orders')
        .select('orderid, status, finaltotal, timestamp')
        .order('timestamp', { ascending: false })
        .limit(50); 

    if (error) throw error;
    
    return (data || []).map((o: any) => {
        let ts = Date.now();
        if (o.timestamp) ts = new Date(o.timestamp).getTime();
        return {
            orderId: o.orderid || 'UNKNOWN',
            status: o.status || 'processing',
            finalTotal: Number(o.finaltotal) || 0,
            timestamp: ts
        };
    });
};

export const getOrdersPaginated = async (from: number, to: number): Promise<OrderRecord[]> => {
    const { data, error } = await supabase
        .from('orders')
        .select('*')
        .order('timestamp', { ascending: false })
        .range(from, to);

    if (error) throw error;
    return (data || []).map(mapOrderRow);
};

export const getUserOrders = async (userId: string): Promise<OrderRecord[]> => { 
    const { data, error } = await supabase.from('orders').select('*').eq('userid', userId).order('timestamp', { ascending: false }); 
    if (error) throw error; 
    return (data || []).map(mapOrderRow); 
};

export const updateOrderStatus = async (orderId: string, newStatus: string) => { 
    const { data, error } = await supabase.from('orders').update({ status: newStatus }).eq('orderid', orderId).select();
    if (error) throw new Error(`فشل: ${error.message}`);
    if (!data || data.length === 0) throw new Error("لم يتم التعديل.");
};

export const saveOrderDirectly = async (order: OrderRecord) => {
  try {
    const dbPayload = {
      orderid: order.orderId,
      timestamp: new Date(order.timestamp).toISOString(),
      customerinfo: order.customerInfo,
      customer_notes: order.customerNotes,
      cartitems: order.cartItems.map(item => ({
        id: item.id, 
        name: item.name, 
        price: item.price, 
        description: item.description, 
        category: item.category, 
        images: item.images, 
        colors: item.colors, 
        sizes: item.sizes, 
        quantity: item.quantity, 
        original_price: item.originalPrice, 
        is_out_of_stock: item.isOutOfStock, 
        size_guide: item.sizeGuide, 
        offer_label: item.offerLabel, 
        selected_size: item.selectedSize, 
        selected_color: item.selectedColor,
      })),
      totalamount: order.totalAmount, 
      deliveryfee: order.deliveryFee, 
      finaltotal: order.finalTotal, 
      userid: order.userid, 
      status: order.status || 'processing', 
    };
    const { error } = await supabase.from('orders').insert(dbPayload);
    if (error) throw new Error(`فشل الحفظ: ${error.message}`);
    return { success: true, orderId: order.orderId };
  } catch (error: any) { console.error("DB Insert Error:", error); throw error; }
};

export const sendTelegramNotification = async (order: OrderRecord) => {
  try {
    const { data: { session } } = await supabase.auth.getSession();
    const token = session?.access_token || supabaseAnonKey;

    const functionUrl = `https://xdkiyhdsqncltaxwkwow.supabase.co/functions/v1/vantor-telegram-sender`;
    
    // Fire and forget logic - don't await excessively
    fetch(functionUrl, {
        method: 'POST',
        headers: { 
            'apikey': supabaseAnonKey,
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json' 
        },
        body: JSON.stringify(order),
      }).catch(e => console.error("Telegram send bg error:", e));

    return { success: true };
  } catch (e: any) {
    return { success: false, error: e.message };
  }
};

export const isUserAdmin = async (userId: string): Promise<boolean> => {
  if (!userId) return false;
  try { const { data } = await supabase.from('admins').select('id').eq('id', userId).maybeSingle(); return !!data; } catch { return false; }
};

export const isUserOrderManager = async (userId: string): Promise<boolean> => {
  if (!userId) return false;
  try { const { data } = await supabase.from('order_managers').select('id').eq('id', userId).maybeSingle(); return !!data; } catch { return false; }
};

export const getOrderManagers = async () => {
    const { data, error } = await supabase.from('order_managers').select('id, email, created_at');
    if (error) throw error;
    return data || [];
};

export const updateUserProfile = async (profile: { name: string; phone: string; address: string }) => {
  const { data, error } = await supabase.auth.updateUser({ data: { name: profile.name, phone: profile.phone, address: profile.address } });
  if (error) throw error;
  return data.user;
};

export const getTopSellingProducts = async (allProducts: Product[]): Promise<Product[]> => {
  if (!allProducts || allProducts.length === 0) return [];
  // Use a predictable shuffle to keep hydration consistent if possible, or just simple slice
  // For better performance, avoid complex sorts on large arrays on every render
  return allProducts.slice(0, 4); 
};

export const forwardMessageToSupport = async (message: string, user: CurrentUser) => {
  try {
    const { data: { session } } = await supabase.auth.getSession();
    const functionUrl = `https://xdkiyhdsqncltaxwkwow.supabase.co/functions/v1/forward-to-telegram`;
    const token = session?.access_token || supabaseAnonKey;

    const headers: HeadersInit = {
        'apikey': supabaseAnonKey,
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
    };

    fetch(functionUrl, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify({ message, user })
    }).catch(e => console.error("Message fwd bg error:", e));
    
    return { success: true };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
};
