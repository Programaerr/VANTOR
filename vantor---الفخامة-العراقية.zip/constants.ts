
export const STANDARD_SIZE_GUIDE = `
• مقاس S: الطول (155-165 سم) | الوزن (45-55 كغم)
• مقاس M: الطول (165-172 سم) | الوزن (55-65 كغم)
• مقاس L: الطول (172-178 سم) | الوزن (65-75 كغم)
• مقاس XL: الطول (178-185 سم) | الوزن (75-85 كغم)
• مقاس XXL: الطول (185-195 سم) | الوزن (85-105 كغم)
`;

export const DEFAULT_PRODUCTS = [];

// FIX: Removed hardcoded sensitive credentials. Telegram configuration should be fetched from a secure source (e.g., backend settings).